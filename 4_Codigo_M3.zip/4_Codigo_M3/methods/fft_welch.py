"""
FFT/Welch based frequency estimator, built to be directly comparable to
the wavelet_cwt.py estimator: same search-band interface, same optional
sequential notch-based extraction, same parabolic sub-bin refinement.
"""
import numpy as np
from scipy.signal import welch, get_window, butter, sosfiltfilt


def _notch(y, fs, f0, bandwidth, order=4):
    nyq = fs / 2
    lo = max(f0 - bandwidth/2, 0.5) / nyq
    hi = min(f0 + bandwidth/2, nyq*0.98) / nyq
    sos = butter(order, [lo, hi], btype='bandstop', output='sos')
    return sosfiltfilt(sos, y)


def estimate_frequency_fft(t, y, f_band, fs, zero_pad_factor=8, window='hann'):
    """
    Hann-windowed periodogram with zero-padding for a fine frequency grid,
    peak search restricted to f_band, refined with parabolic interpolation
    across neighboring bins. Uses a single segment (nperseg = full record)
    since the 0.5 s / 2000-sample record is short and frequency RESOLUTION
    (not noise averaging) is what limits precision here.
    Returns (f_hat, amplitude_proxy).
    """
    n = len(y)
    win = get_window(window, n)
    y_win = y * win

    n_fft = int(2**np.ceil(np.log2(n * zero_pad_factor)))
    Y = np.fft.rfft(y_win, n=n_fft)
    freqs = np.fft.rfftfreq(n_fft, d=1.0/fs)
    power = np.abs(Y)**2

    f_low, f_high = f_band
    mask = (freqs >= f_low) & (freqs <= f_high)
    idx = np.where(mask)[0]
    if len(idx) == 0:
        return float('nan'), 0.0

    local_power = power[idx]
    k_local = np.argmax(local_power)
    k = idx[k_local]

    if 0 < k < len(freqs)-1:
        y0, y1, y2 = power[k-1], power[k], power[k+1]
        denom = (y0 - 2*y1 + y2)
        delta = 0.5*(y0-y2)/denom if abs(denom) > 1e-30 else 0.0
        delta = np.clip(delta, -1, 1)
        step = freqs[1] - freqs[0]
        f_hat = freqs[k] + delta*step
    else:
        f_hat = freqs[k]

    amp_proxy = np.sqrt(power[k]) * 2 / (np.sum(win))
    return float(f_hat), float(amp_proxy)


def estimate_all_tones_naive(t, y, fs, search_bands, **kwargs):
    """Single-pass: search each band directly on the raw composite signal
    (no interference cancellation). Used to test whether FFT/Welch suffers
    the same fundamental-leakage masking that raw CWT showed."""
    return [estimate_frequency_fft(t, y, band, fs, **kwargs) for band in search_bands]


def estimate_all_tones_sequential(t, y, fs, search_bands, notch_bandwidth_factor=1.0, **kwargs):
    """Successive-interference-cancellation variant, matching the wavelet
    estimator's methodology for a fair head-to-head comparison."""
    results = []
    y_work = y.copy()
    for band in search_bands:
        f_hat, amp = estimate_frequency_fft(t, y_work, band, fs, **kwargs)
        results.append((f_hat, amp))
        bw = notch_bandwidth_factor * (band[1] - band[0])
        y_work = _notch(y_work, fs, f_hat, bw)
    return results
