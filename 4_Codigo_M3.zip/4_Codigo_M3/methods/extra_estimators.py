"""
extra_estimators.py -- methods added in the journal revision (review report M3, Sec. 3.2):
interpolated DFT (IpDFT), SOGI-FLL, ESPRIT, VMD, plus a CWT ridge tracker with the
same parabolic refinement used in the stationary benchmark (fixes the Sec. 3.5
inconsistency), and shared filtering / analytic-signal helpers.

All filters are 6th-order Butterworth band-pass or 4th-order band-stop in SOS form.
Zero-phase (sosfiltfilt) is used for offline analysis; a causal variant is provided
for the real-time discussion.
"""
import numpy as np
from scipy.signal import butter, sosfiltfilt, sosfilt, hilbert, spectrogram
import pywt
from vmdpy import VMD


# ----------------------------------------------------------------------------- helpers
def bandpass(y, fs, lo, hi, order=6, causal=False):
    sos = butter(order, [lo/(fs/2), hi/(fs/2)], btype='band', output='sos')
    return sosfilt(sos, y) if causal else sosfiltfilt(sos, y)


def bandstop(y, fs, lo, hi, order=4, causal=False):
    sos = butter(order, [lo/(fs/2), hi/(fs/2)], btype='bandstop', output='sos')
    return sosfilt(sos, y) if causal else sosfiltfilt(sos, y)


def highpass(y, fs, fc, order=6):
    sos = butter(order, fc/(fs/2), btype='high', output='sos')
    return sosfiltfilt(sos, y)


def analytic_if(x, fs, pad=0):
    """Instantaneous amplitude and frequency from the analytic signal.
    pad > 0: symmetric (mirror) extension of `pad` samples on each side before the
    FFT-based Hilbert transform, then cropped -- reduces circular edge ripple."""
    if pad > 0:
        xe = np.concatenate([x[pad:0:-1], x, x[-2:-pad-2:-1]])
        a = hilbert(xe)[pad:pad+len(x)]
    else:
        a = hilbert(x)
    ph = np.unwrap(np.angle(a))
    f = np.diff(ph)*fs/(2*np.pi)
    return np.abs(a), np.concatenate([[f[0]], f])


def fit_sinusoid(y, t, f):
    M = np.column_stack([np.sin(2*np.pi*f*t), np.cos(2*np.pi*f*t)])
    c = np.linalg.lstsq(M, y, rcond=None)[0]
    return M @ c, float(np.hypot(*c))


# ----------------------------------------------------------------------------- IpDFT
def ipdft_peak(y, fs, band):
    """Hann-window two-point interpolated DFT (Grandke): delta = (2a-1)/(a+1)."""
    N = len(y)
    X = np.abs(np.fft.rfft(y*(0.5 - 0.5*np.cos(2*np.pi*np.arange(N)/N))))
    f = np.fft.rfftfreq(N, 1/fs)
    idx = np.where((f >= band[0]) & (f <= band[1]))[0]
    k = idx[np.argmax(X[idx])]
    if k <= 0 or k >= len(X)-1:
        return float(f[k])
    if X[k+1] >= X[k-1]:
        a = X[k+1]/X[k]; d = (2*a-1)/(a+1)
    else:
        a = X[k-1]/X[k]; d = -(2*a-1)/(a+1)
    return float((k+d)*fs/N)


def ipdft_sequential(y, t, fs, bands):
    """IpDFT with sequential cancellation: estimate, least-squares fit, subtract."""
    r, out = y.copy(), []
    for b in bands:
        f = ipdft_peak(r, fs, b)
        comp, _ = fit_sinusoid(r, t, f)
        r = r - comp
        out.append(f)
    return out


def ipdft_track(y, fs, band, win, hop):
    """Sliding-window IpDFT frequency (and amplitude) track, assigned to window centres."""
    N = len(y); centres, fr, am = [], [], []
    w = 0.5 - 0.5*np.cos(2*np.pi*np.arange(win)/win)  # periodic Hann, as assumed by the two-point interpolation
    for s in range(0, N-win+1, hop):
        seg = y[s:s+win]
        f = ipdft_peak(seg, fs, band)
        X = np.abs(np.fft.rfft(seg*w)); ff = np.fft.rfftfreq(win, 1/fs)
        idx = np.where((ff >= band[0]) & (ff <= band[1]))[0]
        am.append(2*X[idx].max()/w.sum())
        centres.append((s + win/2)/fs); fr.append(f)
    return np.array(centres), np.array(fr), np.array(am)


# ----------------------------------------------------------------------------- SOGI-FLL
def sogi_fll(v, fs, f0, k=np.sqrt(2), gamma=50.0, substeps=4):
    """Second-order generalized integrator with normalized frequency-locked loop
    (Rodriguez et al.). Integrated with forward Euler on `substeps` sub-samples.
    Returns the frequency estimate [Hz] and the in-phase amplitude estimate."""
    dt = 1/(fs*substeps)
    w = 2*np.pi*f0; va = vb = 0.0
    fo = np.empty(len(v)); ao = np.empty(len(v))
    for n, x in enumerate(v):
        for _ in range(substeps):
            e = x - va
            dva = w*(k*e - vb)
            dvb = w*va
            dw = -gamma*k*w*e*vb/(va*va + vb*vb + 1e-12)
            va += dva*dt; vb += dvb*dt; w += dw*dt
            w = min(max(w, 2*np.pi*1.0), 2*np.pi*fs/4)
        fo[n] = w/(2*np.pi); ao[n] = np.hypot(va, vb)
    return fo, ao


# ----------------------------------------------------------------------------- ESPRIT
def esprit(x, fs, p, L=None):
    """ESPRIT on a Hankel data matrix; p = signal-subspace dimension (2 per real tone).
    Returns (freq [Hz], sigma [1/s], amplitude) for positive-frequency poles."""
    N = len(x); L = L or min(N//3, 400)
    H = np.lib.stride_tricks.sliding_window_view(x, L).T      # L x (N-L+1)
    U = np.linalg.svd(H, full_matrices=False)[0][:, :p]
    z = np.linalg.eigvals(np.linalg.pinv(U[:-1]) @ U[1:])
    f = np.angle(z)*fs/(2*np.pi); s = np.log(np.abs(z))*fs
    keep = f > 0
    z, f, s = z[keep], f[keep], s[keep]
    n = np.arange(N)
    V = np.power.outer(z, n).T                                   # N x q
    V = np.column_stack([V, V.conj()])
    c = np.linalg.lstsq(V, x.astype(complex), rcond=None)[0]
    amp = 2*np.abs(c[:len(z)])
    order = np.argsort(f)
    return f[order], s[order], amp[order]


def esprit_track(y, fs, target, p, win, hop):
    """Sliding-window ESPRIT; returns the pole frequency closest to `target`."""
    centres, fr = [], []
    for s in range(0, len(y)-win+1, hop):
        f, _, _ = esprit(y[s:s+win], fs, p, L=win//2)
        fr.append(f[np.argmin(np.abs(f-target))] if len(f) else np.nan)
        centres.append((s+win/2)/fs)
    return np.array(centres), np.array(fr)


# ----------------------------------------------------------------------------- VMD
def vmd_modes(y, fs, K, alpha=2000):
    """VMD (Dragomiretskiy & Zosso) via vmdpy; returns modes (K x N) and centres [Hz]."""
    yy = y if len(y) % 2 == 0 else y[:-1]
    u, _, om = VMD(yy, alpha, 0., K, 0, 1, 1e-7)
    u = np.asarray(u)
    if u.shape[1] < len(y):
        u = np.column_stack([u, u[:, -1:]])
    return u, om[-1]*fs


# ----------------------------------------------------------------------------- CWT ridge
def cwt_track(y, fs, fmin, fmax, n=120, wavelet='cmor1.5-1.0', refine=True, l1=True, return_amp=False):
    """CWT ridge frequency per sample, with optional parabolic refinement across scales
    (the same refinement used for the stationary benchmark)."""
    fr = np.linspace(fmin, fmax, n)
    scales = pywt.central_frequency(wavelet)*fs/fr
    C, fa = pywt.cwt(y, scales, wavelet, sampling_period=1/fs)
    P = np.abs(C)**2
    if l1:                     # L1 normalization removes the L2 ridge bias toward low frequency
        P = P/scales[:, None]
    k = np.argmax(P, axis=0)
    fhat = fa[k].astype(float)
    if refine:
        kk = np.clip(k, 1, len(fa)-2); cols = np.arange(P.shape[1])
        y0, y1, y2 = P[kk-1, cols], P[kk, cols], P[kk+1, cols]
        den = y0 - 2*y1 + y2
        d = np.where(np.abs(den) > 1e-30, 0.5*(y0-y2)/den, 0.0)
        d = np.clip(d, -1, 1)
        fhat = fa[kk] + d*(fa[kk+1]-fa[kk-1])/2
    if return_amp:
        return fhat, np.sqrt(P.max(axis=0))
    return fhat


def cwt_tone(y, fs, band, n=250, wavelet='cmor1.5-1.0', l1=True):
    """Stationary tone: band-limit, time-averaged scalogram (edges trimmed 5%), parabolic
    refinement. l1=False reproduces the L2-normalized (biased) original estimator."""
    lo, hi = band; span = hi-lo
    x = bandpass(y, fs, max(lo-0.15*span, 1.0), min(hi+0.15*span, fs/2*0.98))
    fr = np.linspace(lo, hi, n); sc = pywt.central_frequency(wavelet)*fs/fr
    C, fa = pywt.cwt(x, sc, wavelet, sampling_period=1/fs)
    P = np.abs(C)**2
    if l1:
        P = P/sc[:, None]
    e = int(0.05*len(y)); mp = P[:, e:len(y)-e].mean(axis=1)
    k = int(np.clip(np.argmax(mp), 1, len(fa)-2))
    den = mp[k-1]-2*mp[k]+mp[k+1]
    d = 0.5*(mp[k-1]-mp[k+1])/den if abs(den) > 1e-30 else 0.0
    return float(fa[k] + np.clip(d, -1, 1)*(fa[k+1]-fa[k-1])/2)


def cwt_sequential(y, t, fs, bands, l1=True):
    r, out = y.copy(), []
    for b in bands:
        f = cwt_tone(r, fs, b, l1=l1); out.append(f)
        comp, _ = fit_sinusoid(r, t, f); r = r - comp
    return out


def stft_track(y, fs, band, nperseg=200, step=2, nfft=None):
    f, tt, S = spectrogram(y, fs=fs, nperseg=nperseg, noverlap=nperseg-step, window='hann', nfft=nfft)
    m = (f >= band[0]) & (f <= band[1])
    return tt, f[m][np.argmax(S[m, :], axis=0)], np.sqrt(S[m, :].max(axis=0))
