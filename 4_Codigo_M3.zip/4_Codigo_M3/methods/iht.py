"""
Iterative Hybrid Transform (IHT)
================================
Following the methodology line of Sanabria-Villamizar et al., "A New
Hybrid Signal Analysis Method for the Evaluation of Power Quality
Disturbances," IEEE Madrid PowerTech, 2021.

Unlike FN-EMD (which removes a FIXED, externally-assumed notch band
around the nominal fundamental frequency), IHT is fully signal-adaptive:

  1. Decompose the CURRENT residual (initially the raw signal) via
     CEEMDAN.
  2. Identify which resulting IMF corresponds to the tone of interest
     (e.g., the fundamental) by its own extracted instantaneous
     frequency -- not an assumed nominal value.
  3. Subtract THAT SPECIFIC IMF -- its actual extracted waveform,
     including whatever amplitude/phase modulation EMD found, not an
     idealized notch-filtered sinusoid -- from the CURRENT residual.
  4. Re-decompose the new residual to isolate the next tone, and
     repeat.

This lets each extraction adapt to what the signal actually contains
(e.g., small deviations from nominal frequency, amplitude modulation)
rather than assuming a fixed external band, and is iterative in the
sense that each round's residual becomes the next round's input signal.
"""
import numpy as np
from scipy.signal import hilbert
from PyEMD import CEEMDAN


def _median_inst_freq(t, imf, edge_frac=0.05, fs=None):
    analytic = hilbert(imf)
    phase = np.unwrap(np.angle(analytic))
    dt = t[1] - t[0]
    ifreq = np.diff(phase) / (2*np.pi*dt)
    n = len(t)
    edge = int(edge_frac*n)
    trim = ifreq[edge:n-1-edge]
    nyq = fs/2 if fs else 1/(2*dt)
    valid = trim[(trim > 0) & (trim < nyq)]
    return float(np.median(valid)) if len(valid) else float('nan')


def iht_decompose(t, y, fs, f_target_ranges, trials=100, epsilon=0.05, seed=42):
    """
    f_target_ranges: list of (f_low, f_high) tuples, one per tone to
    extract, IN THE ORDER they should be peeled off (typically largest/
    lowest-frequency first, e.g. fundamental, then control band, then
    switching residual).

    Returns: list of (f_hat, imf_waveform) tuples, one per target range,
    plus the final residual after all extractions.
    """
    results = []
    residual = y.copy()

    for (f_low, f_high) in f_target_ranges:
        ceemdan = CEEMDAN(trials=trials, epsilon=epsilon, parallel=False)
        ceemdan.noise_seed(seed)
        imfs = ceemdan.ceemdan(residual, t)

        freqs = [_median_inst_freq(t, imf, fs=fs) for imf in imfs]
        amps = [np.std(imf) for imf in imfs]

        in_band = [i for i, f in enumerate(freqs) if f_low <= f <= f_high]
        if in_band:
            # among IMFs whose own extracted frequency falls in-band,
            # take the largest-amplitude one (most likely the genuine
            # tone rather than a minor leakage fragment)
            best = in_band[int(np.argmax([amps[i] for i in in_band]))]
        else:
            center = (f_low + f_high) / 2
            best = int(np.argmin([abs(f-center) for f in freqs]))

        f_hat = freqs[best]
        imf_best = imfs[best]
        results.append((f_hat, imf_best))

        # adaptive subtraction: remove EMD's OWN identified waveform,
        # not an idealized fixed-band notch
        residual = residual - imf_best

    return results, residual


def _band_power(t, x, fs, f_low, f_high):
    from scipy.signal import welch
    f, Pxx = welch(x, fs=fs, nperseg=min(len(x), 2000))
    mask = (f >= f_low) & (f <= f_high)
    return float(Pxx[mask].max()) if mask.any() else 0.0


def iht_decompose_deflation(t, y, fs, f_target_ranges, trials=100, epsilon=0.05,
                             seed=42, max_deflation_rounds=4, power_ratio_threshold=0.15):
    """
    Iterative-DEFLATION variant of IHT: for each target range, repeat
    "identify the in-band IMF and subtract it" on the SAME residual
    multiple times, checking after each subtraction whether the band's
    peak power has dropped below power_ratio_threshold of its value
    before this round's extraction started. Only once the band is
    genuinely depleted (or max_deflation_rounds is reached) does the
    method move on to the next target range. This directly targets the
    incomplete single-pass subtraction found with plain IHT (a single
    EMD-identified IMF does not capture 100% of a dominant tone's
    energy when smaller tones are also present).

    Returns: list of (f_hat, cumulative_imf_waveform) per target range,
    plus per-round diagnostics for transparency.
    """
    results = []
    diagnostics = []
    residual = y.copy()

    for (f_low, f_high) in f_target_ranges:
        power_before_band = _band_power(t, residual, fs, f_low, f_high)
        cumulative_imf = np.zeros_like(residual)
        round_log = []
        f_hat = float('nan')

        for r in range(max_deflation_rounds):
            ceemdan = CEEMDAN(trials=trials, epsilon=epsilon, parallel=False)
            ceemdan.noise_seed(seed + r)
            imfs = ceemdan.ceemdan(residual, t)

            freqs = [_median_inst_freq(t, imf, fs=fs) for imf in imfs]
            amps = [np.std(imf) for imf in imfs]
            in_band = [i for i, f in enumerate(freqs) if f_low <= f <= f_high]

            if in_band:
                best = in_band[int(np.argmax([amps[i] for i in in_band]))]
            else:
                center = (f_low+f_high)/2
                best = int(np.argmin([abs(f-center) for f in freqs]))

            f_hat = freqs[best]
            residual = residual - imfs[best]
            cumulative_imf = cumulative_imf + imfs[best]

            power_now = _band_power(t, residual, fs, f_low, f_high)
            ratio = power_now / power_before_band if power_before_band > 0 else 0.0
            round_log.append({'round': r, 'f_hat': f_hat, 'power_ratio_remaining': ratio})

            if ratio < power_ratio_threshold:
                break

        results.append((f_hat, cumulative_imf))
        diagnostics.append(round_log)

    return results, residual, diagnostics
