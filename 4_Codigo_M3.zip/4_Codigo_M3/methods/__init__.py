"""GT&D Latin America 2027 paper -- shared signal/estimation methods package."""
