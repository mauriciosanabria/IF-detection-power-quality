"""
Empirical Mode Decomposition (EMD) + Hilbert Transform frequency estimator
-- i.e., the actual "HHT" half of the HHT->LM pipeline, run here on its own
(no LM refinement) so it can be compared head-to-head with FFT and Wavelet
on the same footing.

This implements the sifting algorithm exactly as described in the
companion PowerTech 2027 paper (Algorithm 1): cubic-spline envelopes,
mirror-extended edges to suppress boundary artifacts, sifting stops when
the number of extrema and zero-crossings differ by <=1 or after 15
iterations. Each resulting IMF's instantaneous frequency is obtained via
the analytic signal (Hilbert transform); IMFs are then matched to the
expected tones by comparing their median instantaneous frequency against
the same search bands used for the FFT/Wavelet estimators, so all three
methods are given the same amount of prior information.
"""
import numpy as np
from scipy.signal import hilbert
from scipy.interpolate import CubicSpline


def _find_extrema(x):
    """Indices of local maxima and minima."""
    dx = np.diff(x)
    maxima = np.where((dx[:-1] > 0) & (dx[1:] <= 0))[0] + 1
    minima = np.where((dx[:-1] < 0) & (dx[1:] >= 0))[0] + 1
    return maxima, minima


def _envelope(t, x, extrema_idx):
    """Cubic-spline envelope through the given extrema, mirror-extended
    at both ends to reduce edge artifacts."""
    if len(extrema_idx) < 2:
        return np.full_like(x, np.nan)
    # mirror-extend: reflect the first/last extrema-to-edge span
    idx = list(extrema_idx)
    n = len(t)
    left_pad = 2*idx[0] - idx[1] if len(idx) > 1 else idx[0] - 1
    right_pad = 2*idx[-1] - idx[-2] if len(idx) > 1 else idx[-1] + 1
    ext_idx = np.array([left_pad] + idx + [right_pad])
    ext_idx = np.clip(ext_idx, 0, n-1)
    ext_t = t[0] + ext_idx * (t[1]-t[0]) if len(t) > 1 else t
    # use actual t spacing
    dt = t[1] - t[0]
    ext_t = t[0] + ext_idx * dt
    ext_x = x[ext_idx]
    cs = CubicSpline(ext_t, ext_x)
    return cs(t)


def sift_one_imf(t, x, max_iter=15):
    h = x.copy()
    for _ in range(max_iter):
        maxima, minima = _find_extrema(h)
        if len(maxima) < 2 or len(minima) < 2:
            break
        upper = _envelope(t, h, maxima)
        lower = _envelope(t, h, minima)
        if np.any(np.isnan(upper)) or np.any(np.isnan(lower)):
            break
        mean_env = (upper + lower) / 2
        h_new = h - mean_env

        n_extrema = len(maxima) + len(minima)
        zero_cross = np.sum(np.diff(np.sign(h_new)) != 0)
        if abs(n_extrema - zero_cross) <= 1:
            h = h_new
            break
        h = h_new
    return h


def emd_decompose_legacy(t, x, max_imfs=8, sift_iter=15):
    """DEFECTUOSA, conservada solo por trazabilidad: su extension espejo de los bordes genera IMF lentas
    espurias (con una senoide pura devuelve tres IMF adicionales con 9-31 % de la energia). No usar."""
    residual = x.copy()
    imfs = []
    for _ in range(max_imfs):
        maxima, minima = _find_extrema(residual)
        if len(maxima) < 2 or len(minima) < 2:
            break
        imf = sift_one_imf(t, residual, max_iter=sift_iter)
        imfs.append(imf)
        residual = residual - imf
    imfs.append(residual)
    return imfs


def emd_decompose(t, x, max_imfs=8, sift_iter=15):
    """EMD estandar (PyEMD, EMD-signal): envolventes por splines cubicos, extension de los extremos en los bordes
    de la libreria y un maximo de `sift_iter` iteraciones de sifting por IMF. Devuelve la lista de IMF con el
    residuo como ultimo elemento (misma interfaz que la version anterior)."""
    import numpy as _np
    from PyEMD import EMD as _EMD
    e = _EMD(spline_kind='cubic'); e.MAX_ITERATION = int(sift_iter)
    e.emd(_np.asarray(x, float), _np.asarray(t, float), max_imf=int(max_imfs))
    imfs, res = e.get_imfs_and_residue()
    return [q for q in imfs] + [res]


def instantaneous_frequency(t, imf):
    """Hilbert-transform based instantaneous frequency [Hz] of one IMF."""
    analytic = hilbert(imf)
    phase = np.unwrap(np.angle(analytic))
    dt = t[1] - t[0]
    inst_freq = np.diff(phase) / (2*np.pi*dt)
    return inst_freq  # length N-1


def estimate_all_tones_hht(t, y, search_bands, max_imfs=10, edge_trim=0.05):
    """
    Decompose y via EMD, compute each IMF's median instantaneous
    frequency (excluding edge samples), and match IMFs to search_bands
    by picking, for each band, the IMF whose median frequency falls
    inside it (or is closest, if none fall exactly inside).
    Returns a list of (f_hat, amplitude_proxy), one per search band, in
    the same order as search_bands, for direct comparability with the
    FFT/Wavelet estimators.
    """
    imfs = emd_decompose(t, y, max_imfs=max_imfs)
    n = len(t)
    edge = int(edge_trim * n)

    imf_freqs = []
    imf_amps = []
    for imf in imfs[:-1]:  # exclude final residual/trend
        if_full = instantaneous_frequency(t, imf)
        if_trim = if_full[edge:n-1-edge]
        if_trim = if_trim[(if_trim > 0) & (if_trim < 1/(2*(t[1]-t[0])))]  # physical range
        if len(if_trim) == 0:
            imf_freqs.append(np.nan)
            imf_amps.append(0.0)
            continue
        imf_freqs.append(np.median(if_trim))
        imf_amps.append(np.sqrt(np.mean(imf[edge:n-edge]**2)) * np.sqrt(2))

    imf_freqs = np.array(imf_freqs)
    imf_amps = np.array(imf_amps)

    results = []
    used = set()
    for (f_low, f_high) in search_bands:
        in_band = np.where((imf_freqs >= f_low) & (imf_freqs <= f_high))[0]
        in_band = [i for i in in_band if i not in used]
        if len(in_band) > 0:
            # if multiple IMFs land in-band, take the one with largest amplitude
            best = in_band[np.argmax(imf_amps[in_band])]
        else:
            # fall back to closest median frequency not yet used
            remaining = [i for i in range(len(imf_freqs)) if i not in used and not np.isnan(imf_freqs[i])]
            if not remaining:
                results.append((float('nan'), 0.0))
                continue
            center = (f_low+f_high)/2
            best = remaining[np.argmin(np.abs(imf_freqs[remaining]-center))]
        used.add(best)
        results.append((float(imf_freqs[best]), float(imf_amps[best])))
    return results, len(imfs)-1
