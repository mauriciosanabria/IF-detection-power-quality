"""
Ground-truth tri-tone parameters for nodes v1, v2, v3 of the case-study
network -- identical to those validated in the companion PowerTech 2027
papers, used here for direct comparability across method comparisons.

Each row: (amplitude [kV], frequency [Hz], phase [rad])
"""
import numpy as np

CONFIGS = {
    'v1': np.array([
        127.84, 50.00, np.deg2rad(0.31),
        -2.56,  91.23, np.deg2rad(17.97),
        -0.019, 1000.22, np.deg2rad(-3.03),
    ]),
    'v2': np.array([
        127.71, 50.01, np.deg2rad(-1.07),
        0.065,  123.45, np.deg2rad(-47.21),
        -0.026, 986.07, np.deg2rad(28.92),
    ]),
    'v3': np.array([
        122.44, 50.01, np.deg2rad(1.06),
        -0.62,  161.08, np.deg2rad(-128.95),
        0.036,  1005.46, np.deg2rad(-11.29),
    ]),
}

FS = 4000.0   # Hz
T = 0.5       # s
N = int(FS * T)


def y_model(theta, t):
    a1, f1, p1, a2, f2, p2, a3, f3, p3 = theta
    return (a1 * np.sin(2*np.pi*f1*t + p1)
            + a2 * np.sin(2*np.pi*f2*t + p2)
            + a3 * np.sin(2*np.pi*f3*t + p3))


def time_vector():
    return np.arange(N) / FS


def add_noise(y, snr_db, rng):
    if snr_db is None:
        return y.copy()
    p_sig = np.mean(y**2)
    p_noise = p_sig / (10**(snr_db/10))
    return y + rng.normal(0, np.sqrt(p_noise), size=y.shape)
