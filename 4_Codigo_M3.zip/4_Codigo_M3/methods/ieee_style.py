"""
Shared IEEE-compliant matplotlib style for Figures 3-5.
- Times New Roman (substituted with Liberation Serif, the metric-compatible
  open-source equivalent, since true Times New Roman is not licensed for
  redistribution on this system -- Liberation Serif is the same substitution
  IEEE's own LaTeX class effectively performs via the Times/Nimbus mapping).
- 9pt base size, ticks inward, no gridlines, opaque non-obscuring legends,
  distinguishable line styles for greyscale/B&W printing.
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Liberation Serif', 'Times New Roman', 'DejaVu Serif'],
    'font.size': 9,
    'axes.titlesize': 10,
    'axes.labelsize': 9,
    'legend.fontsize': 8,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.top': True,
    'ytick.right': True,
    'axes.grid': False,
    'legend.frameon': True,
    'legend.framealpha': 1.0,
    'legend.edgecolor': 'black',
    'legend.fancybox': False,
    'lines.linewidth': 1.1,
    'axes.linewidth': 0.8,
    'savefig.dpi': 300,
})

# Distinguishable (colour + linestyle + marker) series styling for B&W printing
SERIES_STYLE = [
    dict(color='#000000', linestyle='-',  marker='o', markersize=3, markevery=0.08),
    dict(color='#c0392b', linestyle='--', marker='s', markersize=3, markevery=0.08),
    dict(color='#1a5fb4', linestyle='-.', marker='^', markersize=3, markevery=0.08),
    dict(color='#555555', linestyle=':',  marker='D', markersize=2.5, markevery=0.08),
]
