"""
extra2.py -- estimators added in the second revision round (review report M3, Sec. 3.2):
Matrix Pencil, least-squares Prony, synchrophasor-type frequency estimators with the
P-class filter of IEC/IEEE 60255-118-1 and an M-class-type filter, and a Fourier
synchrosqueezing transform (FSST) with ridge and multi-peak extraction.
"""
import numpy as np


def _amps(x, z):
    n = np.arange(len(x)); V = np.power.outer(z, n).T; V = np.column_stack([V, V.conj()])
    c = np.linalg.lstsq(V, x.astype(complex), rcond=None)[0]
    return 2*np.abs(c[:len(z)])


def _poles_out(z, fs, x):
    f = np.angle(z)*fs/(2*np.pi); s = np.log(np.abs(z)+1e-300)*fs
    k = f > 0; z, f, s = z[k], f[k], s[k]
    a = _amps(x, z) if len(z) else np.array([])
    o = np.argsort(f)
    return f[o], s[o], a[o]


def matrix_pencil(x, fs, M, L=None):
    """Matrix Pencil (Hua & Sarkar): Hankel matrix (N-L) x (L+1), rank-M truncation of the
    right singular vectors, poles = eig(pinv(V1) V2). Returns (freq, sigma, amplitude)."""
    N = len(x); L = L or min(N//3, 400)
    Y = np.lib.stride_tricks.sliding_window_view(x, L+1)           # (N-L) x (L+1)
    V = np.linalg.svd(Y, full_matrices=False)[2].conj().T[:, :M]    # (L+1) x M
    z = np.linalg.eigvals(np.linalg.pinv(V[:-1]) @ V[1:])
    return _poles_out(z, fs, x)


def prony(x, fs, p):
    """Least-squares Prony of order p: linear prediction, polynomial roots."""
    N = len(x)
    A = np.column_stack([x[p-k-1:N-k-1] for k in range(p)]); b = x[p:]
    a = np.linalg.lstsq(A, -b, rcond=None)[0]
    z = np.roots(np.concatenate([[1.0], a]))
    return _poles_out(z, fs, x)


def pmu_phasor(y, fs, f0, cls='P'):
    """Reference phasor model of IEC/IEEE 60255-118-1:2018, Annex D (Eq. D.1): quadrature
    demodulation at f0 and symmetric FIR low-pass, time-stamped at the window centre.
    P class (D.6): W(k) = 1 - 2|k|/(N+2), N = 2(fs/f0 - 1) (two cycles).
    M class (D.7): W(k) = sin(2 pi (2 Ffr/fs) k)/(2 pi (2 Ffr/fs) k) * h(k), Hamming h, with the
    Table D.1 values for f0 = 50 Hz and a 50 frame/s reporting rate (Ffr = 7.75 Hz, N = 142 at the
    reference 800 sample/s), N scaled to the actual sampling rate so that the window length is kept."""
    n = np.arange(len(y)); X = y*np.exp(-1j*2*np.pi*f0*n/fs)
    if cls == 'P':
        N = int(2*(round(fs/f0)-1)); k = np.arange(-N//2, N//2+1); W = 1 - 2*np.abs(k)/(N+2)
    else:
        Ffr = 7.75 if f0 == 50 else 8.19
        N = int(round((142 if f0 == 50 else 164)*fs/(16*f0))); N += N % 2; k = np.arange(-N//2, N//2+1)
        W = np.sinc(4*Ffr*k/fs)*np.hamming(len(k))        # np.sinc(x) = sin(pi x)/(pi x)
    return np.sqrt(2)*np.convolve(X, W/W.sum(), mode='same'), N


def pmu_freq_rocof(X, fs, f0):
    """Frequency and ROCOF from the phasor angle, Eqs. (D.3)-(D.4) at the internal sample rate."""
    th = np.unwrap(np.angle(X)); dt = 1/fs
    F = np.full(len(th), np.nan); RF = np.full(len(th), np.nan)
    F[1:-1] = f0 + (th[2:] - th[:-2])/(4*np.pi*dt)
    RF[1:-1] = (th[2:] + th[:-2] - 2*th[1:-1])/(2*np.pi*dt**2)
    F[0], F[-1] = F[1], F[-2]; RF[0], RF[-1] = RF[1], RF[-2]
    return F, RF


def pmu_frequency(y, fs, f0, cls='P'):
    """Single-phase application of the Annex D reference model: returns (frequency, N)."""
    X, N = pmu_phasor(y, fs, f0, cls)
    return pmu_freq_rocof(X, fs, f0)[0], N


def pmu_positive_sequence(ya, yb, yc, fs, f0, cls='P'):
    """Three-phase positive-sequence phasor, as specified by the standard (Clause D.4)."""
    a = np.exp(2j*np.pi/3)
    Xa, N = pmu_phasor(ya, fs, f0, cls); Xb, _ = pmu_phasor(yb, fs, f0, cls); Xc, _ = pmu_phasor(yc, fs, f0, cls)
    return (Xa + a*Xb + a*a*Xc)/3, N


def fsst(y, fs, nw=256, hop=4, nfft=4096, band=None):
    """Fourier synchrosqueezing: STFT with Hann window g and its derivative g', instantaneous
    frequency fhat = f - Im(S_g' / S_g)/(2 pi), energy reassigned to the nearest bin of fhat.
    Returns (frame centre times, frequency grid, squeezed magnitude T[f, t], magnitude-weighted sum
    of the reassigned frequencies Fw[f, t], used by ridge() for sub-bin estimates)."""
    g = np.hanning(nw); dg = np.gradient(g)*fs
    starts = np.arange(0, len(y)-nw+1, hop)
    fr = np.fft.rfftfreq(nfft, 1/fs); df = fr[1]-fr[0]
    T = np.zeros((len(fr), len(starts))); Fw = np.zeros_like(T)
    for j, s in enumerate(starts):
        seg = y[s:s+nw]
        Sg = np.fft.rfft(seg*g, nfft); Sd = np.fft.rfft(seg*dg, nfft)
        mag = np.abs(Sg); keep = mag > 1e-3*mag.max()
        fh = fr[keep] - np.imag(Sd[keep]/Sg[keep])/(2*np.pi)
        idx = np.clip(np.round(fh/df).astype(int), 0, len(fr)-1)
        np.add.at(T[:, j], idx, mag[keep]); np.add.at(Fw[:, j], idx, mag[keep]*fh)
    tc = (starts + nw/2)/fs
    if band is not None:
        m = (fr >= band[0]) & (fr <= band[1]); return tc, fr[m], T[m], Fw[m]
    return tc, fr, T, Fw


def ridge(tc, fr, T, Fw=None, half=3):
    """Single ridge: energy centroid of the squeezed magnitude within +-half bins of the
    column maximum (avoids the half-bin quantization of a plain argmax).
    Returns (times, frequency, magnitude)."""
    k = np.argmax(T, axis=0); fo = np.empty(T.shape[1]); mo = np.empty(T.shape[1])
    for j, kk in enumerate(k):
        a, b = max(kk-half, 0), min(kk+half+1, len(fr)); w = T[a:b, j]
        num = Fw[a:b, j].sum() if Fw is not None else np.sum(w*fr[a:b])
        fo[j] = num/max(w.sum(), 1e-30); mo[j] = w.sum()
    return tc, fo, mo


def top_peaks(fr, T, n=2, min_sep=15.0):
    """Per column, the n largest local maxima separated by at least min_sep Hz.
    Returns array (n, ncols) of frequencies (NaN where fewer peaks)."""
    out = np.full((n, T.shape[1]), np.nan)
    for j in range(T.shape[1]):
        col = T[:, j]; pk = np.where((col[1:-1] > col[:-2]) & (col[1:-1] >= col[2:]))[0] + 1
        pk = pk[np.argsort(col[pk])[::-1]]; sel = []
        for p in pk:
            if all(abs(fr[p]-fr[q]) >= min_sep for q in sel): sel.append(p)
            if len(sel) == n: break
        out[:len(sel), j] = fr[sel]
    return out


def ht_ipdft_track(y, fs, band, win, hop, return_amp=True):
    """Hilbert transform plus interpolated DFT (HT-IpDFT), after Frigo, Derviskadic and Paolone (2019):
    the analytic signal (FFT-based Hilbert transform of the record) removes the negative-frequency image,
    so that a short Hann-windowed DFT can be interpolated (two-point Hann IpDFT) without the self-
    interference that biases the real-signal IpDFT. Estimates are time-stamped at the window centers."""
    from scipy.signal import hilbert
    z = hilbert(y); w = 0.5 - 0.5*np.cos(2*np.pi*np.arange(win)/win); fr = np.arange(win)*fs/win
    kb = np.where((fr >= band[0]) & (fr <= band[1]))[0]; tc, fo, ao = [], [], []
    for s in range(0, len(z)-win+1, hop):
        Z = np.abs(np.fft.fft(z[s:s+win]*w)); k = kb[np.argmax(Z[kb])]
        if Z[k+1] >= Z[k-1]: a = Z[k+1]/Z[k]; d = (2*a-1)/(a+1)
        else: a = Z[k-1]/Z[k]; d = -(2*a-1)/(a+1)
        tc.append((s+win/2)/fs); fo.append((k+d)*fs/win)
        ao.append(Z[k]*np.pi*d*(1-d**2)/np.sin(np.pi*d)/w.sum() if abs(d) > 1e-9 else Z[k]/w.sum())
    return (np.array(tc), np.array(fo), np.array(ao)) if return_amp else (np.array(tc), np.array(fo))
