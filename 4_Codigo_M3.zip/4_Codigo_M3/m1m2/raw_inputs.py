"""raw_inputs.py -- the three converter inputs of the original MATLAB scripts, taken from the raw PicoScope
records (1.25 MHz): h1 = V_NoLISN_2V (EV 1), h2 = V_SiLISN_2V (EV 2), h3 = I_SiLISN_CP0.50VA_5V_5A (DER).
Each record is resampled to 4 kHz with a polyphase anti-aliasing filter (2/625), normalized to its fundamental
amplitude, and characterized (fundamental frequency and phase by least squares)."""
import os, numpy as np, scipy.io as sio
from scipy.signal import resample_poly
DATA = os.environ.get('M1M2_DATA', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'raw'))
FILES = {'h1': 'V_NoLISN_2V.mat', 'h2': 'V_SiLISN_2V.mat', 'h3': 'I_SiLISN_CP0.50VA_5V_5A.mat'}
FS = 4000.0
def fit_fund(x, t, f0=50.0):
    best = None
    for f in np.linspace(f0 - 0.2, f0 + 0.2, 401):
        M = np.column_stack([np.sin(2*np.pi*f*t), np.cos(2*np.pi*f*t)]); c, res, *_ = np.linalg.lstsq(M, x, rcond=None)
        r = float(np.sum((x - M@c)**2))
        if best is None or r < best[0]: best = (r, f, c)
    _, f, c = best
    for _ in range(30):                                     # refine frequency by Gauss-Newton on (a, b, f)
        s, co = np.sin(2*np.pi*f*t), np.cos(2*np.pi*f*t); J = np.column_stack([s, co, 2*np.pi*t*(c[0]*co - c[1]*s)])
        r = x - (c[0]*s + c[1]*co); d = np.linalg.lstsq(J, r, rcond=None)[0]; c = c + d[:2]; f = f + d[2]
        if abs(d[2]) < 1e-9: break
    return f, float(np.hypot(*c)), float(np.arctan2(c[1], c[0]))
def load(key, duration=None):
    d = sio.loadmat(os.path.join(DATA, FILES[key])); x = d['A'].ravel().astype(float); x[~np.isfinite(x)] = 0.0
    fs0 = 1/float(d['Tinterval'].ravel()[0]); y = resample_poly(x, 2, 625)          # 1.25 MHz -> 4 kHz
    if duration: y = y[:int(round(duration*FS))]
    t = np.arange(len(y))/FS; f1, A, ph = fit_fund(y, t)
    return dict(x=y/A, t=t, f1=f1, ph=ph, A_probe=A, fs0=fs0, T_raw=len(x)/fs0)
if __name__ == '__main__':
    for k in FILES:
        r = load(k); full = load(k)
        print(f"{k} ({FILES[k]}): registro crudo {r['T_raw']:.3f} s a {r['fs0']/1e6:.2f} MHz | f1 = {r['f1']:.5f} Hz | amplitud de la sonda {r['A_probe']:.4f} V")
