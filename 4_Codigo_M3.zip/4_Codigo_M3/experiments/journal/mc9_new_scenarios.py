"""mc9_new_scenarios.py -- review report M3, Sec. 3.3: intermittent bursts (U3), crossing
frequencies (U4) and a non-sinusoidal (notched) fundamental under a RoCoF ramp (U5).
30 dB SNR, 100 realizations for every method (CEEMDAN included)."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from scipy.signal import spectrogram
from mc_common import FS, A1, tvec, base, rocof_signal, add_noise, summarize
from methods.ground_truth import CONFIGS
from methods.extra_estimators import (bandpass, bandstop, analytic_if, ipdft_track, stft_track, vmd_modes,
                                       sogi_fll, cwt_track, esprit, esprit_track)
from methods.extra2 import fsst, ridge, top_peaks, pmu_frequency
from methods.hht_emd import emd_decompose
from PyEMD import CEEMDAN
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100; OUT = {}
sm = lambda f, n=20: np.convolve(f, np.ones(n)/n, mode='same')


def ceemdan(y, t, seed):
    c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(seed); return c.ceemdan(y, t)


# ---------------------------------------------------------------- U3: intermittent bursts
def intervals(tt, a, min_len=0.010):
    med = np.median(a); thr = med + 6*1.4826*np.median(np.abs(a-med)); on = a > thr; iv = []; i = 0
    while i < len(on):
        if on[i]:
            j = i
            while j < len(on) and on[j]: j += 1
            if tt[min(j, len(tt)-1)]-tt[i] >= min_len: iv.append((tt[i], tt[min(j, len(tt)-1)]))
            i = j
        else: i += 1
    return iv


def score_bursts(tt, a, f, starts, fb, dur=0.06):
    iv = intervals(tt, a); det, on_err, f_ok, used = 0, [], 0, set()
    for s in starts:
        hit = [k for k, (u, v) in enumerate(iv) if u < s+dur and v > s]
        if hit:
            det += 1; k = hit[0]; used.update(hit); on_err.append(abs(iv[k][0]-s))
            m = (tt >= max(iv[k][0], s)) & (tt <= min(iv[k][1], s+dur))
            if m.any() and abs(np.median(f[m])-fb)/fb < 0.01: f_ok += 1
    return det, len(iv)-len(used), on_err, f_ok


def U3():
    t = tvec(1.0); rng = np.random.default_rng(930); acc = {}
    for r in range(N):
        fb, ab = rng.uniform(150, 450), rng.uniform(0.10, 0.30)*A1
        starts = [0.15+rng.uniform(0, .05), 0.45+rng.uniform(0, .05), 0.75+rng.uniform(0, .05)]
        y = base(t)
        for s in starts:
            e = np.clip((t-s)/0.005, 0, 1)*np.clip((s+0.06-t)/0.005, 0, 1); e = 0.5-0.5*np.cos(np.pi*e)
            y = y + ab*e*np.sin(2*np.pi*fb*t + rng.uniform(-np.pi, np.pi))
        y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60); tr = {}
        a, f = analytic_if(bandpass(yn, FS, 60, 500), FS); tr['Notch+BP+Hilbert'] = (t, a, sm(f))
        tt, f, a = stft_track(yn, FS, (60, 500), nperseg=128, step=4, nfft=1024); tr['STFT'] = (tt, a, f)
        tc, f, a = ipdft_track(yn, FS, (60, 500), win=120, hop=8); tr['IpDFT'] = (tc, a, f)
        tc, fr, T, F = fsst(yn, FS, nw=128, hop=4, band=(60, 500)); tc, f, a = ridge(tc, fr, T, F); tr['FSST'] = (tc, a, f)
        u, c = vmd_modes(y, FS, 3); cand = [i for i in range(3) if 60 <= c[i] <= 500]
        if cand:
            i = max(cand, key=lambda i: np.std(u[i])); a, f = analytic_if(u[i], FS); tr['VMD (K=3)'] = (t, a, sm(f))
        for key, x, seed in [('CEEMDAN', y, 9300+r), ('FN-EMD', yn, 9500+r)]:
            best = None
            for imf in ceemdan(x, t, seed):
                a, f = analytic_if(imf, FS); hi = a > np.percentile(a, 80); mf = np.median(f[hi])
                if 60 <= mf <= 500 and (best is None or np.std(imf) > best[0]): best = (np.std(imf), a, sm(f))
            if best: tr[key] = (t, best[1], best[2])
        for k in ['Notch+BP+Hilbert', 'STFT', 'IpDFT', 'FSST', 'VMD (K=3)', 'CEEMDAN', 'FN-EMD']:
            d = acc.setdefault(k, {'det': 0, 'false': [], 'on': [], 'fok': 0, 'n': 0}); d['n'] += 3
            if k in tr:
                dt_, fb_, on_, fo_ = score_bursts(*tr[k], starts, fb); d['det'] += dt_; d['false'].append(fb_); d['on'] += on_; d['fok'] += fo_
            else: d['false'].append(0)
        if (r+1) % 25 == 0: print(f"  U3 {r+1}/{N}", flush=True)
    OUT['U3'] = {k: dict(detection=d['det']/d['n'], false_per_record=float(np.mean(d['false'])),
                         onset_err_ms=summarize(1000*np.array(d['on'])), freq_success=d['fok']/d['n']) for k, d in acc.items()}
    for k, v in OUT['U3'].items(): print('U3', k, f"det {100*v['detection']:.0f}% false/rec {v['false_per_record']:.2f} onset {v['onset_err_ms']['med']} ms freq_ok {100*v['freq_success']:.0f}%", flush=True)


# ---------------------------------------------------------------- U4: crossing frequencies
def U4():
    t = tvec(1.0); fc = 150 + 200*t; fl, fh = np.minimum(250, fc), np.maximum(250, fc)
    rng = np.random.default_rng(940); acc = {}
    ok_t = lambda tt: (tt >= 0.1) & (tt <= 0.9) & (np.abs(tt-0.5) > 0.08)
    def score(tt, pair):
        m = ok_t(tt); p = np.sort(pair[:, m], axis=0); lo, hi = np.interp(tt[m], t, fl), np.interp(tt[m], t, fh)
        miss = np.mean(~np.isfinite(p).all(axis=0))
        if miss > 0.2: return np.nan
        g = np.isfinite(p).all(axis=0); return float(np.sqrt(np.mean(np.concatenate([(p[0, g]-lo[g])**2, (p[1, g]-hi[g])**2]))))
    def imf_pair(modes):
        c = []
        for x in modes:
            a, f = analytic_if(x, FS); mf = np.median(f[(t > .1) & (t < .9)])
            if 100 <= mf <= 450: c.append((np.std(x), sm(f)))
        c = sorted(c, key=lambda q: -q[0])[:2]
        return np.vstack([q[1] for q in c]) if len(c) == 2 else None
    for r in range(N):
        y = base(t) + 0.2*A1*np.sin(2*np.pi*250*t + rng.uniform(-np.pi, np.pi)) + 0.2*A1*np.sin(2*np.pi*(150*t + 100*t**2) + rng.uniform(-np.pi, np.pi))
        y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60); res = {}
        f, tt, S = spectrogram(yn, fs=FS, nperseg=256, noverlap=248, window='hann', nfft=2048); b = (f >= 100) & (f <= 450)
        res['STFT'] = score(tt, top_peaks(f[b], S[b], 2, 10))
        tc, fr, T, F = fsst(yn, FS, nw=256, hop=8, band=(100, 450)); res['FSST'] = score(tc, top_peaks(fr, T, 2, 10))
        cen, pr = [], []
        for s in range(0, len(yn)-240+1, 16):
            fe, _, a = esprit(yn[s:s+240], FS, 12, L=120); k = (fe >= 100) & (fe <= 450)
            q = fe[k][np.argsort(a[k])[::-1][:2]] if k.sum() >= 2 else np.array([np.nan, np.nan])
            cen.append((s+120)/FS); pr.append(q)
        res['ESPRIT (sliding)'] = score(np.array(cen), np.array(pr).T)
        u, c = vmd_modes(y, FS, 4); p = imf_pair(u); res['VMD (K=4)'] = score(t, p) if p is not None else np.nan
        p = imf_pair(emd_decompose(t, yn, max_imfs=10)[:-1]); res['EMD'] = score(t, p) if p is not None else np.nan
        p = imf_pair(ceemdan(yn, t, 9700+r)); res['CEEMDAN'] = score(t, p) if p is not None else np.nan
        for k, v in res.items(): acc.setdefault(k, []).append(v)
        if (r+1) % 25 == 0: print(f"  U4 {r+1}/{N}", flush=True)
    OUT['U4'] = {k: dict(rmse=summarize(v), success=float(np.mean([np.isfinite(x) and x < 2 for x in v]))) for k, v in acc.items()}
    for k, v in OUT['U4'].items(): print('U4', k, f"median RMSE {v['rmse']['med']} Hz, success(<2 Hz) {100*v['success']:.0f}%", flush=True)


# ---------------------------------------------------------------- U5: notched fundamental under RoCoF
def U5():
    t, y0, ft = rocof_signal(); a1, _, p1 = CONFIGS['v1'][:3]
    ph = np.mod(2*np.pi*np.cumsum(ft)/FS + p1, np.pi/3); h = (ph > 0.5) & (ph < 0.5 + 2*np.pi*50*0.0006)
    y0 = y0*(1 - 0.3*h)                                  # six commutation notches per cycle, 30 % deep, 0.6 ms wide
    rng = np.random.default_rng(950); acc = {}
    def rm(tt, f, w): m = (tt >= w[0]) & (tt <= w[1]); return float(np.sqrt(np.mean((f[m]-np.interp(tt[m], t, ft))**2)))
    for r in range(N):
        y = add_noise(y0, 30, rng); tr = {}
        tr['PF+Hilbert'] = (t, analytic_if(bandpass(y, FS, 40, 60), FS)[1])
        tr['SOGI-FLL'] = (t, sogi_fll(bandpass(y, FS, 40, 60, causal=True), FS, 50.0)[0])
        tc, fi, _ = ipdft_track(y, FS, (40, 60), 240, 8); tr['IpDFT'] = (tc, fi)
        tr['P-class'] = (t, pmu_frequency(y, FS, 50.0, 'P')[0]); tr['M-class'] = (t, pmu_frequency(y, FS, 50.0, 'M')[0])
        tc, fe = esprit_track(y, FS, 50, 12, win=160, hop=16); tr['ESPRIT'] = (tc, fe)
        tr['CWT (L1)'] = (t, cwt_track(y, FS, 40, 60))
        tc, fr, T, F = fsst(y, FS, band=(40, 60)); tc, fe, _ = ridge(tc, fr, T, F); tr['FSST'] = (tc, fe)
        u, c = vmd_modes(y, FS, 3); tr['VMD+Hilbert'] = (t, analytic_if(u[np.argmin(abs(c-50))], FS)[1])
        best = min((analytic_if(i, FS)[1] for i in ceemdan(y, t, 9900+r)), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50))
        tr['Full HHT (CEEMDAN)'] = (t, best)
        for k, (tt, f) in tr.items(): acc.setdefault(k, []).append((rm(tt, f, (.4, .55)), rm(tt, f, (.6, .8))))
        if (r+1) % 25 == 0: print(f"  U5 {r+1}/{N}", flush=True)
    OUT['U5'] = {k: {'ramp': summarize([a for a, b in v]), 'settled': summarize([b for a, b in v])} for k, v in acc.items()}
    for k, v in OUT['U5'].items(): print('U5', k, f"ramp {v['ramp']['med']:.3f} settled {v['settled']['med']:.3f}", flush=True)


if __name__ == '__main__':
    t0 = time.time()
    P = os.path.join(os.path.dirname(__file__), 'res_mc9_new_scenarios.json')
    if os.path.exists(P): OUT.update(json.load(open(P)))
    todo = sys.argv[2].split(',') if len(sys.argv) > 2 else ['U5', 'U3', 'U4']
    for f in [{'U3': U3, 'U4': U4, 'U5': U5}[k] for k in todo]:
        f(); json.dump(OUT, open(os.path.join(os.path.dirname(__file__), 'res_mc9_new_scenarios.json'), 'w'), indent=1)
    print(f"done {time.time()-t0:.0f}s")
