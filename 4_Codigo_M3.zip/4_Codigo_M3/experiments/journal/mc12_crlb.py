"""mc12_crlb.py -- bias, standard deviation and RMSE of the f2 estimate in Scenario S versus the
single-tone Cramer-Rao lower bound (real sinusoid in white noise):
var(f) >= 12 fs^2 / ((2 pi)^2 eta N (N^2 - 1)),  eta = a2^2 / (2 sigma^2).  100 realizations."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np, rlib
from mc_common import FS
from methods.ground_truth import CONFIGS, y_model, time_vector
from methods.fft_welch import estimate_all_tones_sequential as fft_seq
from methods.extra_estimators import ipdft_sequential, cwt_sequential, esprit, bandpass, bandstop, analytic_if, sogi_fll
from methods.extra2 import matrix_pencil
t = time_vector(); m = (t > 0.05) & (t < 0.45); N = len(t)
for snr in [60, 30]:
    for node in ['v1', 'v3', 'v2']:
        key = f'{snr}_{node}'; th = CONFIGS[node]; f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5); bands = [(35, 65), b2, (th[7]*0.7, th[7]*1.3)]
        y0 = y_model(th, t); have = rlib.done('crlb')
        for r in range(100):
            if (key, r) in have: continue
            rng = np.random.default_rng(120000 + 1000*snr + 10*int(node[1]) + r); sig2 = np.mean(y0**2)/10**(snr/10)
            y = y0 + rng.normal(0, np.sqrt(sig2), N); est = {}
            est['FFT'] = fft_seq(t, y, FS, bands)[1][0]; est['IpDFT'] = ipdft_sequential(y, t, FS, bands)[1]
            est['CWT (L1)'] = cwt_sequential(y, t, FS, bands)[1]
            for k, fn in [('ESPRIT', lambda: esprit(y, FS, 6)), ('Matrix Pencil', lambda: matrix_pencil(y, FS, 6))]:
                f, _, _ = fn(); est[k] = float(f[np.argmin(abs(f-f2))]) if len(f) else None
            x = bandpass(bandstop(y, FS, 40, 60), FS, *b2); est['PF+Hilbert'] = float(np.median(analytic_if(x, FS)[1][m]))
            est['SOGI-FLL'] = float(np.median(sogi_fll(x, FS, np.mean(b2))[0][t > 0.25]))
            rlib.save('crlb', dict(key=key, r=r, f2=f2, a2=abs(th[3]), sig2=sig2, N=N, est={k: (None if v is None else float(v)) for k, v in est.items()}))
        print('crlb', key, flush=True)
