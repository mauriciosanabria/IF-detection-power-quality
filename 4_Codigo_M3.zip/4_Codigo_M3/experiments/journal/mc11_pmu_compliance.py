"""mc11_pmu_compliance.py -- checks that our implementation of the IEC/IEEE 60255-118-1:2018
Annex D reference model meets the standard's frequency/ROCOF limits (Tables 3 and 7) under its
own test conditions: balanced three-phase signals, positive sequence, f0 = 50 Hz, Fs = 50 fps,
noise-free, fs = 4 kHz. Errors are evaluated at the reporting instants (every 20 ms).
Harmonic tests are limited to orders 2-39 (higher orders exceed the 2 kHz Nyquist frequency)."""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from methods.extra2 import pmu_positive_sequence, pmu_freq_rocof
FS, F0, FR = 4000.0, 50.0, 50
LIM = {'P': dict(ss_fe=0.005, ss_rfe=0.4, h_fe=0.005, h_rfe=0.4, h_lvl=0.01, r_fe=0.01, r_rfe=0.4, r_range=2.0, excl=2/F0),
       'M': dict(ss_fe=0.005, ss_rfe=0.1, h_fe=0.025, h_rfe=None, h_lvl=0.10, r_fe=0.01, r_rfe=0.2, r_range=5.0, excl=7/FR)}

def three_phase(phase_fn, harm=None, T=3.0):
    t = np.arange(int(FS*T))/FS; ph = phase_fn(t); out = []
    for s in (0, -2*np.pi/3, 2*np.pi/3):
        y = np.cos(ph + s)
        if harm: y = y + harm[1]*np.cos(harm[0]*(ph + s))
        out.append(y)
    return t, out

def errors(t, ys, cls, f_true, r_true, mask):
    X, N = pmu_positive_sequence(*ys, FS, F0, cls); F, RF = pmu_freq_rocof(X, FS, F0)
    rep = np.zeros(len(t), bool); rep[::int(FS/FR)] = True
    m = rep & mask & (t > N/FS) & (t < t[-1]-N/FS)
    return float(np.max(np.abs(F[m]-f_true(t[m])))), float(np.max(np.abs(RF[m]-r_true(t[m])))), N

out = {}
for cls, L in LIM.items():
    res = {}; ss = []
    for df in np.arange(-L['r_range'], L['r_range']+1e-9, 0.5):
        t, ys = three_phase(lambda t: 2*np.pi*(F0+df)*t)
        ss.append(errors(t, ys, cls, lambda q: F0+df+0*q, lambda q: 0*q, np.ones(len(t), bool))[:2])
    res['steady'] = dict(FE=max(a for a, b in ss), RFE=max(b for a, b in ss))
    hh = []
    for h in range(2, 40):
        t, ys = three_phase(lambda t: 2*np.pi*F0*t, harm=(h, L['h_lvl']))
        hh.append(errors(t, ys, cls, lambda q: F0+0*q, lambda q: 0*q, np.ones(len(t), bool))[:2])
    res['harmonics'] = dict(FE=max(a for a, b in hh), RFE=max(b for a, b in hh))
    rr = []
    for sgn in (+1, -1):
        Rf = sgn*1.0; T = 2*L['r_range']/1.0 + 2.0; f_start = F0 - sgn*L['r_range']; t1 = 1.0; t2 = t1 + 2*L['r_range']
        def fin(t): return np.clip(f_start + Rf*(t-t1)*((t > t1)), min(f_start, f_start+Rf*(t2-t1)), max(f_start, f_start+Rf*(t2-t1)))
        def phase(t): return 2*np.pi*np.cumsum(fin(t))/FS
        t, ys = three_phase(phase, T=T)
        mask = (t > t1+L['excl']) & (t < t2-L['excl'])
        rr.append(errors(t, ys, cls, fin, lambda q: Rf+0*q, mask)[:2])
    res['ramp'] = dict(FE=max(a for a, b in rr), RFE=max(b for a, b in rr))
    ok = (res['steady']['FE'] <= L['ss_fe'] and res['steady']['RFE'] <= L['ss_rfe'] and res['harmonics']['FE'] <= L['h_fe']
          and (L['h_rfe'] is None or res['harmonics']['RFE'] <= L['h_rfe']) and res['ramp']['FE'] <= L['r_fe'] and res['ramp']['RFE'] <= L['r_rfe'])
    res['limits'] = L; res['all_pass'] = bool(ok); out[cls] = res
    print(cls, {k: (round(v['FE'], 5), round(v['RFE'], 4)) for k, v in res.items() if isinstance(v, dict) and 'FE' in v}, 'PASS' if ok else 'FAIL', flush=True)
json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc11_pmu_compliance.json'), 'w'), indent=1)
