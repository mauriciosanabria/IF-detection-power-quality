"""mc14_sensitivity.py -- sensitivity of the Scenario R ranking (30 dB, ramp and settled RMSE) to the
main tuning parameter of each method, 30 realizations per configuration (same noise for all)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np, rlib
from mc_common import FS, rocof_signal, add_noise
from methods.extra_estimators import bandpass, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track, vmd_modes
from PyEMD import CEEMDAN
t, y0, ft = rocof_signal()
def rm(tt, f):
    o = []
    for a, b in [(.4, .55), (.6, .8)]:
        mm = (tt >= a) & (tt <= b); o.append(float(np.sqrt(np.mean((f[mm]-np.interp(tt[mm], t, ft))**2))))
    return o
def hht(y, eps, tr, r):
    c = CEEMDAN(trials=tr, epsilon=eps, parallel=False); c.noise_seed(140000+r); imfs = c.ceemdan(y, t)
    return min((analytic_if(i, FS)[1] for i in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50))
C = {}
for o in [2, 4, 6]:
    for hw in [5, 10, 20]: C[f'PF+Hilbert|order={o},band=50±{hw} Hz'] = (lambda y, o=o, hw=hw: rm(t, analytic_if(bandpass(y, FS, 50-hw, 50+hw, order=o), FS)[1]))
for cyc in [2, 3, 5]: C[f'IpDFT|window={cyc} cycles'] = (lambda y, cyc=cyc: rm(*ipdft_track(y, FS, (40, 60), int(80*cyc), 8)[:2]))
for g in [20, 50, 150]: C[f'SOGI-FLL|Gamma={g}'] = (lambda y, g=g: rm(t, sogi_fll(y, FS, 50.0, gamma=g)[0]))
for ms in [20, 40, 80]: C[f'ESPRIT|window={ms} ms'] = (lambda y, ms=ms: rm(*esprit_track(y, FS, 50, 6, int(4*ms), 16)))
for wv in ['cmor1.0-1.0', 'cmor1.5-1.0', 'cmor3.0-1.0']: C[f'CWT|wavelet={wv}'] = (lambda y, wv=wv: rm(t, cwt_track(y, FS, 40, 60, wavelet=wv)))
for al in [500, 2000, 5000]:
    for K in [3, 4]: C[f'VMD|alpha={al},K={K}'] = (lambda y, al=al, K=K: (lambda u_c: rm(t, analytic_if(u_c[0][np.argmin(abs(u_c[1]-50))], FS)[1]))(vmd_modes(y, FS, K, alpha=al)))
for eps in [0.02, 0.05, 0.2]: C[f'CEEMDAN|epsilon={eps},trials=30'] = ('hht', eps, 30)
C['CEEMDAN|epsilon=0.05,trials=10'] = ('hht', 0.05, 10)
have = rlib.done('sens')
for r in range(30):
    y = add_noise(y0, 30, np.random.default_rng(140000 + r))
    for k, fn in C.items():
        if (k, r) in have: continue
        v = rm(t, hht(y, fn[1], fn[2], r)) if isinstance(fn, tuple) else fn(y)
        rlib.save('sens', dict(key=k, r=r, ramp=v[0], settled=v[1]))
    print('sens', r, flush=True)
