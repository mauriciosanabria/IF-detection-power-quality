"""timing.py -- median wall-clock time per call of each estimator on the 1 s Scenario R record (single core)."""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, rocof_signal, add_noise
from methods.extra_estimators import bandpass, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track, vmd_modes
from methods.hht_emd import emd_decompose
from PyEMD import CEEMDAN
t, y0, _ = rocof_signal(); y = add_noise(y0, 30, np.random.default_rng(1))
def ce(): c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(0); return c.ceemdan(y, t)
M = {'PF+Hilbert': lambda: analytic_if(bandpass(y, FS, 40, 60), FS),
     'IpDFT (sliding)': lambda: ipdft_track(y, FS, (40, 60), 240, 8),
     'SOGI-FLL': lambda: sogi_fll(y, FS, 50.0),
     'CWT (L1)': lambda: cwt_track(y, FS, 40, 60),
     'ESPRIT (sliding)': lambda: esprit_track(y, FS, 50, 6, 160, 16),
     'VMD (K=3)': lambda: vmd_modes(y, FS, 3),
     'EMD': lambda: emd_decompose(t, y, max_imfs=10),
     'CEEMDAN (30 trials)': ce}
out = {}
for k, f in M.items():
    n = 3 if 'CEEMDAN' in k else 7; ts = []
    for _ in range(n):
        a = time.perf_counter(); f(); ts.append(time.perf_counter()-a)
    out[k] = float(np.median(ts)); print(f"{k:22s} {1000*out[k]:9.1f} ms", flush=True)
json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_timing.json'), 'w'), indent=1)
