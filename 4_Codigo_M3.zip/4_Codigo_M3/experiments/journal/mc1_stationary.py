"""mc1_stationary.py -- f2 resolution at nodes v1/v2/v3, 30 dB SNR.
Success = relative error < 1 %. Fast methods: 100 realizations; CEEMDAN-based: 30."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, add_noise, summarize
from methods.ground_truth import CONFIGS, y_model, time_vector
from methods.fft_welch import estimate_all_tones_sequential as fft_seq
from methods.hht_emd import estimate_all_tones_hht
from methods.extra_estimators import (ipdft_sequential, cwt_sequential, esprit, bandpass, bandstop,
                                       analytic_if, sogi_fll, vmd_modes)
from PyEMD import CEEMDAN

N_FAST, N_EMD = int(sys.argv[1]) if len(sys.argv) > 1 else 100, int(sys.argv[2]) if len(sys.argv) > 2 else 30


def band_imf(imfs, fs, band, m):
    best, amp = None, -1
    for imf in imfs:
        _, f = analytic_if(imf, fs)
        med = np.median(f[m])
        if band[0] <= med <= band[1] and np.std(imf) > amp:
            best, amp = med, np.std(imf)
    return best


def run():
    t = time_vector(); m = (t > 0.05) & (t < 0.45)
    out = {}
    for SNR in [30, 60]:
     out[SNR] = {}
     for node, th in CONFIGS.items():
        f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5)
        bands = [(35, 65), b2, (th[7]*0.7, th[7]*1.3)]
        rng = np.random.default_rng(100*SNR + list(CONFIGS).index(node))
        errs = {k: [] for k in ['FFT-seq', 'IpDFT-seq', 'CWT-seq (L1)', 'ESPRIT', 'SOGI-FLL', 'PF+Hilbert',
                                'VMD (K=4)', 'FN-VMD (K=3)', 'EMD', 'CEEMDAN', 'FN-EMD']}
        y0 = y_model(th, t)
        for r in range(N_FAST):
            y = add_noise(y0, SNR, rng)
            e = lambda f: np.nan if f is None else 100*abs(f-f2)/f2
            errs['FFT-seq'].append(e(fft_seq(t, y, FS, bands)[1][0]))
            errs['IpDFT-seq'].append(e(ipdft_sequential(y, t, FS, bands)[1]))
            errs['CWT-seq (L1)'].append(e(cwt_sequential(y, t, FS, bands)[1]))
            fe, _, a = esprit(y, FS, 6); errs['ESPRIT'].append(e(fe[np.argmin(abs(fe-np.mean(b2)))]) if len(fe) else np.nan)
            x = bandpass(bandstop(y, FS, 40, 60), FS, *b2)
            _, fi = analytic_if(x, FS); errs['PF+Hilbert'].append(e(np.median(fi[m])))
            so, _ = sogi_fll(x, FS, np.mean(b2)); errs['SOGI-FLL'].append(e(np.median(so[t > 0.25])))
            for key, K, pre in [('VMD (K=4)', 4, False), ('FN-VMD (K=3)', 3, True)]:
                u, c = vmd_modes(bandstop(y, FS, 40, 60) if pre else y, FS, K)
                inb = [i for i in range(K) if b2[0] <= c[i] <= b2[1]]
                if inb:
                    i = max(inb, key=lambda i: np.std(u[i])); _, fv = analytic_if(u[i], FS)
                    errs[key].append(e(np.median(fv[m])))
                else:
                    errs[key].append(np.nan)
            est, _ = estimate_all_tones_hht(t, y, bands); errs['EMD'].append(e(est[1][0]))
            if r < N_EMD:
                for key, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
                    c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(1000+r)
                    imfs = c.ceemdan(bandstop(y, FS, 40, 60) if pre else y, t)
                    errs[key].append(e(band_imf(imfs, FS, b2, m)))
        out[SNR][node] = {}
        for k, v in errs.items():
            v = np.array(v, float); ok = np.isfinite(v) & (v < 1.0)
            out[SNR][node][k] = dict(runs=int(len(v)), success=float(ok.mean()), **summarize(v))
        print(SNR, node, {k: f"{100*d['success']:.0f}%" for k, d in out[SNR][node].items()}, flush=True)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc1_stationary.json'), 'w'), indent=1)


if __name__ == '__main__':
    t0 = time.time(); run(); print(f"done {time.time()-t0:.0f}s")
