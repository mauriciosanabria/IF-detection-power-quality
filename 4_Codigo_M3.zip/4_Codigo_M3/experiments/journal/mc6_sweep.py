"""mc6_sweep.py -- Scenario P: parametric sweep, independent of any case-study table.
y = a1 sin(2 pi 50 t) + r a1 sin(2 pi f2 t + phi) + noise (40 dB), 0.5 s, fs = 4 kHz.
r in 9 amplitude ratios x f2 in 7 frequencies = 63 cells. Success = |f2 error| < 1 %.
Band-prior methods get f2*[0.7, 1.3]; VMD/EMD/CEEMDAN pick the mode/IMF whose median IF lies there.
Fast methods: 20 realizations per cell; CEEMDAN (20 trials): 5 per cell."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, A1, tvec, add_noise
from methods.extra_estimators import ipdft_sequential, esprit, bandpass, bandstop, analytic_if, vmd_modes
from methods.hht_emd import emd_decompose
from PyEMD import CEEMDAN
R = [0.0005, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10, 0.20, 0.50]
F2 = [70, 100, 150, 250, 400, 650, 1000]
NF, NE = 20, 5
t = tvec(0.5); m = (t > 0.05) & (t < 0.45)
def med_if(x): return float(np.median(analytic_if(x, FS)[1][m]))
def pick(modes, band):
    c = [(np.std(x), med_if(x)) for x in modes]
    c = [(s, f) for s, f in c if band[0] <= f <= band[1]]
    return max(c)[1] if c else np.nan
out = []; rng = np.random.default_rng(66); t0 = time.time()
for r in R:
    for f2 in F2:
        band = (0.7*f2, 1.3*f2); res = {k: [] for k in ['IpDFT', 'ESPRIT', 'PF+Hilbert', 'VMD', 'EMD', 'CEEMDAN']}
        for k in range(NF):
            y = add_noise(A1*np.sin(2*np.pi*50*t) + r*A1*np.sin(2*np.pi*f2*t + rng.uniform(-np.pi, np.pi)), 40, rng)
            e = lambda f: 100*abs(f-f2)/f2 if np.isfinite(f) else np.nan
            res['IpDFT'].append(e(ipdft_sequential(y, t, FS, [(35, 65), band])[1]))
            fe, _, _ = esprit(y, FS, 4, L=200); res['ESPRIT'].append(e(fe[np.argmin(abs(fe-f2))]) if len(fe) else np.nan)
            res['PF+Hilbert'].append(e(med_if(bandpass(bandstop(y, FS, 40, 60), FS, *band))))
            u, c = vmd_modes(y, FS, 2); res['VMD'].append(e(pick(u, band)))
            res['EMD'].append(e(pick(emd_decompose(t, y, max_imfs=10)[:-1], band)))
            if k < NE:
                ce = CEEMDAN(trials=20, epsilon=0.05, parallel=False); ce.noise_seed(600+k)
                res['CEEMDAN'].append(e(pick(ce.ceemdan(y, t), band)))
        row = dict(r=r, f2=f2, rho=r*f2/50)
        for kk, v in res.items():
            v = np.array(v, float); row[kk] = float(np.mean(np.isfinite(v) & (v < 1)))
        out.append(row)
        print(f"r={100*r:5.2f}% f2={f2:4d} rho={r*f2/50:6.3f} " + ' '.join(f"{kk}:{100*row[kk]:3.0f}" for kk in res), flush=True)
json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc6_sweep.json'), 'w'), indent=1)
print(f"done {time.time()-t0:.0f}s")
