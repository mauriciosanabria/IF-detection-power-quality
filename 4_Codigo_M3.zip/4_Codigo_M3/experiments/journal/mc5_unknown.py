"""mc5_unknown.py -- scenarios that do NOT give any method a band prior (review report M3, Sec. 3.3).
All methods may only assume the nominal fundamental (50 Hz, e.g. from a PLL) and a generic
search range of 60-500 Hz (E1) or 60-600 Hz (E2).

E1: v1 base + interharmonic of UNKNOWN frequency f_u ~ U(70, 450) Hz and amplitude
    a_u ~ U(10, 30) % of a1, random phase. Success = |f error| < 1 %. The slope ratio
    rho = a_u f_u / (a1 f1) is stored to test the prediction that EMD separates a component
    only when rho > 1.
E2: v1 base + linear chirp 150 -> 400 Hz over the 0.6 s record, amplitude 40 % of a1
    (rho >= 1.2 throughout, i.e. the EMD-separable regime). Metric: IF RMSE over 100-500 ms.
30 dB SNR, 100 realizations per scenario, every method."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, A1, F1, tvec, base, add_noise, summarize
from methods.extra_estimators import (bandstop, bandpass, highpass, analytic_if, ipdft_peak, ipdft_track, fit_sinusoid,
                                       esprit, vmd_modes, cwt_track, stft_track)
from methods.hht_emd import emd_decompose
from PyEMD import CEEMDAN

N = int(sys.argv[1]) if len(sys.argv) > 1 else 100


def pick_imf(imfs, lo, hi, m):
    best, e = None, -1
    for imf in imfs:
        _, f = analytic_if(imf, FS); md = np.median(f[m])
        if lo <= md <= hi and np.std(imf) > e:
            best, e = imf, np.std(imf)
    return best


def e1():
    t = tvec(0.5); m = (t > 0.05) & (t < 0.45); rng = np.random.default_rng(51)
    rows = []
    for r in range(N):
        fu, au, ph = rng.uniform(70, 450), rng.uniform(0.10, 0.30)*A1, rng.uniform(-np.pi, np.pi)
        y = add_noise(base(t) + au*np.sin(2*np.pi*fu*t+ph), 30, rng)
        est = {}
        f1 = ipdft_peak(y, FS, (35, 65)); comp, _ = fit_sinusoid(y, t, f1); est['IpDFT'] = ipdft_peak(y-comp, FS, (60, 500))
        fe, s, a = esprit(y, FS, 10); k = (fe > 60) & (fe < 500)
        est['ESPRIT'] = float(fe[k][np.argmax(a[k])]) if k.any() else np.nan
        _, fi = analytic_if(bandpass(bandstop(y, FS, 40, 60), FS, 60, 500), FS); est['Notch+BP+Hilbert'] = float(np.median(fi[m]))
        u, c = vmd_modes(y, FS, 4); inb = [i for i in range(4) if 60 <= c[i] <= 500]
        if inb:
            i = max(inb, key=lambda i: np.std(u[i])); _, fv = analytic_if(u[i], FS); est['VMD (K=4)'] = float(np.median(fv[m]))
        else:
            est['VMD (K=4)'] = np.nan
        imf = pick_imf(emd_decompose(t, y, max_imfs=10)[:-1], 60, 500, m)
        est['EMD'] = np.nan if imf is None else float(np.median(analytic_if(imf, FS)[1][m]))
        for key, pre in ([('CEEMDAN', False), ('FN-EMD', True)] if r < 30 else [('CEEMDAN', None), ('FN-EMD', None)]):
            if pre is None:
                est[key] = np.nan; continue
            ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(11000+r)
            imf = pick_imf(ce.ceemdan(bandstop(y, FS, 40, 60) if pre else y, t), 60, 500, m)
            est[key] = np.nan if imf is None else float(np.median(analytic_if(imf, FS)[1][m]))
        rows.append(dict(fu=fu, rho=au*fu/(A1*F1), **{k: 100*abs(v-fu)/fu for k, v in est.items()}))
        if (r+1) % 20 == 0:
            print(f"  E1 {r+1}/{N}", flush=True)
    methods = [k for k in rows[0] if k not in ('fu', 'rho')]
    out = {}
    for k in methods:
        sub = rows[:30] if k in ('CEEMDAN', 'FN-EMD') else rows
        err = np.array([row[k] for row in sub], float); rho = np.array([row['rho'] for row in sub])
        ok = np.isfinite(err) & (err < 1)
        out[k] = dict(success=float(ok.mean()), success_rho_gt1=float(ok[rho > 1].mean()),
                      success_rho_lt1=float(ok[rho <= 1].mean()), err=summarize(err))
        print('E1', k, f"success {100*ok.mean():.0f}% | rho>1: {100*ok[rho > 1].mean():.0f}% | rho<=1: {100*ok[rho <= 1].mean():.0f}%", flush=True)
    out['_n_rho_gt1'] = int(sum(r['rho'] > 1 for r in rows)); out['_rows'] = rows
    return out


def e2():
    T = 0.6; t = tvec(T); fa, fb = 150.0, 400.0; k = (fb-fa)/T
    ftrue = fa + k*t; ac = 0.40*A1
    y0 = base(t) + ac*np.sin(2*np.pi*(fa*t + 0.5*k*t**2))
    ev = (t >= 0.10) & (t <= 0.50); rng = np.random.default_rng(52); res = {}
    sm = lambda f: np.convolve(f, np.ones(20)/20, mode='same')   # 5 ms IF smoothing, applied to every Hilbert-based tracker
    def add(key, tt, f):
        mm = (tt >= 0.10) & (tt <= 0.50)
        res.setdefault(key, []).append(float(np.sqrt(np.mean((f[mm]-np.interp(tt[mm], t, ftrue))**2))))
    for r in range(N):
        y = add_noise(y0, 30, rng); yn = bandstop(y, FS, 40, 60)
        _, f = analytic_if(bandpass(yn, FS, 60, 600), FS); add('Notch+BP+Hilbert', t, sm(f))
        add('CWT (L1)', t, cwt_track(yn, FS, 60, 600, n=400))
        tc, f, _ = stft_track(yn, FS, (60, 600), nperseg=128, step=4); add('STFT', tc, f)
        tc, f, _ = ipdft_track(yn, FS, (60, 600), win=120, hop=8); add('IpDFT', tc, f)
        u, c = vmd_modes(y, FS, 3); inb = [i for i in range(3) if 60 <= c[i] <= 600]
        if inb:
            i = max(inb, key=lambda i: np.std(u[i])); add('VMD (K=3)', t, sm(analytic_if(u[i], FS)[1]))
        else:
            res.setdefault('VMD (K=3)', []).append(np.nan)
        imf = pick_imf(emd_decompose(t, y, max_imfs=10)[:-1], 60, 600, ev)
        if imf is None: res.setdefault('EMD', []).append(np.nan)
        else: add('EMD', t, sm(analytic_if(imf, FS)[1]))
        for key, pre in ([('CEEMDAN', False), ('FN-EMD', True)] if r < 30 else []):
            ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(13000+r)
            imf = pick_imf(ce.ceemdan(yn if pre else y, t), 60, 600, ev)
            if imf is None: res.setdefault(key, []).append(np.nan)
            else: add(key, t, sm(analytic_if(imf, FS)[1]))
        if (r+1) % 20 == 0:
            print(f"  E2 {r+1}/{N}", flush=True)
    out = {k: summarize(v) for k, v in res.items()}
    for k, v in out.items():
        print('E2', k, f"IF RMSE median {v['med']:.2f} Hz  [IQR {v['p25']:.2f}-{v['p75']:.2f}]", flush=True)
    return out


if __name__ == '__main__':
    t0 = time.time()
    out = {'E1': e1(), 'E2': e2()}
    json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc5_unknown.json'), 'w'), indent=1)
    print(f"done {time.time()-t0:.0f}s")
