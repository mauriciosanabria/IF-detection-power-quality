import json, numpy as np, rlib, sys
FS = 4000.0; out = {}
# ---------------- CRLB
rows = rlib.load('crlb')
if rows:
    out['crlb'] = {}
    for key in sorted({r['key'] for r in rows}):
        R = [r for r in rows if r['key'] == key]; f2, a2, s2, N = R[0]['f2'], R[0]['a2'], R[0]['sig2'], R[0]['N']
        eta = a2**2/(2*s2); crlb = np.sqrt(12*FS**2/((2*np.pi)**2*eta*N*(N**2-1))); out['crlb'][key] = {'crlb': crlb, 'n': len(R)}
        for m in R[0]['est']:
            e = np.array([np.nan if r['est'][m] is None else r['est'][m]-f2 for r in R]); ok = np.abs(e) < 0.01*f2
            out['crlb'][key][m] = dict(succ=float(ok.mean()), bias=float(np.mean(e[ok])) if ok.sum() > 2 else None, std=float(np.std(e[ok])) if ok.sum() > 2 else None)
# ---------------- semi-synthetic
for nm in ['semi_R', 'semi_G']:
    rows = rlib.load(nm)
    if not rows: continue
    meths = sorted({k for r in rows for k in r['res']}); out[nm] = {}
    for m in meths:
        v = [r['res'][m] for r in rows if m in r['res']]
        if nm == 'semi_R': out[nm][m] = dict(n=len(v), ramp=float(np.median([x[0] for x in v])), settled=float(np.median([x[1] for x in v])))
        else:
            d = [x[0] for x in v]; fa = np.mean([x[1] for x in v]); det = np.mean([x is not None for x in d]); g = [x[2] for x in v if x[2] is not None]
            out[nm][m] = dict(n=len(v), det=float(det), fa=float(fa), delay=float(1000*np.median([x for x in d if x is not None])) if any(x is not None for x in d) else None, growth=float(np.median(g)) if g else None)
rf = rlib.load('real_f')
if rf: out['real_f'] = {r['key']: dict(est=r['est'], residual=r['residual_pct']) for r in rf}
# ---------------- sensitivity
rows = rlib.load('sens')
if rows:
    out['sens'] = {}
    for k in sorted({r['key'] for r in rows}):
        v = [r for r in rows if r['key'] == k]; out['sens'][k] = dict(n=len(v), ramp=float(np.median([x['ramp'] for x in v])), settled=float(np.median([x['settled'] for x in v])))
json.dump(out, open('res_round6.json', 'w'), indent=1)
if 'crlb' in out:
    print('CRLB [Hz] y desv. est. (eficiencia = CRLB/std) por condición:')
    for key, d in out['crlb'].items():
        print(f"  {key}: CRLB={d['crlb']:.2e} Hz (n={d['n']}) | " + '; '.join(f"{m}: éxito {100*v['succ']:.0f}%, std {v['std']:.2e}, sesgo {v['bias']:+.1e}" if v['std'] is not None else f"{m}: éxito {100*v['succ']:.0f}%" for m, v in d.items() if isinstance(v, dict)))
for nm in ['semi_R', 'semi_G', 'real_f']:
    if nm in out: print(nm, json.dumps(out[nm], indent=None)[:1500])
if 'sens' in out: print('sens', {k: (v['n'], round(v['ramp'], 3)) for k, v in out['sens'].items()})
