"""rlib.py -- resumable per-realization storage: one JSON line per (key, r)."""
import json, os
D = os.path.dirname(os.path.abspath(__file__))
def path(name): return os.path.join(D, f"{name}{os.environ.get('RLIB_SUFFIX', '')}.jsonl")
def done(name):
    p = path(name); s = set()
    if os.path.exists(p):
        for l in open(p):
            try: d = json.loads(l); s.add((d['key'], d['r']))
            except Exception: pass
    return s
def save(name, row):
    with open(path(name), 'a') as fh: fh.write(json.dumps(row) + '\n'); fh.flush(); os.fsync(fh.fileno())
def load(name):
    return [json.loads(l) for l in open(path(name))] if os.path.exists(path(name)) else []
