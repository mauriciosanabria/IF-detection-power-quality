"""
mc_common.py -- shared pieces for the journal-revision Monte Carlo study.

Redesigned scenarios (review report M3, Sec. 3.5): every event now sits away from the
record edges, so that no method is penalized by boundary effects of the FFT-based
Hilbert transform, zero-phase filtering or the CWT.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from methods.ground_truth import CONFIGS

FS = 4000.0
A1, F1 = 127.84, 50.0


def tvec(T):
    return np.arange(int(round(FS*T)))/FS


def base(t, node='v1', with_f1=True):
    a1, f1, p1, a2, f2, p2, a3, f3, p3 = CONFIGS[node]
    y = a2*np.sin(2*np.pi*f2*t+p2) + a3*np.sin(2*np.pi*f3*t+p3)
    return y + (a1*np.sin(2*np.pi*f1*t+p1) if with_f1 else 0)


def rocof_signal(T=1.0, t_start=0.40, dur=0.15, rocof=-4.0):
    """1.0 s record; -4 Hz/s ramp from 400 to 550 ms; settles at 49.4 Hz."""
    t = tvec(T)
    f = np.full_like(t, 50.0)
    r = (t >= t_start) & (t < t_start+dur)
    f[r] = 50.0 + rocof*(t[r]-t_start)
    f[t >= t_start+dur] = 50.0 + rocof*dur
    a1, _, p1 = CONFIGS['v1'][:3]
    y = a1*np.sin(2*np.pi*np.cumsum(f)/FS + p1) + base(t, 'v1', with_f1=False)
    return t, y, f


def growing_signal(T=1.05, t0=0.50, f=110.0, A0=0.6, g=6.0):
    """Super-synchronous (110 Hz > 50 Hz) oscillation growing at g [1/s] from onset t0.
    Onset at 500 ms so causal estimators are fully settled (continuous-operation monitor)."""
    t = tvec(T)
    env = np.where(t >= t0, A0*np.exp(g*(t-t0)), 0.0)
    return t, base(t) + env*np.sin(2*np.pi*f*(t-t0)), env


def transient_signal(T=0.6, t0=0.20, f=120.0, tau=0.015, A0=60.0):
    t = tvec(T)
    env = np.where(t >= t0, A0*np.exp(-(t-t0)/tau), 0.0)
    return t, base(t) + env*np.sin(2*np.pi*f*(t-t0)), env


def add_noise(y, snr_db, rng):
    p = np.mean(y**2)/10**(snr_db/10)
    return y + rng.normal(0, np.sqrt(p), y.shape)


def detect(tt, amp, t_base, t_search, hold=0.010):
    """First time in t_search where amp stays above median+3*std of the event-free
    baseline window for `hold` seconds. Returns (t_detect or None)."""
    b = (tt >= t_base[0]) & (tt < t_base[1])
    thr = np.median(amp[b]) + 3*np.std(amp[b])
    idx = np.where((tt >= t_search[0]) & (tt <= t_search[1]))[0]
    dt = np.median(np.diff(tt)); n = max(1, int(round(hold/dt)))
    above = amp[idx] > thr
    for j in range(len(idx)-n):
        if above[j:j+n].all():
            return float(tt[idx[j]])
    return None


def logfit_rate(tt, env, win):
    m = (tt >= win[0]) & (tt <= win[1]) & (env > 0)
    if m.sum() < 5:
        return np.nan
    return float(np.polyfit(tt[m], np.log(env[m]), 1)[0])


def summarize(vals):
    v = np.asarray([x for x in vals if x is not None and np.isfinite(x)])
    if len(v) == 0:
        return dict(n=0, med=None, p25=None, p75=None)
    return dict(n=int(len(v)), med=float(np.median(v)), p25=float(np.percentile(v, 25)),
                p75=float(np.percentile(v, 75)))
