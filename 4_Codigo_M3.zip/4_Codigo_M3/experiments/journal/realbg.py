"""realbg.py -- real background from the measured EV-charger voltages: resample to 4 kHz, fit and remove the
fundamental by least squares, rescale the residual to the 127.84 kV fundamental of configuration v1."""
import os, numpy as np
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data'); FS = 4000.0; A1 = 127.84
RAW = bool(os.environ.get('REALBG_RAW'))
def residual(name):
    if RAW: return residual_raw(name)
    return residual_export(name)
def residual_raw(name):
    """raw PicoScope records (1.25 MHz, 1.9-2.5 s): 'con' = voltage with LISN, 'sin' = voltage without LISN;
    polyphase resampling to 4 kHz, then the same least-squares removal of the fundamental as for the exports"""
    import sys as _s; _s.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'm1m2')); import raw_inputs as RI
    x = RI.load({'con': 'h2', 'sin': 'h1'}[name])['x']; t = np.arange(len(x))/FS; best = None
    for f in np.linspace(49.9, 50.1, 401):
        M = np.column_stack([np.sin(2*np.pi*f*t), np.cos(2*np.pi*f*t), np.ones_like(t)]); c = np.linalg.lstsq(M, x, rcond=None)[0]
        e = np.sum((x-M@c)**2)
        if best is None or e < best[0]: best = (e, f, c, M)
    _, f, c, M = best; A = np.hypot(c[0], c[1]); r = (x - M@c)*A1/A
    return t, x, r, f, A
def residual_export(name):
    v = np.load(os.path.join(D, f'v_{name}.npy')); tt = np.load(os.path.join(D, f't_{name}.npy'))
    # the stored points come from a matlab2tikz plot export (non-uniform time stamps): interpolate onto a
    # uniform 200 kHz grid, low-pass at 1.8 kHz (anti-aliasing) and decimate to 4 kHz
    from scipy.signal import butter, sosfiltfilt
    tu = np.arange(0, tt[-1], 1/200000.0); vu = np.interp(tu, tt, v)
    vu = sosfiltfilt(butter(8, 1800/(200000/2), output='sos'), vu); x = vu[::50]; t = np.arange(len(x))/FS
    best = None
    for f in np.linspace(49.5, 50.5, 2001):
        M = np.column_stack([np.sin(2*np.pi*f*t), np.cos(2*np.pi*f*t), np.ones_like(t)]); c = np.linalg.lstsq(M, x, rcond=None)[0]
        e = np.sum((x-M@c)**2)
        if best is None or e < best[0]: best = (e, f, c, M)
    _, f, c, M = best; A = np.hypot(c[0], c[1]); r = (x - M@c)*A1/A
    return t, x, r, f, A
def background(n):
    """n-sample background: concatenation of both residuals (with and without EV), tiled."""
    if RAW:   # alternate 0.5 s blocks of both raw records, as with the exports, but with five times more material
        a, b = residual('con')[2], residual('sin')[2]; L = 2000; m = min(len(a), len(b))//L
        r = np.concatenate([np.concatenate([a[i*L:(i+1)*L], b[i*L:(i+1)*L]]) for i in range(m)])
    else:
        r = np.concatenate([residual('con')[2], residual('sin')[2]])
    k = int(np.ceil(n/len(r))) + 1
    return np.tile(r, k)
if __name__ == '__main__':
    from numpy.fft import rfft, rfftfreq
    for nm in ['con', 'sin']:
        t, x, r, f, A = residual(nm); X = np.abs(rfft(r*np.hanning(len(r)))); fr = rfftfreq(len(r), 1/FS)
        h = {k: 100*2*X[np.argmin(abs(fr-k*f))]/np.hanning(len(r)).sum()/A1 for k in [3, 5, 7, 9, 11, 13]}
        thd = np.sqrt(sum(v**2 for v in h.values()))
        print(f"{nm}: f1 = {f:.3f} Hz | residual RMS = {100*np.std(r)/(A1/np.sqrt(2)):.2f} % of fundamental RMS | harmonics (% a1): " + ', '.join(f'{k}:{v:.2f}' for k, v in h.items()) + f" | THD(3-13) = {thd:.2f} %")
