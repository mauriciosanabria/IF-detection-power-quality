"""mc17_ipdft_fix.py -- recomputes every IpDFT result with the periodic Hann window assumed by the two-point
interpolation (the symmetric window used before biased the estimates by up to ~65 mHz), and adds the
Hilbert-transform IpDFT (HT-IpDFT) of Frigo et al. (2019) where IpDFT tracks. Noise realizations are
reproduced exactly from the seeds and draw order of the original experiments."""
import sys, os, json; sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np, realbg
from mc_common import FS, A1, tvec, base, rocof_signal, growing_signal, add_noise, detect, logfit_rate, summarize
from methods.ground_truth import CONFIGS, y_model, time_vector
from methods.extra_estimators import ipdft_sequential, ipdft_track, ipdft_peak, fit_sinusoid, bandstop
from methods.extra2 import ht_ipdft_track
from mc9_new_scenarios import score_bursts
O = {}; TR = {'IpDFT': ipdft_track, 'HT-IpDFT': ht_ipdft_track}
def rm(tc, f, t, ft, w): m = (tc >= w[0]) & (tc <= w[1]); e = f[m]-np.interp(tc[m], t, ft); return float(np.sqrt(np.mean(e**2))), float(np.mean(e)), float(np.std(e))
# 1. Scenario S (mc1: 60 realizations)
t = time_vector(); O['S'] = {}
for SNR in [30, 60]:
    for node, th in CONFIGS.items():
        f2 = th[4]; bands = [(35, 65), (max(60, f2*0.5), f2*1.5), (th[7]*0.7, th[7]*1.3)]
        rng = np.random.default_rng(100*SNR + list(CONFIGS).index(node)); y0 = y_model(th, t); ok = []
        for r in range(60):
            y = add_noise(y0, SNR, rng); f = ipdft_sequential(y, t, FS, bands)[1]; ok.append(f is not None and abs(f-f2)/f2 < 0.01)
        nf = ipdft_sequential(y0, t, FS, bands)[1]
        O['S'][f'{SNR}_{node}'] = dict(success=float(np.mean(ok)), noise_free_err=float(100*abs(nf-f2)/f2))
print('S', O['S'], flush=True)
# 2. Scenario R (mc2: seeds = snr)
t, y0, ft = rocof_signal(); O['R'] = {}
for snr in [40, 30, 20, 15]:
    rng = np.random.default_rng(snr); acc = {k: [] for k in TR}
    for r in range(100):
        y = add_noise(y0, snr, rng)
        for k, fn in TR.items():
            tc, f, _ = fn(y, FS, (40, 60), 240, 8); acc[k].append((rm(tc, f, t, ft, (.4, .55))[0], rm(tc, f, t, ft, (.6, .8))[0]))
    O['R'][snr] = {k: dict(ramp=float(np.median([a for a, b in v])), settled=float(np.median([b for a, b in v]))) for k, v in acc.items()}
print('R', O['R'], flush=True)
# 3. Scenario R paired statistics (mc13 seeds)
O['Rstats'] = {}
for snr in [30, 15]:
    acc = {k: [] for k in TR}
    for r in range(100):
        y = add_noise(y0, snr, np.random.default_rng(130000 + 1000*snr + r))
        for k, fn in TR.items():
            tc, f, _ = fn(y, FS, (40, 60), 240, 8); acc[k].append(rm(tc, f, t, ft, (.4, .55)))
    O['Rstats'][snr] = {k: dict(rmse=[a for a, b, c in v], bias=float(np.mean([b for a, b, c in v])), std=float(np.mean([c for a, b, c in v]))) for k, v in acc.items()}
print('Rstats ok', flush=True)
# 4. Sensitivity (mc14 seeds)
O['sens'] = {}
for cyc in [2, 3, 5]:
    v = []
    for r in range(30):
        y = add_noise(y0, 30, np.random.default_rng(140000 + r)); tc, f, _ = ipdft_track(y, FS, (40, 60), int(80*cyc), 8)
        v.append((rm(tc, f, t, ft, (.4, .55))[0], rm(tc, f, t, ft, (.6, .8))[0]))
    O['sens'][cyc] = dict(ramp=float(np.median([a for a, b in v])), settled=float(np.median([b for a, b in v])))
print('sens', O['sens'], flush=True)
# 5. Scenario U5 (mc9 U5: seed 950)
a1, _, p1 = CONFIGS['v1'][:3]; ph = np.mod(2*np.pi*np.cumsum(ft)/FS + p1, np.pi/3); h = (ph > 0.5) & (ph < 0.5 + 2*np.pi*50*0.0006)
yN = y0*(1 - 0.3*h); rng = np.random.default_rng(950); acc = {k: [] for k in TR}
for r in range(100):
    y = add_noise(yN, 30, rng)
    for k, fn in TR.items():
        tc, f, _ = fn(y, FS, (40, 60), 240, 8); acc[k].append((rm(tc, f, t, ft, (.4, .55))[0], rm(tc, f, t, ft, (.6, .8))[0]))
O['U5'] = {k: dict(ramp=float(np.median([a for a, b in v])), settled=float(np.median([b for a, b in v]))) for k, v in acc.items()}
print('U5', O['U5'], flush=True)
# 6. Scenario G (mc3: seed 3)
T, T0 = 1.05, 0.50; t, yG0, env = growing_signal(T=T, t0=T0, g=6.0); rng = np.random.default_rng(3); acc = {k: [] for k in TR}
def det_row(tt, a):
    td = detect(tt, a, (0.30, 0.48), (0.48, T-0.03)); return (None if (td is None or td < T0) else td-T0, bool(td is not None and td < T0), logfit_rate(tt, a, (T0+0.05, T-0.08)))
for r in range(100):
    y = add_noise(yG0, 30, rng)
    for k, fn in TR.items():
        tc, _, a = fn(y, FS, (95, 125), 160, 8); acc[k].append(det_row(tc + 0.02, a))
def gsum(v):
    d = [x[0] for x in v]; return dict(det=float(np.mean([x is not None for x in d])), fa=float(np.mean([x[1] for x in v])),
        delay=summarize(1000*np.array([x for x in d if x is not None])), growth=float(np.median([x[2] for x in v if x[2] is not None])))
O['G'] = {k: gsum(v) for k, v in acc.items()}
print('G', {k: (v['det'], v['fa'], v['delay']['med'], v['growth']) for k, v in O['G'].items()}, flush=True)
# 7. Scenario U1 (mc5 e1: seed 51) and U2 (mc5 e2: seed 52)
t = tvec(0.5); rng = np.random.default_rng(51); ok, rho = [], []
for r in range(100):
    fu, au, phh = rng.uniform(70, 450), rng.uniform(0.10, 0.30)*A1, rng.uniform(-np.pi, np.pi)
    y = add_noise(base(t) + au*np.sin(2*np.pi*fu*t+phh), 30, rng)
    f1 = ipdft_peak(y, FS, (35, 65)); comp, _ = fit_sinusoid(y, t, f1); f = ipdft_peak(y-comp, FS, (60, 500))
    ok.append(abs(f-fu)/fu < 0.01); rho.append(au*fu/(A1*50))
ok, rho = np.array(ok), np.array(rho); O['U1'] = dict(success=float(ok.mean()), gt1=float(ok[rho > 1].mean()), le1=float(ok[rho <= 1].mean()))
Tc = 0.6; t = tvec(Tc); kk = 250/Tc; ftc = 150 + kk*t; y0c = base(t) + 0.4*A1*np.sin(2*np.pi*(150*t + 0.5*kk*t**2)); rng = np.random.default_rng(52); acc = {k: [] for k in TR}
for r in range(100):
    y = add_noise(y0c, 30, rng); yn = bandstop(y, FS, 40, 60)
    for k, fn in TR.items():
        tc, f, _ = fn(yn, FS, (60, 600), 120, 8); m = (tc >= .1) & (tc <= .5); acc[k].append(float(np.sqrt(np.mean((f[m]-np.interp(tc[m], t, ftc))**2))))
O['U2'] = {k: summarize(v) for k, v in acc.items()}
print('U1', O['U1'], 'U2', {k: (v['med'], v['p25'], v['p75']) for k, v in O['U2'].items()}, flush=True)
# 8. Scenario U3 (mc9r seeds 930000+r)
t = tvec(1.0); acc = {k: [] for k in TR}
for r in range(100):
    rng = np.random.default_rng(930000+r); fb, ab = rng.uniform(150, 450), rng.uniform(0.10, 0.30)*A1
    starts = [0.15+rng.uniform(0, .05), 0.45+rng.uniform(0, .05), 0.75+rng.uniform(0, .05)]; y = base(t)
    for s in starts:
        e = np.clip((t-s)/0.005, 0, 1)*np.clip((s+0.06-t)/0.005, 0, 1); e = 0.5-0.5*np.cos(np.pi*e); y = y + ab*e*np.sin(2*np.pi*fb*t + rng.uniform(-np.pi, np.pi))
    y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60)
    for k, fn in TR.items():
        tc, f, a = fn(yn, FS, (60, 500), 120, 8); acc[k].append(score_bursts(tc, a, f, starts, fb))
O['U3'] = {k: dict(detected=float(sum(x[0] for x in v)/300), false=float(np.mean([x[1] for x in v])), onset=float(1000*np.median([o for x in v for o in x[2]])), freq=float(sum(x[3] for x in v)/300)) for k, v in acc.items()}
print('U3', O['U3'], flush=True)
# 9. Sweep P (mc6: seed 66, NF = 20)
t = tvec(0.5); rng = np.random.default_rng(66); P = {}
for rr in [0.0005, 0.002, 0.005, 0.01, 0.02, 0.05, 0.10, 0.20, 0.50]:
    for f2 in [70, 100, 150, 250, 400, 650, 1000]:
        ok = []
        for k in range(20):
            y = add_noise(A1*np.sin(2*np.pi*50*t) + rr*A1*np.sin(2*np.pi*f2*t + rng.uniform(-np.pi, np.pi)), 40, rng)
            f = ipdft_sequential(y, t, FS, [(35, 65), (0.7*f2, 1.3*f2)])[1]; ok.append(f is not None and np.isfinite(f) and abs(f-f2)/f2 < 0.01)
        P[f'{rr}_{f2}'] = float(np.mean(ok))
O['P'] = P; print('P cells with >=50 %:', sum(v >= 0.5 for v in P.values()), 'of 63', flush=True)
# 10. CRLB (mc12 seeds)
t = time_vector(); N = len(t); O['crlb'] = {}
for snr in [60, 30]:
    for node in ['v1', 'v3', 'v2']:
        th = CONFIGS[node]; f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5); bands = [(35, 65), b2, (th[7]*0.7, th[7]*1.3)]; y0 = y_model(th, t); e = []
        for r in range(100):
            rng = np.random.default_rng(120000 + 1000*snr + 10*int(node[1]) + r); sig2 = np.mean(y0**2)/10**(snr/10)
            y = y0 + rng.normal(0, np.sqrt(sig2), N); f = ipdft_sequential(y, t, FS, bands)[1]; e.append(np.nan if f is None else f-f2)
        e = np.array(e); ok = np.abs(e) < 0.01*f2
        O['crlb'][f'{snr}_{node}'] = dict(succ=float(ok.mean()), bias=float(np.mean(e[ok])) if ok.sum() > 2 else None, std=float(np.std(e[ok])) if ok.sum() > 2 else None)
print('crlb', O['crlb'], flush=True)
# 11. Measured background (mc15: shifts from seed 150) and measured records
BG = realbg.background(8000); shifts = np.random.default_rng(150).integers(0, 4000, 100)
a1, f1_, p1_, a2, f2_, p2, a3, f3, p3 = CONFIGS['v1']
t, yR, ft = rocof_signal(); yR = yR - a2*np.sin(2*np.pi*f2_*t+p2) - a3*np.sin(2*np.pi*f3*t+p3); acc = {k: [] for k in TR}
for r in range(100):
    y = yR + BG[shifts[r]:shifts[r]+len(t)]
    for k, fn in TR.items():
        tc, f, _ = fn(y, FS, (40, 60), 240, 8); acc[k].append((rm(tc, f, t, ft, (.4, .55))[0], rm(tc, f, t, ft, (.6, .8))[0]))
O['semi_R'] = {k: dict(ramp=float(np.median([a for a, b in v])), settled=float(np.median([b for a, b in v]))) for k, v in acc.items()}
t, yG, env = growing_signal(T=1.05, t0=0.50); yG = yG - a2*np.sin(2*np.pi*f2_*t+p2) - a3*np.sin(2*np.pi*f3*t+p3); acc = {k: [] for k in TR}
for r in range(100):
    y = yG + BG[shifts[r]:shifts[r]+len(t)]
    for k, fn in TR.items():
        tc, _, a = fn(y, FS, (95, 125), 160, 8); acc[k].append(det_row(tc + 0.02, a))
O['semi_G'] = {k: gsum(v) for k, v in acc.items()}
O['real_f'] = {}
for rec in ['con', 'sin']:
    tt, x, rr_, fls, A = realbg.residual(rec); x = x*127.84/A; O['real_f'][rec] = {}
    for k, fn in TR.items():
        tc, f, _ = fn(x, FS, (40, 60), 240, 8); m = (tc > .1) & (tc < .4); O['real_f'][rec][k] = float(1000*(np.median(f[m])-fls))
print('semi_R', O['semi_R'], '\nsemi_G', {k: (v['det'], v['fa'], v['delay']['med'], v['growth']) for k, v in O['semi_G'].items()}, '\nreal_f', O['real_f'], flush=True)
json.dump(O, open(os.path.join(os.path.dirname(__file__), f"res_mc17_ipdft_fix{os.environ.get('RLIB_SUFFIX', '')}.json"), 'w'), indent=1)
