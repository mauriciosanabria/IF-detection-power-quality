"""mc4_transient.py -- 120 Hz transient, tau = 15 ms, A0 = 60 kV, onset at 200 ms of a 600 ms
record, 30 dB SNR, 100 realizations. Estimates frequency and time constant.
'Right phenomenon' = estimated frequency within 5 Hz of 120 Hz.
'EMD-guided LM' = EMD used only to LOCATE the event (blind IMF choice by early non-stationary
energy, recombination of split modes, spectral seed), then Levenberg-Marquardt on the ORIGINAL
signal -- the 'locate with EMD, measure on the original signal' strategy."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from scipy.optimize import least_squares
from mc_common import FS, transient_signal, add_noise, logfit_rate, summarize
from methods.extra_estimators import bandpass, analytic_if, esprit, cwt_track, stft_track, vmd_modes
from PyEMD import CEEMDAN

N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
T0, TAU, FE = 0.20, 0.015, 120.0
FIT = (T0+0.005, T0+0.040)


def est_env(tt, a, fi):
    s = logfit_rate(tt, a, FIT); m = (tt >= FIT[0]) & (tt <= FIT[1])
    return float(np.median(fi[m])), (-1/s if s < 0 else np.nan)


def emd_guided(t, y, imfs):
    late, early = t > T0+0.15, (t >= T0) & (t < T0+0.05)
    info = []
    for imf in imfs:
        seg = imf[late]*np.hanning(late.sum()); F = np.abs(np.fft.rfft(seg, 32768)); fr = np.fft.rfftfreq(32768, 1/FS)
        f0 = fr[np.argmax(F[1:])+1]
        M = np.column_stack([np.sin(2*np.pi*f0*t), np.cos(2*np.pi*f0*t)])
        c = np.linalg.lstsq(M[late], imf[late], rcond=None)[0]
        info.append((f0, np.sqrt(np.mean((imf-M@c)[early]**2))))
    i = int(np.argmax([r for _, r in info]))
    x = sum(imfs[j] for j in range(len(imfs)) if abs(info[j][0]-info[i][0]) < 1.0)
    M = np.column_stack([np.sin(2*np.pi*50*t), np.cos(2*np.pi*50*t)])
    c = np.linalg.lstsq(M[late], x[late], rcond=None)[0]; res = x - M@c
    seg = res[early]*np.hanning(early.sum()); F = np.abs(np.fft.rfft(seg, 8192)); fr = np.fft.rfftfreq(8192, 1/FS)
    b = (fr > 60) & (fr < 500); fseed = fr[b][np.argmax(F[b])]
    w = (t >= T0) & (t <= T0+0.10); tw = t[w]-T0; yw = y[w]
    ca = np.linalg.lstsq(M[late], y[late], rcond=None)[0]
    def model(p, tt):
        a1, f1, p1, A, tau, fe, pe = p
        return a1*np.sin(2*np.pi*f1*(tt+T0)+p1) + A*np.exp(-tt/tau)*np.sin(2*np.pi*fe*tt+pe)
    best = None
    for pe in np.linspace(-np.pi, np.pi, 6, endpoint=False):
        p0 = [np.hypot(*ca), 50.0, np.arctan2(ca[1], ca[0]), 30.0, 0.02, fseed, pe]
        rr = least_squares(lambda p: model(p, tw)-yw, p0, bounds=([0, 45, -np.inf, 0, 1e-3, 60, -np.inf],
                                                                 [400, 55, np.inf, 400, 0.2, 500, np.inf]))
        if best is None or rr.cost < best.cost: best = rr
    return float(best.x[5]), float(best.x[4])


def run():
    t, y0, env = transient_signal(t0=T0, tau=TAU, f=FE)
    rng = np.random.default_rng(4); res = {}
    def put(k, f, tau): res.setdefault(k, {'f': [], 'tau': []}); res[k]['f'].append(f); res[k]['tau'].append(tau)
    for r in range(N):
        y = add_noise(y0, 30, rng)
        a, fi = analytic_if(bandpass(y, FS, 100, 145), FS); put('PF+Hilbert', *est_env(t, a, fi))
        f, a = cwt_track(y, FS, 90, 150, return_amp=True); put('CWT (L1)', *est_env(t, a, f))
        tc, f, a = stft_track(y, FS, (100, 145), nperseg=64, step=2, nfft=1024); put('STFT', *est_env(tc, a, f))
        seg = (t >= T0+0.002) & (t <= T0+0.10)
        fe, s, _ = esprit(y[seg], FS, 8); k = (fe > 90) & (fe < 150)
        put('ESPRIT', float(fe[k][np.argmin(abs(fe[k]-120))]) if k.any() else np.nan,
            float(-1/s[k][np.argmin(abs(fe[k]-120))]) if k.any() and s[k][np.argmin(abs(fe[k]-120))] < 0 else np.nan)
        u, c = vmd_modes(y, FS, 4)
        early, late = (t >= T0) & (t < T0+0.05), t > T0+0.15
        i = int(np.argmax([np.std(m[early])/(np.std(m[late])+1e-9) for m in u])); a, fi = analytic_if(u[i], FS)
        put('VMD (blind)', *est_env(t, a, fi))
        if r >= 30:
            continue
        ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(9000+r); imfs = ce.ceemdan(y, t)
        sc = []
        for imf in imfs:
            a, fi = analytic_if(imf, FS); e = (t >= T0) & (t < T0+0.06)
            sc.append(np.mean((fi[e] > 90) & (fi[e] < 150))*min(np.mean(a[(t >= T0) & (t < T0+0.05)])/(np.mean(a[late])+1e-9), 20))
        a, fi = analytic_if(imfs[int(np.argmax(sc))], FS); put('HHT, naive IMF rule', *est_env(t, a, fi))
        put('EMD-guided LM', *emd_guided(t, y, imfs))
        if (r+1) % 20 == 0:
            print(f"  {r+1}/{N}", flush=True)
    out = {}
    for k, v in res.items():
        f = np.array(v['f'], float); tau = np.array(v['tau'], float)
        right = np.isfinite(f) & (np.abs(f-FE) < 5)
        out[k] = dict(right_phenomenon=float(right.mean()), f=summarize(f),
                      tau_err_pct=summarize(100*np.abs(tau-TAU)/TAU),
                      tau_err_pct_right=summarize(100*np.abs(tau[right]-TAU)/TAU) if right.any() else None)
        print(k, f"right {100*out[k]['right_phenomenon']:.0f}%  f med {out[k]['f']['med']}  tau err med {out[k]['tau_err_pct']['med']}", flush=True)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc4_transient.json'), 'w'), indent=1)


if __name__ == '__main__':
    t0 = time.time(); run(); print(f"done {time.time()-t0:.0f}s")
