"""mc10r_resumable.py -- CEEMDAN-based methods with 100 realizations in D, U1 and U2, resumable
(one JSONL line per realization). Same signals and metrics as mc10; merges into res_mc10_ceemdan100.json."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, A1, tvec, base, transient_signal, add_noise, summarize
from methods.extra_estimators import bandstop, analytic_if
import mc4_transient as m4, mc5_unknown as m5
from PyEMD import CEEMDAN
D = os.path.dirname(os.path.abspath(__file__)); N = 100
def ce(y, t, s): c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(s); return c.ceemdan(y, t)
def done(s):
    p = os.path.join(D, f'{s}_ce_raw.jsonl'); return {json.loads(l)['r'] for l in open(p)} if os.path.exists(p) else set()
def save(s, row):
    with open(os.path.join(D, f'{s}_ce_raw.jsonl'), 'a') as fh: fh.write(json.dumps(row) + '\n'); fh.flush(); os.fsync(fh.fileno())
def Dr(r):
    t, y0, _ = transient_signal(t0=m4.T0); rng = np.random.default_rng(1032000+r); late = t > m4.T0+0.15
    y = add_noise(y0, 30, rng); imfs = ce(y, t, 22000+r); sc = []
    for imf in imfs:
        a, fi = analytic_if(imf, FS); e = (t >= m4.T0) & (t < m4.T0+0.06)
        sc.append(np.mean((fi[e] > 90) & (fi[e] < 150))*min(np.mean(a[(t >= m4.T0) & (t < m4.T0+0.05)])/(np.mean(a[late])+1e-9), 20))
    a, fi = analytic_if(imfs[int(np.argmax(sc))], FS)
    return {'r': r, 'HHT, naive IMF rule': list(m4.est_env(t, a, fi)), 'EMD-guided LM': list(m4.emd_guided(t, y, imfs))}
def U1r(r):
    t = tvec(0.5); m = (t > 0.05) & (t < 0.45); rng = np.random.default_rng(1033000+r)
    fu, au, ph = rng.uniform(70, 450), rng.uniform(0.10, 0.30)*A1, rng.uniform(-np.pi, np.pi)
    y = add_noise(base(t) + au*np.sin(2*np.pi*fu*t+ph), 30, rng); row = {'r': r, 'rho': au*fu/(A1*50)}
    for k, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
        imf = m5.pick_imf(ce(bandstop(y, FS, 40, 60) if pre else y, t, 23000+r), 60, 500, m)
        row[k] = None if imf is None else 100*abs(float(np.median(analytic_if(imf, FS)[1][m]))-fu)/fu
    return row
def U2r(r):
    T = 0.6; t = tvec(T); k_ = 250/T; ftrue = 150 + k_*t; ev = (t >= 0.10) & (t <= 0.50); rng = np.random.default_rng(1034000+r)
    y = add_noise(base(t) + 0.4*A1*np.sin(2*np.pi*(150*t + 0.5*k_*t**2)), 30, rng); sm = lambda f: np.convolve(f, np.ones(20)/20, mode='same'); row = {'r': r}
    for k, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
        imf = m5.pick_imf(ce(bandstop(y, FS, 40, 60) if pre else y, t, 24000+r), 60, 600, ev)
        row[k] = None if imf is None else float(np.sqrt(np.mean((sm(analytic_if(imf, FS)[1])[ev]-ftrue[ev])**2)))
    return row
def aggregate():
    P = os.path.join(D, 'res_mc10_ceemdan100.json'); OUT = json.load(open(P)) if os.path.exists(P) else {}
    L = lambda s: [json.loads(l) for l in open(os.path.join(D, f'{s}_ce_raw.jsonl'))] if os.path.exists(os.path.join(D, f'{s}_ce_raw.jsonl')) else []
    rows = L('D')
    if rows:
        OUT['D'] = {}
        for k in ['HHT, naive IMF rule', 'EMD-guided LM']:
            f = np.array([x[k][0] if x[k][0] is not None else np.nan for x in rows], float); tau = np.array([x[k][1] if x[k][1] is not None else np.nan for x in rows], float)
            right = np.isfinite(f) & (abs(f-120) < 5)
            OUT['D'][k] = dict(right=float(right.mean()), f=summarize(f), tau_err=summarize(100*abs(tau-m4.TAU)/m4.TAU), n=len(rows))
    rows = L('U1')
    if rows:
        rho = np.array([x['rho'] for x in rows]); OUT['U1'] = {}
        for k in ['CEEMDAN', 'FN-EMD']:
            ok = np.array([x[k] is not None and x[k] < 1 for x in rows])
            OUT['U1'][k] = dict(success=float(ok.mean()), rho_gt1=float(ok[rho > 1].mean()), rho_le1=float(ok[rho <= 1].mean()), n=len(rows))
    rows = L('U2')
    if rows: OUT['U2'] = {k: dict(**summarize([x[k] for x in rows]), runs=len(rows)) for k in ['CEEMDAN', 'FN-EMD']}
    json.dump(OUT, open(P, 'w'), indent=1); print({k: OUT[k] for k in ['D', 'U1', 'U2'] if k in OUT})
if __name__ == '__main__':
    if sys.argv[1:] == ['aggregate']: aggregate(); sys.exit()
    for s, fn in [('D', Dr), ('U1', U1r), ('U2', U2r)]:
        have = done(s)
        for r in range(N):
            if r not in have: save(s, fn(r)); print(s, r, flush=True)
    aggregate()
