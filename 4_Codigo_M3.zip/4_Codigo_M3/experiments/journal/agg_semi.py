"""agg_semi.py -- aggregate the measured-background validation (exports or raw records, RLIB_SUFFIX) into the
quantities of the M3 table: Scenario R medians, Scenario G detection statistics, measured-record deviations."""
import os, json, numpy as np, rlib
sfx = os.environ.get('RLIB_SUFFIX', ''); OUT = {'R': {}, 'G': {}, 'real': {}}
R = rlib.load('semi_R')
for k in (R[0]['res'] if R else {}):
    v = [x['res'][k] for x in R if k in x['res']]; OUT['R'][k] = dict(ramp=float(np.median([a for a, b in v])), settled=float(np.median([b for a, b in v])), n=len(v))
G = rlib.load('semi_G')
for k in (G[0]['res'] if G else {}):
    v = [x['res'][k] for x in G if k in x['res']]; d = [x[0] for x in v]
    OUT['G'][k] = dict(det=100*float(np.mean([x is not None for x in d])), fa=100*float(np.mean([x[1] for x in v])), delay=float(1000*np.median([x for x in d if x is not None])) if any(x is not None for x in d) else None,
                       growth=float(np.median([x[2] for x in v if x[2] is not None])), n=len(v))
for row in rlib.load('real_f'):
    ls = row['est']['Least squares (whole record)']; OUT['real'][row['key']] = {k: 1000*(f - ls) for k, f in row['est'].items() if k != 'Least squares (whole record)'}; OUT['real'][row['key']]['_residual_pct'] = row['residual_pct']
p17 = f'res_mc17_ipdft_fix{sfx}.json'
if os.path.exists(p17):
    M = json.load(open(p17))
    for k in ('IpDFT', 'HT-IpDFT'):
        if k in M.get('semi_R', {}): OUT['R'][k] = dict(M['semi_R'][k], n=100)
        if k in M.get('semi_G', {}): g = M['semi_G'][k]; OUT['G'][k] = dict(det=100*g['det'], fa=100*g['fa'], delay=g['delay']['med'], growth=g['growth'], n=100)
        for rec in ('con', 'sin'):
            if k in M.get('real_f', {}).get(rec, {}): OUT['real'][rec][k] = M['real_f'][rec][k]
json.dump(OUT, open(f'res_semi_aggregate{sfx}.json', 'w'), indent=1)
print('R (rampa / estable, Hz):'); [print(f"   {k:22s} {v['ramp']:.4f} / {v['settled']:.4f}  (n={v['n']})") for k, v in sorted(OUT['R'].items(), key=lambda kv: kv[1]['ramp'])]
print('G:'); [print(f"   {k:22s} det {v['det']:.0f} % / fa {v['fa']:.0f} % | retardo {v['delay']} ms | crecimiento {v['growth']:.2f}") for k, v in OUT['G'].items()]
print('Registros (desvío mHz):'); [print(f"   {rec}: residuo {d.pop('_residual_pct'):.3f} % | " + ', '.join(f"{k} {v:+.1f}" for k, v in d.items())) for rec, d in OUT['real'].items()]
