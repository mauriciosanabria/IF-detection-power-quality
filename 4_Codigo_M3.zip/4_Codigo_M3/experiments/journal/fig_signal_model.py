"""fig_signal_model.py -- Figure 1 (fig:signal): the test signal of Eq. (1), configuration v1 with the fundamental
following the -4 Hz/s RoCoF ramp of Scenario R (400-550 ms), and its instantaneous fundamental frequency.
Run from experiments/journal/. Output: figures/signal_model.pdf"""
import os, sys
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(D, '..', '..', 'methods')); sys.path.insert(0, D)
from ieee_style import plt
from mc_common import rocof_signal

t, y, f = rocof_signal()
fig, ax = plt.subplots(2, 1, figsize=(3.45, 3.3), sharex=True)
ax[0].plot(t*1e3, y, color='#1a5fb4', lw=0.5); ax[0].set_ylabel('$y(t)$ (kV)')
ax[1].axvspan(400, 550, color='0.88', lw=0); ax[1].plot(t*1e3, f, 'k-', lw=1.5)
ax[1].set_ylabel('$f_1(t)$ (Hz)'); ax[1].set_xlabel('Time (ms)'); ax[1].set_xlim(0, 1000); ax[1].set_yticks([49.4, 49.6, 49.8, 50.0])
plt.tight_layout(); plt.savefig(os.path.join(D, '..', '..', 'figures', 'signal_model.pdf'))
