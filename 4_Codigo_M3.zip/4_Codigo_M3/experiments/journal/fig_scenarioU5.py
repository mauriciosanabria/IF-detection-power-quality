import os
import sys; sys.path.insert(0, '../../methods'); sys.path.insert(0, '.'); sys.path.insert(0, '../..')
from ieee_style import plt
import numpy as np
from mc_common import FS, transient_signal, rocof_signal, add_noise
from methods.ground_truth import CONFIGS
from methods.extra_estimators import analytic_if, bandpass, vmd_modes
from methods.extra2 import matrix_pencil, pmu_frequency
import mc4_transient as m4
from PyEMD import CEEMDAN
# ---------------- Scenario U5
t, yR, ft = rocof_signal(); a1, _, p1 = CONFIGS['v1'][:3]
ph = np.mod(2*np.pi*np.cumsum(ft)/FS + p1, np.pi/3); h = (ph > 0.5) & (ph < 0.5 + 2*np.pi*50*0.0006); yN0 = yR*(1-0.3*h)
y = add_noise(yN0, 30, np.random.default_rng(2028))
tr = {'PF+Hilbert': (t, analytic_if(bandpass(y, FS, 40, 60), FS)[1]), 'M class': (t, pmu_frequency(y, FS, 50.0, 'M')[0])}
u, cc = vmd_modes(y, FS, 3); tr['VMD+Hilbert'] = (t, analytic_if(u[np.argmin(abs(cc-50))], FS)[1])
c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(2); imfs = c.ceemdan(y, t)
tr['Full HHT (CEEMDAN)'] = (t, min((analytic_if(q, FS)[1] for q in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50)))
m = (t >= 0.3) & (t <= 0.85)
fig = plt.figure(figsize=(7.1, 5.2)); gs = fig.add_gridspec(2, 2, width_ratios=[1, 2.3], hspace=0.38, wspace=0.28)
a0 = fig.add_subplot(gs[:, 0]); c1 = (t >= 0.30) & (t < 0.32)
a0.plot(1000*(t[c1]-0.30), yR[c1], color='#999999', ls='--', lw=1.0, label='Undistorted'); a0.plot(1000*(t[c1]-0.30), yN0[c1], color='#000000', lw=1.0, label='Notched')
a0.set_xlabel('Time (ms)'); a0.set_ylabel('Voltage (kV)'); a0.legend(fontsize=6.5, loc='lower left'); a0.set_title('(a) One cycle', fontsize=8.5)
b_ = fig.add_subplot(gs[0, 1]); c_ = fig.add_subplot(gs[1, 1], sharex=b_)
for ax_, keys, yl, ttl in [(b_, [('PF+Hilbert', '#c0392b', '-', 1.2), ('M class', '#1a5fb4', '--', 1.2)], (49.0, 50.4), '(b) Narrowband estimators (fine scale)'),
                          (c_, [('VMD+Hilbert', '#e67e22', '-', 0.6), ('Full HHT (CEEMDAN)', '#555555', '-', 0.5)], (44, 56), '(c) Decomposition-based estimators (wide scale)')]:
    ax_.axvspan(400, 550, color='#e8e8e8', zorder=0)
    for k_, col, ls, lw in keys:
        tt, f = tr[k_]; mm = (tt >= 0.3) & (tt <= 0.85); ax_.plot(1000*tt[mm], f[mm], color=col, ls=ls, lw=lw, label=k_, alpha=0.9)
    ax_.plot(1000*t[m], ft[m], color='#000000', lw=1.6, label='True', zorder=6)
    ax_.set_ylim(*yl); ax_.set_ylabel('Frequency (Hz)'); ax_.set_title(ttl, fontsize=8.5); ax_.legend(fontsize=6.3, loc='upper right', ncol=3)
c_.set_xlabel('Time (ms)')
plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'scenarioU5_frequency.pdf'), bbox_inches='tight'); print('U5 ok')
