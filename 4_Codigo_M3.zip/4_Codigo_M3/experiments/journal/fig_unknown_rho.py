"""fig_unknown_rho.py -- Figure 7 de M3 (U1: exito frente a rho). Recuperado de la sesion del 3-oct-2026, donde se ejecuto
como bloque directo sin guardarse como archivo. Solo se cambiaron las rutas a rutas relativas."""
import sys, json; import os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'methods'))
from ieee_style import plt
import numpy as np
d = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'res_mc5_unknown.json')))['E1']; rows = d['_rows']
# CEEMDAN y FN-EMD: las 100 realizaciones del experimento mc10 (U1_ce_raw.jsonl), como en la figura publicada
ce_rows = [json.loads(l) for l in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'U1_ce_raw.jsonl'))]
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.7), sharey=True)
for a, keys in zip(ax, [['CEEMDAN', 'FN-EMD', 'EMD'], ['IpDFT', 'ESPRIT', 'VMD (K=4)', 'Notch+BP+Hilbert']]):
    st = {'CEEMDAN': ('#000000', 'o'), 'FN-EMD': ('#c0392b', 's'), 'EMD': ('#999999', 'x'),
          'IpDFT': ('#e67e22', 's'), 'ESPRIT': ('#6a1b9a', 'D'), 'VMD (K=4)': ('#1a5fb4', '^'), 'Notch+BP+Hilbert': ('#2e7d32', 'o')}
    for k in keys:
        sub = ce_rows if k in ('CEEMDAN', 'FN-EMD') else rows
        rho = np.array([r['rho'] for r in sub]); e = np.array([r[k] for r in sub], float); e = np.where(np.isfinite(e), e, 300)
        a.scatter(rho, np.clip(e, 1e-5, 300), s=9, marker=st[k][1], facecolors='none' if st[k][1] in 'osD^' else None,
                  edgecolors=st[k][0] if st[k][1] in 'osD^' else None, color=st[k][0], lw=0.7, label=k)
    a.axhline(1, color='k', ls='--', lw=0.7); a.axvline(1, color='k', ls=':', lw=0.8)
    a.set_yscale('log'); a.set_xscale('log'); a.set_xlabel(r'Slope ratio $\rho = a_u f_u/(a_1 f_1)$'); a.legend(fontsize=6.5, loc='upper right')
ax[0].set_ylabel('Relative frequency error (%)'); ax[0].set_title('(a) EMD family', fontsize=9); ax[1].set_title('(b) Other blind estimators', fontsize=9)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'unknown_rho.pdf'))
n1 = sum(r['rho'] > 1 for r in rows); n1e = sum(r['rho'] > 1 for r in ce_rows); print(f'rho>1: {n1} de {len(rows)} (U1/U2); {n1e} de {len(ce_rows)} (CEEMDAN y FN-EMD)')