"""Una configuracion del escenario S (CEEMDAN y FN-EMD), con las semillas de mc1_stationary; guarda en res_ceemdan_tabla4.json.
Uso: python3 ceemdan_uno.py SNR nodo"""
import sys, os, json, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')); sys.path.insert(0, '.')
import numpy as np
SNR, node = int(sys.argv[1]), sys.argv[2]; sys.argv = sys.argv[:1]
import mc1_stationary as M
from PyEMD import CEEMDAN
from methods.extra_estimators import bandstop
t = M.time_vector(); m = (t > 0.05) & (t < 0.45); th = M.CONFIGS[node]; f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5)
rng = np.random.default_rng(100*SNR + list(M.CONFIGS).index(node)); y0 = M.y_model(th, t); res = {'CEEMDAN': [], 'FN-EMD': []}
for r in range(15):
    y = M.add_noise(y0, SNR, rng)
    for key, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
        c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(1000 + r)
        f = M.band_imf(c.ceemdan(bandstop(y, M.FS, 40, 60) if pre else y, t), M.FS, b2, m); res[key].append(f is not None and abs(f - f2)/f2 < 0.01)
P = 'res_ceemdan_tabla4.json'; OUT = json.load(open(P)) if os.path.exists(P) else {}
OUT.setdefault(str(SNR), {})[node] = {k: 100*float(np.mean(v)) for k, v in res.items()}; json.dump(OUT, open(P, 'w'), indent=1)
print(f"SNR {SNR} {node}: CEEMDAN {OUT[str(SNR)][node]['CEEMDAN']:.0f} % | FN-EMD {OUT[str(SNR)][node]['FN-EMD']:.0f} %")
