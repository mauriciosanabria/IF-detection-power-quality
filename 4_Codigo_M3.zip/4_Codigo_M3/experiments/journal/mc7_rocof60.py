"""mc7_rocof60.py -- Scenario R repeated on a 60 Hz grid (ramp 60 -> 59.4 Hz), 30 dB, 30 realizations
(CEEMDAN: 10). Checks that the ranking does not depend on the 50 Hz choice."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, tvec, add_noise, summarize
from methods.extra_estimators import bandpass, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track, vmd_modes
from methods.ground_truth import CONFIGS
from PyEMD import CEEMDAN
t = tvec(1.0); f = np.full_like(t, 60.0); rr = (t >= .4) & (t < .55); f[rr] = 60 - 4*(t[rr]-.4); f[t >= .55] = 59.4
a1, _, p1, a2, f2, p2, a3, f3, p3 = CONFIGS['v1']
y0 = a1*np.sin(2*np.pi*np.cumsum(f)/FS+p1) + a2*np.sin(2*np.pi*f2*1.2*t+p2) + a3*np.sin(2*np.pi*f3*1.2*t+p3)
def rm(tt, est, w): ft = np.interp(tt, t, f); m = (tt >= w[0]) & (tt <= w[1]); return float(np.sqrt(np.mean((est[m]-ft[m])**2)))
rng = np.random.default_rng(60); res = {}
def add(k, tt, est): res.setdefault(k, {'ramp': [], 'settled': []}); res[k]['ramp'].append(rm(tt, est, (.4, .55))); res[k]['settled'].append(rm(tt, est, (.6, .8)))
for r in range(30):
    y = add_noise(y0, 30, rng)
    add('PF+Hilbert', t, analytic_if(bandpass(y, FS, 48, 72), FS)[1])
    add('CWT (L1)', t, cwt_track(y, FS, 48, 72))
    add('SOGI-FLL', t, sogi_fll(y, FS, 60.0)[0])
    tc, fi, _ = ipdft_track(y, FS, (48, 72), win=200, hop=8); add('IpDFT', tc, fi)
    tc, fe = esprit_track(y, FS, 60, 6, win=134, hop=16); add('ESPRIT', tc, fe)
    u, c = vmd_modes(y, FS, 3); add('VMD+Hilbert', t, analytic_if(u[np.argmin(abs(c-60))], FS)[1])
    if r < 10:
        ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(r); imfs = ce.ceemdan(y, t)
        add('Full HHT (CEEMDAN)', t, min((analytic_if(i, FS)[1] for i in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-60)))
out = {k: {w: summarize(v[w]) for w in v} for k, v in res.items()}
for k, v in out.items(): print(f"{k:20s} ramp {v['ramp']['med']:.3f}  settled {v['settled']['med']:.3f}", flush=True)
json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc7_rocof60.json'), 'w'), indent=1)
