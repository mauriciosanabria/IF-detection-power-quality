"""mc3_growing.py -- 110 Hz (super-synchronous for a 50 Hz grid) oscillation growing at 6/s
from 0.47% of the fundamental, onset at 500 ms of a 1.05 s record, 30 dB SNR.
Detection: event-free baseline 300-480 ms, median+3*std, held 10 ms. Sliding-window methods
are time-stamped at the window END (causal time stamping). 100 realizations for every method."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from scipy.signal import remez, lfilter
from mc_common import FS, growing_signal, add_noise, detect, logfit_rate, summarize
from methods.extra_estimators import (bandpass, bandstop, analytic_if, sogi_fll, ipdft_track, stft_track,
                                       vmd_modes, esprit)
from PyEMD import CEEMDAN

N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
T0, T, G, BAND = 0.50, 1.05, 6.0, (95, 125)
HB = remez(401, [20, FS/2-20], [1], type='hilbert', fs=FS)


def causal_env(y):
    x = bandpass(y, FS, *BAND, causal=True)
    xd = np.concatenate([np.zeros(200), x[:-200]])
    return np.abs(xd - 1j*lfilter(HB, 1, x))


def run():
    t, y0, env = growing_signal(T=T, t0=T0, g=G)
    rng = np.random.default_rng(3)
    det, rate, fa = {}, {}, {}
    def put(k, tt, a, rate_val=None):
        td = detect(tt, a, (0.30, 0.48), (0.48, T-0.03))
        det.setdefault(k, []); rate.setdefault(k, []); fa.setdefault(k, [])
        fa[k].append(td is not None and td < T0)
        det[k].append(None if (td is None or td < T0) else td - T0)
        rate[k].append(rate_val if rate_val is not None else logfit_rate(tt, a, (T0+0.05, T-0.08)))
    for r in range(N):
        y = add_noise(y0, 30, rng)
        a, _ = analytic_if(bandpass(y, FS, *BAND), FS); put('PF+Hilbert (zero-phase)', t, a)
        put('PF+Hilbert (causal)', t, causal_env(y), logfit_rate(t, a, (T0+0.05, T-0.08)))
        _, a = sogi_fll(bandpass(y, FS, *BAND, causal=True), FS, 110.0); put('SOGI (causal)', t, a)
        tc, _, a = ipdft_track(y, FS, BAND, win=160, hop=8); put('IpDFT (causal stamp)', tc + 0.02, a)
        tc, _, a = stft_track(y, FS, BAND, nperseg=160, step=4); put('STFT (causal stamp)', tc + 0.02, a)
        seg = (t >= T0+0.03) & (t <= T-0.05)
        f, s, _ = esprit(bandpass(y, FS, *BAND)[seg], FS, 2)
        rate.setdefault('ESPRIT', []).append(float(s[np.argmin(abs(f-110))]) if len(f) else np.nan)
        u, c = vmd_modes(bandstop(y, FS, 40, 60), FS, 3); a, _ = analytic_if(u[np.argmin(abs(c-110))], FS)
        put('FN-VMD', t, a)
        for k, pre in ([('Full HHT (CEEMDAN)', False), ('FN-EMD', True)] if r < 30 else []):
            ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(7000+r)
            imfs = ce.ceemdan(bandstop(y, FS, 40, 60) if pre else y, t); best, bd = None, 1e9
            for imf in imfs:
                a, fi = analytic_if(imf, FS); md = np.median(fi[t > T0+0.2])
                if abs(md-110) < bd: bd, best = abs(md-110), a
            put(k, t, best)
        if (r+1) % 20 == 0:
            print(f"  {r+1}/{N}", flush=True)
    out = {}
    for k in rate:
        d = {'growth_rate': summarize(rate[k])}
        if k in det:
            d['detect_prob'] = float(np.mean([x is not None for x in det[k]]))
            d['false_alarm'] = float(np.mean(fa[k])); d['delay_s'] = summarize(det[k])
        out[k] = d
        print(k, {kk: (round(v, 3) if isinstance(v, float) else v) for kk, v in d.items() if kk != 'growth_rate'},
              'rate med', d['growth_rate']['med'], flush=True)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc3_growing.json'), 'w'), indent=1)


if __name__ == '__main__':
    t0 = time.time(); run(); print(f"done {time.time()-t0:.0f}s")
