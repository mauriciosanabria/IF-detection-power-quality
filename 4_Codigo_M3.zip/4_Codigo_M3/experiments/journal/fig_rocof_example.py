import os
import sys; sys.path.insert(0, '../../methods'); sys.path.insert(0, '.'); sys.path.insert(0, '../..')
from ieee_style import plt
import numpy as np
from mc_common import FS, rocof_signal, add_noise
from methods.extra_estimators import bandpass, analytic_if, ipdft_track, esprit_track, sogi_fll, cwt_track
from methods.extra2 import pmu_frequency
from PyEMD import CEEMDAN
t, y0, ft = rocof_signal()
for seed in range(30, 50):
    y = add_noise(y0, 30, np.random.default_rng(seed))
    c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(seed); imfs = c.ceemdan(y, t)
    fh = min((analytic_if(q, FS)[1] for q in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50))
    mm = (t >= .4) & (t <= .55); e = float(np.sqrt(np.mean((fh[mm]-ft[mm])**2))); print('seed', seed, 'HHT ramp RMSE %.2f Hz' % e)
    if 1.2 <= e <= 2.0: break
tr = {'PF+Hilbert': (t, analytic_if(bandpass(y, FS, 40, 60), FS)[1]), 'IpDFT': ipdft_track(y, FS, (40, 60), 240, 8)[:2],
      'ESPRIT': esprit_track(y, FS, 50, 6, 160, 16), 'M class': (t, pmu_frequency(y, FS, 50.0, 'M')[0]),
      'SOGI-FLL': (t, sogi_fll(y, FS, 50.0)[0])}
st = {'PF+Hilbert': ('#c0392b', '-'), 'IpDFT': ('#e67e22', '--'), 'ESPRIT': ('#6a1b9a', '-'), 'M class': ('#1a5fb4', '-.'), 'SOGI-FLL': ('#2e7d32', ':')}
fig, ax = plt.subplots(3, 1, figsize=(7.1, 6.2), sharex=True); w = lambda tt: (tt >= 0.3) & (tt <= 0.85)
for k, (tt, f) in tr.items():
    m = w(tt); c_, ls = st[k]; ax[0].plot(1000*tt[m], f[m], color=c_, ls=ls, lw=1.0, label=k); ax[1].plot(1000*tt[m], f[m]-np.interp(tt[m], t, ft), color=c_, ls=ls, lw=1.0)
m = w(t); ax[0].plot(1000*t[m], ft[m], color='k', lw=1.8, label='True', zorder=6)
ax[2].plot(1000*t[m], fh[m], color='#777777', lw=0.6, label='Full HHT (CEEMDAN)'); ax[2].plot(1000*t[m], ft[m], color='k', lw=1.8, label='True')
for a_ in ax: a_.axvspan(400, 550, color='#e8e8e8', zorder=0)
ax[0].set_ylim(49.1, 50.3); ax[0].set_ylabel('Frequency (Hz)'); ax[0].legend(ncol=3, fontsize=6.5, loc='upper right'); ax[0].set_title('(a) Narrowband estimators', fontsize=8.5)
ax[1].set_ylim(-0.5, 0.5); ax[1].axhline(0, color='k', lw=0.5); ax[1].set_ylabel('Error (Hz)'); ax[1].set_title('(b) Error of the narrowband estimators', fontsize=8.5)
ax[2].set_ylim(44, 56); ax[2].set_ylabel('Frequency (Hz)'); ax[2].set_xlabel('Time (ms)'); ax[2].legend(fontsize=6.5, loc='upper right'); ax[2].set_title('(c) Full EMD-based pipeline (wide scale)', fontsize=8.5)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'rocof_example.pdf')); print('ok')
