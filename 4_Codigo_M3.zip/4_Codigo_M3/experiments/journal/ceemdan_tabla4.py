"""Tasas de exito de CEEMDAN y FN-EMD en el escenario S (Tabla 4 de M3), reproduciendo exactamente mc1_stationary:
mismas semillas de ruido (100*SNR + indice de configuracion), misma semilla de CEEMDAN (1000 + r), 15 realizaciones."""
import sys; sys.path.insert(0, '../..'); sys.path.insert(0, '.')
import numpy as np, json, warnings; warnings.filterwarnings('ignore')
import mc1_stationary as M
from PyEMD import CEEMDAN
from methods.extra_estimators import bandstop
import os
t = M.time_vector(); m = (t > 0.05) & (t < 0.45)
OUT = json.load(open('res_ceemdan_tabla4.json')) if os.path.exists('res_ceemdan_tabla4.json') else {}
for SNR in [30, 60]:
    OUT.setdefault(str(SNR), {})
    for node, th in M.CONFIGS.items():
        if node in OUT[str(SNR)]: continue
        f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5); rng = np.random.default_rng(100*SNR + list(M.CONFIGS).index(node)); y0 = M.y_model(th, t)
        res = {'CEEMDAN': [], 'FN-EMD': []}
        for r in range(15):
            y = M.add_noise(y0, SNR, rng)
            for key, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
                c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(1000 + r)
                imfs = c.ceemdan(bandstop(y, M.FS, 40, 60) if pre else y, t); f = M.band_imf(imfs, M.FS, b2, m)
                res[key].append(f is not None and abs(f - f2)/f2 < 0.01)
        OUT[str(SNR)][node] = {k: 100*float(np.mean(v)) for k, v in res.items()};         print(f"SNR {SNR} {node}: CEEMDAN {OUT[str(SNR)][node]['CEEMDAN']:.0f} % | FN-EMD {OUT[str(SNR)][node]['FN-EMD']:.0f} %", flush=True)
json.dump(OUT, open('res_ceemdan_tabla4.json', 'w'), indent=1)
