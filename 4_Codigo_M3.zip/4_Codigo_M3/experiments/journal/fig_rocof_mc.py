import os
import sys, json; sys.path.insert(0, '../../methods')
from ieee_style import plt
import numpy as np
d = json.load(open('res_mc2_rocof.json')); r30 = json.load(open('res_mc10_ceemdan100.json'))['R30']
d['30']['Full HHT (CEEMDAN)'] = r30                                   # 100 realizations at 30 dB
snr = [40, 30, 20, 15]
st = {'PF+Hilbert': ('#c0392b', '-', 'o'), 'PF+Hilbert (causal)': ('#c0392b', ':', 'o'), 'ESPRIT': ('#6a1b9a', '-', 'D'), 'IpDFT': ('#e67e22', '--', 's'),
      'SOGI-FLL': ('#2e7d32', '-.', '^'), 'CWT (L1)': ('#1a5fb4', '--', 'v'), 'VMD+Hilbert': ('#777777', '-.', 'x'), 'Full HHT (CEEMDAN)': ('#000000', '-', '*')}
fig, ax = plt.subplots(1, 2, figsize=(7.1, 3.2), sharey=True)
for j, w in enumerate(['ramp', 'settled']):
    for k, (c, ls, mk) in st.items():
        med = [d[str(s)][k][w]['med'] for s in snr]; lo = [d[str(s)][k][w]['p25'] for s in snr]; hi = [d[str(s)][k][w]['p75'] for s in snr]
        ax[j].errorbar(snr, med, yerr=[np.subtract(med, lo), np.subtract(hi, med)], color=c, ls=ls, marker=mk, ms=3.5, lw=1.0, capsize=2, label=k)
    ax[j].set_yscale('log'); ax[j].invert_xaxis(); ax[j].set_xlabel('SNR (dB)'); ax[j].set_xticks(snr)
    ax[j].set_title('(a) Ramp, 400--550 ms' if j == 0 else '(b) Settled, 600--800 ms', fontsize=9)
ax[0].set_ylabel('Frequency RMSE (Hz)'); ax[0].set_ylim(0.008, 30)
h, l = ax[0].get_legend_handles_labels(); fig.legend(h, l, loc='lower center', ncol=4, fontsize=6.5, frameon=False, bbox_to_anchor=(0.5, 0.0))
plt.tight_layout(rect=[0, 0.12, 1, 1]); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'rocof_mc.pdf')); print('Fig 4 regenerada')
