import os
import sys; sys.path.insert(0, '../../methods'); sys.path.insert(0, '.'); sys.path.insert(0, '../..')
from ieee_style import plt
import numpy as np
from mc_common import FS, transient_signal, rocof_signal, add_noise
from methods.ground_truth import CONFIGS
from methods.extra_estimators import analytic_if, bandpass, vmd_modes
from methods.extra2 import matrix_pencil, pmu_frequency
import mc4_transient as m4
from PyEMD import CEEMDAN
# ---------------- Scenario D
t, y0, env = transient_signal(t0=m4.T0); T0 = m4.T0; late = t > T0+0.15
for seed in range(2027, 2045):
    y = add_noise(y0, 30, np.random.default_rng(seed))
    c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(seed); imfs = c.ceemdan(y, t); sc = []
    for imf in imfs:
        a, fi = analytic_if(imf, FS); e = (t >= T0) & (t < T0+0.06)
        sc.append(np.mean((fi[e] > 90) & (fi[e] < 150))*min(np.mean(a[(t >= T0) & (t < T0+0.05)])/(np.mean(a[late])+1e-9), 20))
    a_n, f_n = analytic_if(imfs[int(np.argmax(sc))], FS); fmed = np.median(f_n[(t > T0+.005) & (t < T0+.04)])
    print('seed', seed, 'IMF elegido: %.1f Hz' % fmed)
    if 45 <= fmed <= 65: break
f_g, tau_g = m4.emd_guided(t, y, imfs)
seg = (t >= T0+0.002) & (t <= T0+0.10); fm, sm, am = matrix_pencil(y[seg], FS, 8); k = (fm > 90) & (fm < 150); i = np.argmin(abs(fm[k]-120))
f_mp, s_mp, A_mp = fm[k][i], sm[k][i], am[k][i]
print(f'D: naive IMF median f (onset+5..40 ms) = {np.median(f_n[(t > T0+.005) & (t < T0+.04)]):.1f} Hz; guided f={f_g:.2f}, tau={1000*tau_g:.1f} ms; MP f={f_mp:.2f}, tau={-1000/s_mp:.1f} ms')
w = (t >= T0-0.03) & (t <= T0+0.08); tm = 1000*t[w]
fig, ax = plt.subplots(3, 1, figsize=(3.6, 5.6), sharex=True)
ax[0].plot(tm, y[w], color='#000000', lw=0.6); ax[0].axvline(1000*T0, color='#888888', ls=':', lw=0.8); ax[0].set_ylabel('Voltage (kV)')
on = t[w] >= T0
ax[1].axhline(120, color='#bbbbbb', lw=4, label='True (120 Hz)', zorder=1); ax[1].plot(tm, np.clip(f_n[w], 0, 200), color='#c0392b', lw=0.8, label='HHT, selected IMF')
ax[1].plot(tm[on], np.full(on.sum(), f_g), color='#2e7d32', ls='--', lw=1.3, label='EMD-guided LM'); ax[1].plot(tm[on], np.full(on.sum(), f_mp), color='#1a5fb4', ls=':', lw=1.5, label='Matrix Pencil')
ax[1].set_ylim(0, 200); ax[1].set_ylabel('Inst. frequency (Hz)'); ax[1].legend(fontsize=6, loc='lower right', ncol=2)
ax[2].plot(tm, env[w], color='#000000', lw=1.4, label=r'True, $\tau$ = 15 ms'); ax[2].plot(tm, a_n[w], color='#c0392b', lw=0.8, label='HHT, selected IMF')
ax[2].plot(tm[on], A_mp*np.exp(s_mp*(t[w][on]-T0-0.002)), color='#1a5fb4', ls=':', lw=1.5, label='Matrix Pencil')
ax[2].set_ylabel('Envelope (kV)'); ax[2].set_xlabel('Time (ms)'); ax[2].legend(fontsize=6, loc='upper right')
for a_, l in zip(ax, '(a)(b)(c)'.replace(')(', ') (').split()): a_.text(0.02, 0.9, l, transform=a_.transAxes, fontsize=8)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'scenarioD_frequency.pdf'))
print('D ok')
