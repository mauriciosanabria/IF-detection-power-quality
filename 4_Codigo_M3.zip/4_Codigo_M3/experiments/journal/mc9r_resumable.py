"""mc9r_resumable.py -- U3 (bursts) and U4 (crossing frequencies), resumable.
Each realization r uses its own seed and is appended to <scen>_raw.jsonl as soon as it finishes;
re-running skips realizations already stored. `python3 mc9r_resumable.py aggregate` merges the
results into res_mc9_new_scenarios.json (keeping U5). Same signals and metrics as mc9."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from scipy.signal import spectrogram
from mc_common import FS, A1, tvec, base, add_noise, summarize
from methods.extra_estimators import bandpass, bandstop, analytic_if, ipdft_track, stft_track, vmd_modes, esprit
from methods.extra2 import fsst, ridge, top_peaks
from methods.hht_emd import emd_decompose
from mc9_new_scenarios import score_bursts, ceemdan, sm
D = os.path.dirname(os.path.abspath(__file__)); N = 100


def done(scen):
    p = os.path.join(D, f'{scen}_raw.jsonl')
    return {json.loads(l)['r'] for l in open(p)} if os.path.exists(p) else set()


def save(scen, row):
    with open(os.path.join(D, f'{scen}_raw.jsonl'), 'a') as fh: fh.write(json.dumps(row) + '\n'); fh.flush(); os.fsync(fh.fileno())


def U3(r):
    t = tvec(1.0); rng = np.random.default_rng(930000+r)
    fb, ab = rng.uniform(150, 450), rng.uniform(0.10, 0.30)*A1
    starts = [0.15+rng.uniform(0, .05), 0.45+rng.uniform(0, .05), 0.75+rng.uniform(0, .05)]
    y = base(t)
    for s in starts:
        e = np.clip((t-s)/0.005, 0, 1)*np.clip((s+0.06-t)/0.005, 0, 1); e = 0.5-0.5*np.cos(np.pi*e)
        y = y + ab*e*np.sin(2*np.pi*fb*t + rng.uniform(-np.pi, np.pi))
    y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60); tr = {}
    a, f = analytic_if(bandpass(yn, FS, 60, 500), FS); tr['Notch+BP+Hilbert'] = (t, a, sm(f))
    tt, f, a = stft_track(yn, FS, (60, 500), nperseg=128, step=4, nfft=1024); tr['STFT'] = (tt, a, f)
    tc, f, a = ipdft_track(yn, FS, (60, 500), win=120, hop=8); tr['IpDFT'] = (tc, a, f)
    tc, fr, T, F = fsst(yn, FS, nw=128, hop=4, band=(60, 500)); tc, f, a = ridge(tc, fr, T, F); tr['FSST'] = (tc, a, f)
    u, c = vmd_modes(y, FS, 3); cand = [i for i in range(3) if 60 <= c[i] <= 500]
    if cand:
        i = max(cand, key=lambda i: np.std(u[i])); a, f = analytic_if(u[i], FS); tr['VMD (K=3)'] = (t, a, sm(f))
    for key, x, seed in [('CEEMDAN', y, 9300+r), ('FN-EMD', yn, 9500+r)]:
        best = None
        for imf in ceemdan(x, t, seed):
            a, f = analytic_if(imf, FS); hi = a > np.percentile(a, 80); mf = np.median(f[hi])
            if 60 <= mf <= 500 and (best is None or np.std(imf) > best[0]): best = (np.std(imf), a, sm(f))
        if best: tr[key] = (t, best[1], best[2])
    row = {'r': r}
    for k in ['Notch+BP+Hilbert', 'STFT', 'IpDFT', 'FSST', 'VMD (K=3)', 'CEEMDAN', 'FN-EMD']:
        if k in tr:
            d, fa, on, fo = score_bursts(*tr[k], starts, fb); row[k] = [d, fa, [float(x) for x in on], fo]
        else: row[k] = [0, 0, [], 0]
    return row


def U4(r):
    t = tvec(1.0); fc = 150 + 200*t; fl, fh = np.minimum(250, fc), np.maximum(250, fc); rng = np.random.default_rng(940000+r)
    ok_t = lambda tt: (tt >= 0.1) & (tt <= 0.9) & (np.abs(tt-0.5) > 0.08)
    def score(tt, pair):
        m = ok_t(tt); p = np.sort(pair[:, m], axis=0); lo, hi = np.interp(tt[m], t, fl), np.interp(tt[m], t, fh)
        if np.mean(~np.isfinite(p).all(axis=0)) > 0.2: return None
        g = np.isfinite(p).all(axis=0); return float(np.sqrt(np.mean(np.concatenate([(p[0, g]-lo[g])**2, (p[1, g]-hi[g])**2]))))
    def imf_pair(modes):
        c = []
        for x in modes:
            a, f = analytic_if(x, FS); mf = np.median(f[(t > .1) & (t < .9)])
            if 100 <= mf <= 450: c.append((np.std(x), sm(f)))
        c = sorted(c, key=lambda q: -q[0])[:2]
        return np.vstack([q[1] for q in c]) if len(c) == 2 else None
    y = base(t) + 0.2*A1*np.sin(2*np.pi*250*t + rng.uniform(-np.pi, np.pi)) + 0.2*A1*np.sin(2*np.pi*(150*t + 100*t**2) + rng.uniform(-np.pi, np.pi))
    y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60); row = {'r': r}
    f, tt, S = spectrogram(yn, fs=FS, nperseg=256, noverlap=248, window='hann', nfft=2048); b = (f >= 100) & (f <= 450)
    row['STFT'] = score(tt, top_peaks(f[b], S[b], 2, 10))
    tc, fr, T, F = fsst(yn, FS, nw=256, hop=8, band=(100, 450)); row['FSST'] = score(tc, top_peaks(fr, T, 2, 10))
    cen, pr = [], []
    for s in range(0, len(yn)-240+1, 16):
        fe, _, a = esprit(yn[s:s+240], FS, 12, L=120); k = (fe >= 100) & (fe <= 450)
        q = fe[k][np.argsort(a[k])[::-1][:2]] if k.sum() >= 2 else np.array([np.nan, np.nan]); cen.append((s+120)/FS); pr.append(q)
    row['ESPRIT (sliding)'] = score(np.array(cen), np.array(pr).T)
    u, c = vmd_modes(y, FS, 4); p = imf_pair(u); row['VMD (K=4)'] = score(t, p) if p is not None else None
    p = imf_pair(emd_decompose(t, yn, max_imfs=10)[:-1]); row['EMD'] = score(t, p) if p is not None else None
    p = imf_pair(ceemdan(yn, t, 9700+r)); row['CEEMDAN'] = score(t, p) if p is not None else None
    return row


def aggregate():
    P = os.path.join(D, 'res_mc9_new_scenarios.json'); OUT = json.load(open(P)) if os.path.exists(P) else {}
    rows = [json.loads(l) for l in open(os.path.join(D, 'U3_raw.jsonl'))] if os.path.exists(os.path.join(D, 'U3_raw.jsonl')) else []
    if rows:
        OUT['U3'] = {}
        for k in [k for k in rows[0] if k != 'r']:
            det = sum(x[k][0] for x in rows); fa = [x[k][1] for x in rows]; on = [o for x in rows for o in x[k][2]]; fo = sum(x[k][3] for x in rows)
            OUT['U3'][k] = dict(detection=det/(3*len(rows)), false_per_record=float(np.mean(fa)), onset_err_ms=summarize(1000*np.array(on)), freq_success=fo/(3*len(rows)), n=len(rows))
    rows = [json.loads(l) for l in open(os.path.join(D, 'U4_raw.jsonl'))] if os.path.exists(os.path.join(D, 'U4_raw.jsonl')) else []
    if rows:
        OUT['U4'] = {k: dict(rmse=summarize([x[k] for x in rows]), success=float(np.mean([x[k] is not None and x[k] < 2 for x in rows])), n=len(rows))
                     for k in rows[0] if k != 'r'}
    json.dump(OUT, open(P, 'w'), indent=1)
    for s in ['U3', 'U4']:
        if s in OUT: print(s, {k: (round(v.get('detection', v.get('success')), 2), v['n']) for k, v in OUT[s].items()})


if __name__ == '__main__':
    if sys.argv[1:] == ['aggregate']:
        aggregate(); sys.exit()
    for scen, fn in [('U3', U3), ('U4', U4)]:
        have = done(scen)
        for r in range(N):
            if r not in have:
                save(scen, fn(r)); print(scen, r, flush=True)
    aggregate()
