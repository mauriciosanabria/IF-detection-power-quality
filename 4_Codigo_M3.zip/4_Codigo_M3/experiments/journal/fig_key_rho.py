import os
import sys; sys.path.insert(0, '../../methods'); sys.path.insert(0, '.'); sys.path.insert(0, '../..')
from ieee_style import plt
plt.rcParams['mathtext.fontset'] = 'stix'
import numpy as np
from methods.ground_truth import CONFIGS
fs = 40000; t = np.arange(0, 0.04, 1/fs)
def extrema(y):
    d = np.diff(y); return np.where((d[:-1] > 0) & (d[1:] <= 0) | (d[:-1] < 0) & (d[1:] >= 0))[0] + 1
fig = plt.figure(figsize=(7.1, 5.8)); gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], hspace=0.42, wspace=0.25)
cases = [(fig.add_subplot(gs[0, 0]), 0.02, 91.23, r'(a) $\rho = 0.037$: 2 % tone at 91 Hz (Scenario S, $v_1$)'),
         (fig.add_subplot(gs[0, 1]), 0.50, 150.0, r'(b) $\rho = 1.5$: 50 % tone at 150 Hz')]
for ax, ar, f2, title in cases:
    fund = np.sin(2*np.pi*50*t); y = fund + ar*np.sin(2*np.pi*f2*t + 0.4)
    ax.plot(1000*t, fund, color='#999999', lw=0.9, ls='--', label='Fundamental alone')
    ax.plot(1000*t, y, color='#000000', lw=1.1, label='Fundamental + tone')
    e = extrema(y); ef = extrema(fund)
    ax.plot(1000*t[e], y[e], 'o', ms=4.5, mfc='#c0392b', mec='#c0392b', label='Extrema used by EMD')
    ax.set_title(title, fontsize=8.5); ax.set_xlabel('Time (ms)'); ax.set_xlim(0, 40); ax.set_ylim(-1.75, 1.95)
    ax.text(0.98, 0.04, f'{len(e)} extrema vs. {len(ef)} of a pure 50 Hz tone', transform=ax.transAxes, ha='right', fontsize=7.5)
cases[0][0].set_ylabel('Amplitude (p.u.)')
h, l = cases[0][0].get_legend_handles_labels(); fig.legend(h, l, loc='upper center', bbox_to_anchor=(0.5, 1.0), ncol=3, frameon=False, fontsize=7.5)
ax = fig.add_subplot(gs[1, :]); f = np.logspace(np.log10(60), np.log10(1100), 200)
ax.fill_between(f, 100*50/f, 400, color='#2e7d32', alpha=0.12, lw=0); ax.plot(f, 100*50/f, color='#2e7d32', lw=1.6)
ax.fill_between(f, 100*(50/f)**2, 100*50/f, color='#e67e22', alpha=0.12, lw=0); ax.plot(f, 100*(50/f)**2, color='#c0392b', lw=1.3, ls='--')
ax.text(900, 1.6, 'intermittent\nextrema', fontsize=7.5, color='#b9770e', ha='center')
ax.text(800, 17, r'$\rho > 1$: own extrema,' + '\nEMD can isolate it', fontsize=8, color='#2e7d32', ha='center')
ax.text(560, 0.042, r'$a_k f_k^2 < a_1 f_1^2$: extrema identical' + '\nto those of the fundamental; EMD' + '\nmerges the component with it', fontsize=7.5, color='#c0392b', ha='center', va='bottom')
for node, mk in [('v1', 'o'), ('v3', 's'), ('v2', 'D')]:
    th = CONFIGS[node]; r = 100*abs(th[3])/th[0]
    ax.plot(th[4], r, mk, ms=6, color='#c0392b'); left = node == 'v1'
    ax.annotate(f'S, {node}: $\\rho$={abs(th[3])*th[4]/(th[0]*50):.3f}', (th[4], r), xytext=(-6 if left else 6, -3), textcoords='offset points', fontsize=7.2, ha='right' if left else 'left')
ax.plot(120, 100*60/127.84, '^', ms=7, color='#1a5fb4'); ax.annotate(r'D at onset: $\rho$=1.13, below 1 after 1.8 ms', (120, 100*60/127.84), xytext=(10, 8), textcoords='offset points', fontsize=7.2)
ax.add_patch(plt.Rectangle((70, 10), 380, 20, fill=False, ec='#6a1b9a', lw=1.1, ls='--')); ax.text(163, 13, 'U1: random draws', fontsize=7.2, color='#6a1b9a', va='center')
ax.plot([110, 110], [100*0.6/127.84, 100*0.6*np.exp(6*0.55)/127.84], color='#e67e22', lw=2.2); ax.text(116, 0.9, 'G: grows from 0.47 %', fontsize=7.2, color='#e67e22')
from matplotlib.lines import Line2D
ax.legend([Line2D([0], [0], color='#2e7d32', lw=1.6), Line2D([0], [0], color='#c0392b', lw=1.3, ls='--')], [r'$\rho = a_k f_k/(a_1 f_1) = 1$ (slope)', r'$a_k f_k^2 = a_1 f_1^2$ (curvature)'], loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2, frameon=False, fontsize=7.5)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(60, 1100); ax.set_ylim(0.03, 400)
ax.set_yticks([0.1, 1, 10, 100]); ax.set_yticklabels(['0.1', '1', '10', '100'])
ax.set_xticks([70, 100, 150, 250, 400, 650, 1000]); ax.set_xticklabels(['70', '100', '150', '250', '400', '650', '1000'])
ax.set_xlabel('Frequency of the component $f_k$ (Hz)'); ax.set_ylabel(r'Amplitude $a_k/a_1$ (%)')
ax.set_title(r'(c) Three regimes of the amplitude-frequency plane and the test components of this study', fontsize=8.5)
plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'key_slope_criterion.pdf'), bbox_inches='tight'); print('ok')
