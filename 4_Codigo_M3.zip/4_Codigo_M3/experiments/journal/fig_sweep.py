import os
import sys, json; sys.path.insert(0, '../../methods')
from ieee_style import plt
import numpy as np
d = json.load(open('res_mc6_sweep.json'))
R = sorted({x['r'] for x in d}); F = sorted({x['f2'] for x in d})
meths = ['IpDFT', 'ESPRIT', 'PF+Hilbert', 'VMD', 'EMD', 'CEEMDAN']
fig, axs = plt.subplots(2, 3, figsize=(7.1, 4.6), sharex=True, sharey=True)
for ax, m in zip(axs.flat, meths):
    Z = np.array([[next(x[m] for x in d if x['r'] == r and x['f2'] == f) for f in F] for r in R])
    ax.pcolormesh(np.arange(len(F)+1), np.arange(len(R)+1), Z, cmap='Greys', vmin=0, vmax=1, shading='flat')
    for i, r in enumerate(R):
        for j, f in enumerate(F):
            ax.text(j+0.5, i+0.5, f'{100*Z[i, j]:.0f}', ha='center', va='center', fontsize=5.2, color='white' if Z[i, j] > 0.55 else 'black')
    # rho = 1 boundary: r = 50/f
    xs = np.linspace(0, len(F), 200); fx = np.interp(xs-0.5, np.arange(len(F)), np.log(F)); rr = np.log(50/np.exp(fx))
    ys = np.interp(rr, np.log(R), np.arange(len(R))) + 0.5
    ok = (rr >= np.log(R[0])) & (rr <= np.log(R[-1])); ax.plot(xs[ok], ys[ok], color='#c0392b', lw=1.3, ls='--')
    ax.set_title(m, fontsize=8.5)
for ax in axs[-1]: ax.set_xticks(np.arange(len(F))+0.5); ax.set_xticklabels(F, fontsize=6.5); ax.set_xlabel('$f_2$ (Hz)', fontsize=8)
for ax in axs[:, 0]: ax.set_yticks(np.arange(len(R))+0.5); ax.set_yticklabels([f'{100*r:g}' for r in R], fontsize=6.5); ax.set_ylabel('$a_2/a_1$ (%)', fontsize=8)
for ax in axs.flat: ax.tick_params(direction='out', top=False, right=False)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'sweep_map.pdf'))
