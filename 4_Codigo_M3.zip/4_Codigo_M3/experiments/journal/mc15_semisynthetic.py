"""mc15_semisynthetic.py -- semi-synthetic validation: Scenarios R and G with the measured background
(residual of the EV-charger voltage recordings, i.e. everything but the fundamental, rescaled to the
127.84 kV fundamental) instead of white Gaussian noise. Realizations = circular shifts of the background.
Also estimates the fundamental frequency of the two real recordings with every tracker (consistency)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np, rlib, realbg
from scipy.signal import remez, lfilter
from mc_common import FS, rocof_signal, growing_signal, detect, logfit_rate
from methods.ground_truth import CONFIGS
from methods.extra_estimators import bandpass, bandstop, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track, vmd_modes
from methods.extra2 import pmu_frequency, fsst, ridge
from PyEMD import CEEMDAN
BG = realbg.background(8000); HB = remez(401, [20, FS/2-20], [1], type='hilbert', fs=FS)
def ce(y, t, s): c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(s); return c.ceemdan(y, t)
def causal_if(y, lo, hi):
    x = bandpass(y, FS, lo, hi, causal=True); xd = np.concatenate([np.zeros(200), x[:-200]]); z = xd - 1j*lfilter(HB, 1, x)
    f = np.diff(np.unwrap(np.angle(z)))*FS/(2*np.pi); return np.concatenate([[f[0]], f]), np.abs(z)
# ---------------- consistency on the real recordings
if not rlib.done('real_f'):
    for nm in ['con', 'sin']:
        t, x, r, f_ls, A = realbg.residual(nm); x = x*127.84/A; m = (t > 0.1) & (t < 0.4); est = {'Least squares (whole record)': f_ls}
        est['PF+Hilbert'] = float(np.median(analytic_if(bandpass(x, FS, 40, 60), FS)[1][m])); est['SOGI-FLL'] = float(np.median(sogi_fll(x, FS, 50.0)[0][m]))
        tc, fi, _ = ipdft_track(x, FS, (40, 60), 240, 8); est['IpDFT'] = float(np.median(fi[(tc > .1) & (tc < .4)]))
        tc, fe = esprit_track(x, FS, 50, 6, 160, 16); est['ESPRIT'] = float(np.median(fe[(tc > .1) & (tc < .4)]))
        for k in ['P', 'M']: est[f'{k} class'] = float(np.median(pmu_frequency(x, FS, 50.0, k)[0][m]))
        est['CWT (L1)'] = float(np.median(cwt_track(x, FS, 40, 60)[m]))
        tc, fr, T, F = fsst(x, FS, band=(40, 60)); tc, fe, _ = ridge(tc, fr, T, F); est['FSST'] = float(np.median(fe[(tc > .1) & (tc < .4)]))
        u, c = vmd_modes(x, FS, 3); est['VMD+Hilbert'] = float(np.median(analytic_if(u[np.argmin(abs(c-50))], FS)[1][m]))
        imfs = ce(x, t, 1); est['Full HHT (CEEMDAN)'] = float(np.median(min((analytic_if(q, FS)[1] for q in imfs), key=lambda q: abs(np.median(q[m])-50))[m]))
        rlib.save('real_f', dict(key=nm, r=0, est=est, residual_pct=float(100*np.std(r)/(127.84/np.sqrt(2)))))
    print('real_f done', flush=True)
# ---------------- Scenario R with real background
t, yR, ft = rocof_signal(); a1, f1, p1, a2, f2, p2, a3, f3, p3 = CONFIGS['v1']
yR = yR - a2*np.sin(2*np.pi*f2*t+p2) - a3*np.sin(2*np.pi*f3*t+p3)          # fundamental only; the background supplies the rest
def rm(tt, f, lag=0.0):
    o = []
    for a, b in [(.4, .55), (.6, .8)]:
        mm = (tt >= a) & (tt <= b); o.append(float(np.sqrt(np.mean((f[mm]-np.interp(tt[mm]-lag, t, ft))**2))))
    return o
have = rlib.done('semi_R'); rng = np.random.default_rng(150)
shifts = rng.integers(0, 4000, 100)
for r in range(100):
    if ('R', r) in have: continue
    y = yR + BG[shifts[r]:shifts[r]+len(t)]; res = {}
    res['PF+Hilbert'] = rm(t, analytic_if(bandpass(y, FS, 40, 60), FS)[1]); res['PF+Hilbert (causal)'] = rm(t, causal_if(y, 40, 60)[0], 0.112)
    res['CWT (L1)'] = rm(t, cwt_track(y, FS, 40, 60)); res['SOGI-FLL'] = rm(t, sogi_fll(y, FS, 50.0)[0])
    tc, fi, _ = ipdft_track(y, FS, (40, 60), 240, 8); res['IpDFT'] = rm(tc, fi)
    tc, fe = esprit_track(y, FS, 50, 6, 160, 16); res['ESPRIT'] = rm(tc, fe)
    for k in ['P', 'M']: res[f'{k} class'] = rm(t, pmu_frequency(y, FS, 50.0, k)[0])
    tc, fr, T, F = fsst(y, FS, band=(40, 60)); tc, fe, _ = ridge(tc, fr, T, F); res['FSST'] = rm(tc, fe)
    u, c = vmd_modes(y, FS, 3); res['VMD+Hilbert'] = rm(t, analytic_if(u[np.argmin(abs(c-50))], FS)[1])
    if r < 20:
        imfs = ce(y, t, 150000+r); res['Full HHT (CEEMDAN)'] = rm(t, min((analytic_if(q, FS)[1] for q in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50)))
    rlib.save('semi_R', dict(key='R', r=r, res=res))
print('semi_R done', flush=True)
# ---------------- Scenario G with real background
T0, TT = 0.50, 1.05; t, yG, env = growing_signal(T=TT, t0=T0); yG = yG - a2*np.sin(2*np.pi*f2*t+p2) - a3*np.sin(2*np.pi*f3*t+p3)
have = rlib.done('semi_G')
for r in range(100):
    if ('G', r) in have: continue
    y = yG + BG[shifts[r]:shifts[r]+len(t)]; res = {}
    def put(k, tt, a):
        td = detect(tt, a, (0.30, 0.48), (0.48, TT-0.03)); res[k] = [None if (td is None or td < T0) else td-T0, bool(td is not None and td < T0), logfit_rate(tt, a, (T0+0.05, TT-0.08))]
    put('SOGI (causal)', t, sogi_fll(bandpass(y, FS, 95, 125, causal=True), FS, 110.0)[1]); put('PF+Hilbert (causal)', t, causal_if(y, 95, 125)[1])
    tc, _, a = ipdft_track(y, FS, (95, 125), 160, 8); put('IpDFT', tc + 0.02, a)
    tc, fr, T_, F = fsst(y, FS, nw=256, hop=4, band=(95, 125)); tc, fe, mg = ridge(tc, fr, T_, F); put('FSST', tc + 128/FS, mg)
    if r < 20:
        for k, pre in [('Full HHT (CEEMDAN)', False), ('FN-EMD', True)]:
            best, bd = None, 1e9
            for imf in ce(bandstop(y, FS, 40, 60) if pre else y, t, 151000+r):
                a, fi = analytic_if(imf, FS); md = np.median(fi[t > T0+0.2])
                if abs(md-110) < bd: bd, best = abs(md-110), a
            put(k, t, best)
    rlib.save('semi_G', dict(key='G', r=r, res=res))
print('semi_G done', flush=True)
