"""mc8_new_methods.py -- second revision round: Matrix Pencil, Prony, P/M-class synchrophasor
frequency and FSST added to scenarios S, R, D, G, U1 and U2 (100 realizations each)."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import (FS, A1, tvec, base, rocof_signal, growing_signal, transient_signal, add_noise,
                       detect, logfit_rate, summarize)
from methods.ground_truth import CONFIGS, y_model, time_vector
from methods.extra_estimators import bandpass, bandstop
from methods.extra2 import matrix_pencil, prony, pmu_frequency, fsst, ridge
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100; OUT = {}


def pole_near(f, s, a, target, lo, hi, by='near'):
    k = (f > lo) & (f < hi)
    if not k.any(): return np.nan, np.nan
    i = np.argmin(abs(f[k]-target)) if by == 'near' else np.argmax(a[k])
    return float(f[k][i]), float(s[k][i])


def scen_S():
    t = time_vector(); res = {}
    for snr in [30, 60]:
        for node, th in CONFIGS.items():
            f2 = th[4]; rng = np.random.default_rng(800+snr+list(CONFIGS).index(node)); y0 = y_model(th, t); ok = {'MP': [], 'Prony': []}
            for _ in range(N):
                y = add_noise(y0, snr, rng)
                for k, fn in [('MP', lambda: matrix_pencil(y, FS, 6)), ('Prony', lambda: prony(y, FS, 6))]:
                    f, s, a = fn(); fe = f[np.argmin(abs(f-f2))] if len(f) else np.nan
                    ok[k].append(bool(np.isfinite(fe) and abs(fe-f2)/f2 < 0.01))
            res[f'{snr}_{node}'] = {k: float(np.mean(v)) for k, v in ok.items()}
            print('S', snr, node, res[f'{snr}_{node}'], flush=True)
    OUT['S'] = res


def scen_R():
    t, y0, ft = rocof_signal(); res = {}
    def rm(tt, f, w): m = (tt >= w[0]) & (tt <= w[1]); g = np.interp(tt[m], t, ft); return float(np.sqrt(np.mean((f[m]-g)**2)))
    for snr in [40, 30, 20, 15]:
        rng = np.random.default_rng(810+snr); acc = {}
        for _ in range(N):
            y = add_noise(y0, snr, rng)
            for k in ['P', 'M']:
                f, _ = pmu_frequency(y, FS, 50.0, k); acc.setdefault(f'{k}-class', []).append((rm(t, f, (.4, .55)), rm(t, f, (.6, .8))))
            tc, fr, T, F = fsst(y, FS, band=(40, 60)); tc, fe, _ = ridge(tc, fr, T, F)
            acc.setdefault('FSST', []).append((rm(tc, fe, (.4, .55)), rm(tc, fe, (.6, .8))))
        res[snr] = {k: {'ramp': summarize([a for a, b in v]), 'settled': summarize([b for a, b in v])} for k, v in acc.items()}
        print('R', snr, {k: f"{v['ramp']['med']:.3f}/{v['settled']['med']:.3f}" for k, v in res[snr].items()}, flush=True)
    OUT['R'] = res


def scen_D():
    T0, TAU = 0.20, 0.015; t, y0, _ = transient_signal(t0=T0); rng = np.random.default_rng(820); acc = {}
    seg = (t >= T0+0.002) & (t <= T0+0.10); FIT = (T0+0.005, T0+0.040)
    for _ in range(N):
        y = add_noise(y0, 30, rng)
        for k, fn in [('MP', lambda: matrix_pencil(y[seg], FS, 8)), ('Prony', lambda: prony(y[seg], FS, 8))]:
            f, s, a = fn(); fe, se = pole_near(f, s, a, 120, 90, 150)
            acc.setdefault(k, []).append((fe, -1/se if np.isfinite(se) and se < 0 else np.nan))
        tc, fr, T, F = fsst(y, FS, nw=128, hop=2, band=(90, 150)); tc, fe, mg = ridge(tc, fr, T, F)
        s_ = logfit_rate(tc, mg, FIT); m = (tc >= FIT[0]) & (tc <= FIT[1])
        acc.setdefault('FSST', []).append((float(np.median(fe[m])), -1/s_ if s_ < 0 else np.nan))
    res = {}
    for k, v in acc.items():
        f = np.array([a for a, b in v], float); tau = np.array([b for a, b in v], float); right = np.isfinite(f) & (abs(f-120) < 5)
        res[k] = dict(right=float(right.mean()), f=summarize(f), tau_err=summarize(100*abs(tau-TAU)/TAU))
        print('D', k, f"right {100*res[k]['right']:.0f}% f {res[k]['f']['med']} tau_err {res[k]['tau_err']['med']}", flush=True)
    OUT['D'] = res


def scen_G():
    T0, T = 0.50, 1.05; t, y0, _ = growing_signal(T=T, t0=T0); rng = np.random.default_rng(830); acc = {}
    seg = (t >= T0+0.03) & (t <= T-0.05)
    for _ in range(N):
        y = add_noise(y0, 30, rng); xb = bandpass(y, FS, 95, 125)
        for k, fn in [('MP', lambda: matrix_pencil(xb[seg], FS, 2)), ('Prony', lambda: prony(xb[seg], FS, 2))]:
            f, s, a = fn(); acc.setdefault(k, {'rate': [], 'det': []})['rate'].append(pole_near(f, s, a, 110, 95, 125)[1])
        tc, fr, T_, F = fsst(y, FS, nw=256, hop=4, band=(95, 125)); tc, fe, mg = ridge(tc, fr, T_, F)
        tce = tc + 128/FS                                   # time-stamp at window end (on-line)
        td = detect(tce, mg, (0.30, 0.48), (0.48, T-0.03))
        d = acc.setdefault('FSST', {'rate': [], 'det': [], 'fa': []})
        d['rate'].append(logfit_rate(tce, mg, (T0+0.05, T-0.08))); d['fa'].append(td is not None and td < T0)
        d['det'].append(None if (td is None or td < T0) else td-T0)
    res = {}
    for k, v in acc.items():
        res[k] = {'growth_rate': summarize(v['rate'])}
        if v['det']:
            res[k].update(detect_prob=float(np.mean([x is not None for x in v['det']])), false_alarm=float(np.mean(v['fa'])), delay_s=summarize(v['det']))
        print('G', k, res[k], flush=True)
    OUT['G'] = res


def scen_U():
    t = tvec(0.5); m = (t > 0.05) & (t < 0.45); rng = np.random.default_rng(840); ok = {'MP': [], 'FSST': []}; rho = []
    for _ in range(N):
        fu, au, ph = rng.uniform(70, 450), rng.uniform(0.10, 0.30)*A1, rng.uniform(-np.pi, np.pi)
        y = add_noise(base(t) + au*np.sin(2*np.pi*fu*t+ph), 30, rng); rho.append(au*fu/(A1*50))
        f, s, a = matrix_pencil(y, FS, 10); fe = pole_near(f, s, a, 0, 60, 500, by='amp')[0]
        ok['MP'].append(bool(np.isfinite(fe) and abs(fe-fu)/fu < 0.01))
        tc, fr, T, F = fsst(bandstop(y, FS, 40, 60), FS, band=(60, 500)); tc, fe2, _ = ridge(tc, fr, T, F)
        ok['FSST'].append(bool(abs(np.median(fe2[(tc > .05) & (tc < .45)])-fu)/fu < 0.01))
    rho = np.array(rho); OUT['U1'] = {k: dict(success=float(np.mean(v)), rho_gt1=float(np.mean(np.array(v)[rho > 1])), rho_le1=float(np.mean(np.array(v)[rho <= 1]))) for k, v in ok.items()}
    print('U1', OUT['U1'], flush=True)
    T = 0.6; t = tvec(T); k_ = 250/T; ftrue = 150 + k_*t; y0 = base(t) + 0.4*A1*np.sin(2*np.pi*(150*t + 0.5*k_*t**2)); rng = np.random.default_rng(841); r = []
    for _ in range(N):
        y = add_noise(y0, 30, rng); tc, fr, T_, F = fsst(bandstop(y, FS, 40, 60), FS, band=(60, 600)); tc, fe, _ = ridge(tc, fr, T_, F)
        mm = (tc >= .1) & (tc <= .5); r.append(float(np.sqrt(np.mean((fe[mm]-np.interp(tc[mm], t, ftrue))**2))))
    OUT['U2'] = {'FSST': summarize(r)}; print('U2', OUT['U2'], flush=True)


if __name__ == '__main__':
    t0 = time.time()
    for f in [scen_S, scen_R, scen_D, scen_G, scen_U]:
        f(); json.dump(OUT, open(os.path.join(os.path.dirname(__file__), 'res_mc8_new_methods.json'), 'w'), indent=1)
    print(f"done {time.time()-t0:.0f}s")
