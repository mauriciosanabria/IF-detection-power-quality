"""mc13_rocof_stats.py -- Scenario R at 30 and 15 dB, 100 realizations, per-realization signed errors
(bias) and RMSE for paired statistics (bootstrap confidence intervals, Wilcoxon signed-rank tests)."""
import sys, os; sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np, rlib
from scipy.signal import remez, lfilter
from mc_common import FS, rocof_signal, add_noise
from methods.extra_estimators import bandpass, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track, vmd_modes
from methods.extra2 import pmu_frequency, fsst, ridge
t, y0, ft = rocof_signal(); HB = remez(401, [20, FS/2-20], [1], type='hilbert', fs=FS); LAG = 0.112
def causal(y):
    x = bandpass(y, FS, 40, 60, causal=True); xd = np.concatenate([np.zeros(200), x[:-200]])
    f = np.diff(np.unwrap(np.angle(xd - 1j*lfilter(HB, 1, x))))*FS/(2*np.pi); return np.concatenate([[f[0]], f])
def stats(tt, f, lag=0.0):
    out = {}
    for w, (a, b) in [('ramp', (.4, .55)), ('settled', (.6, .8))]:
        mm = (tt >= a) & (tt <= b); e = f[mm] - np.interp(tt[mm]-lag, t, ft)
        out[w] = [float(np.sqrt(np.mean(e**2))), float(np.mean(e)), float(np.std(e))]
    return out
for snr in [30, 15]:
    have = rlib.done('rstats')
    for r in range(100):
        if (str(snr), r) in have: continue
        y = add_noise(y0, snr, np.random.default_rng(130000 + 1000*snr + r)); res = {}
        res['PF+Hilbert'] = stats(t, analytic_if(bandpass(y, FS, 40, 60), FS)[1])
        res['PF+Hilbert (causal)'] = stats(t, causal(y), LAG)
        res['CWT (L1)'] = stats(t, cwt_track(y, FS, 40, 60)); res['SOGI-FLL'] = stats(t, sogi_fll(y, FS, 50.0)[0])
        tc, fi, _ = ipdft_track(y, FS, (40, 60), 240, 8); res['IpDFT'] = stats(tc, fi)
        tc, fe = esprit_track(y, FS, 50, 6, 160, 16); res['ESPRIT'] = stats(tc, fe)
        res['P class'] = stats(t, pmu_frequency(y, FS, 50.0, 'P')[0]); res['M class'] = stats(t, pmu_frequency(y, FS, 50.0, 'M')[0])
        tc, fr, T, F = fsst(y, FS, band=(40, 60)); tc, fe, _ = ridge(tc, fr, T, F); res['FSST'] = stats(tc, fe)
        u, c = vmd_modes(y, FS, 3); res['VMD+Hilbert'] = stats(t, analytic_if(u[np.argmin(abs(c-50))], FS)[1])
        rlib.save('rstats', dict(key=str(snr), r=r, res=res))
    print('rstats', snr, flush=True)
