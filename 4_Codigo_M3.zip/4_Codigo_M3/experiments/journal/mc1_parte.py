"""mc1_parte.py -- escenario S, una configuracion por ejecucion, con el MISMO codigo y semillas que mc1_stationary.run().
Uso: python3 mc1_parte.py SNR nodo [N_FAST N_EMD]. Acumula en res_mc1_stationary.json (mismo formato que el original)."""
import sys, os, json, time
SNR, NODE = int(sys.argv[1]), sys.argv[2]; NF = int(sys.argv[3]) if len(sys.argv) > 3 else 60; NE = int(sys.argv[4]) if len(sys.argv) > 4 else 15
sys.argv = [sys.argv[0], str(NF), str(NE)]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
import numpy as np, warnings; warnings.filterwarnings('ignore')
import mc1_stationary as M
from mc_common import FS, add_noise, summarize
t0 = time.time(); t = M.time_vector(); m = (t > 0.05) & (t < 0.45); th = M.CONFIGS[NODE]
f2 = th[4]; b2 = (max(60, f2*0.5), f2*1.5); bands = [(35, 65), b2, (th[7]*0.7, th[7]*1.3)]
rng = np.random.default_rng(100*SNR + list(M.CONFIGS).index(NODE))
errs = {k: [] for k in ['FFT-seq', 'IpDFT-seq', 'CWT-seq (L1)', 'ESPRIT', 'SOGI-FLL', 'PF+Hilbert', 'VMD (K=4)', 'FN-VMD (K=3)', 'EMD', 'CEEMDAN', 'FN-EMD']}
y0 = M.y_model(th, t)
for r in range(NF):
    y = add_noise(y0, SNR, rng); e = lambda f: np.nan if f is None else 100*abs(f-f2)/f2
    errs['FFT-seq'].append(e(M.fft_seq(t, y, FS, bands)[1][0]))
    errs['IpDFT-seq'].append(e(M.ipdft_sequential(y, t, FS, bands)[1]))
    errs['CWT-seq (L1)'].append(e(M.cwt_sequential(y, t, FS, bands)[1]))
    fe, _, a = M.esprit(y, FS, 6); errs['ESPRIT'].append(e(fe[np.argmin(abs(fe-np.mean(b2)))]) if len(fe) else np.nan)
    x = M.bandpass(M.bandstop(y, FS, 40, 60), FS, *b2)
    _, fi = M.analytic_if(x, FS); errs['PF+Hilbert'].append(e(np.median(fi[m])))
    so, _ = M.sogi_fll(x, FS, np.mean(b2)); errs['SOGI-FLL'].append(e(np.median(so[t > 0.25])))
    for key, K, pre in [('VMD (K=4)', 4, False), ('FN-VMD (K=3)', 3, True)]:
        u, c = M.vmd_modes(M.bandstop(y, FS, 40, 60) if pre else y, FS, K); inb = [i for i in range(K) if b2[0] <= c[i] <= b2[1]]
        if inb:
            i = max(inb, key=lambda i: np.std(u[i])); _, fv = M.analytic_if(u[i], FS); errs[key].append(e(np.median(fv[m])))
        else: errs[key].append(np.nan)
    est, _ = M.estimate_all_tones_hht(t, y, bands); errs['EMD'].append(e(est[1][0]))
    if r < NE:
        for key, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
            c = M.CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(1000+r)
            errs[key].append(e(M.band_imf(c.ceemdan(M.bandstop(y, FS, 40, 60) if pre else y, t), FS, b2, m)))
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'res_mc1_stationary.json'); out = json.load(open(P)) if os.path.exists(P) else {}
out.setdefault(str(SNR), {})[NODE] = {}
for k, v in errs.items():
    v = np.array(v, float); ok = np.isfinite(v) & (v < 1.0); out[str(SNR)][NODE][k] = dict(runs=int(len(v)), success=float(ok.mean()), **summarize(v))
json.dump(out, open(P, 'w'), indent=1)
print(SNR, NODE, {k: f"{100*d['success']:.0f}%" for k, d in out[str(SNR)][NODE].items()}, f"({time.time()-t0:.0f} s)", flush=True)
