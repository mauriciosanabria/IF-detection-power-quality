"""mc2_rocof.py -- RoCoF tracking, -4 Hz/s ramp at 400-550 ms inside a 1.0 s record.
RMSE over ramp (400-550 ms) and settled (600-800 ms) windows, far from record edges.
Fast methods: 100 realizations per SNR. Full HHT (CEEMDAN): 100 at 30 dB, 20 elsewhere."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from scipy.signal import remez, lfilter
from mc_common import FS, rocof_signal, add_noise, summarize
from methods.extra_estimators import (bandpass, analytic_if, cwt_track, sogi_fll, ipdft_track, esprit_track,
                                       vmd_modes, stft_track)
from PyEMD import CEEMDAN

N_FAST = int(sys.argv[1]) if len(sys.argv) > 1 else 100
HB = remez(401, [20, FS/2-20], [1], type='hilbert', fs=FS)       # FIR Hilbert transformer, delay 200 samples (50 ms)


def causal_pf_hilbert(y):
    x = bandpass(y, FS, 40, 60, causal=True)
    xd = np.concatenate([np.zeros(200), x[:-200]])                 # align real part with FIR delay
    ph = np.unwrap(np.angle(xd - 1j*lfilter(HB, 1, x)))   # remez hilbert design: opposite sign convention
    f = np.diff(ph)*FS/(2*np.pi)
    return np.concatenate([[f[0]], f])


def rmse(tt, f, t, ftrue, win, lag=0.0):
    ft = np.interp(tt - lag, t, ftrue); m = (tt >= win[0]) & (tt <= win[1]) & np.isfinite(f)
    return float(np.sqrt(np.mean((f[m]-ft[m])**2)))


def run():
    t, y0, ftrue = rocof_signal()
    RAMP, SETT = (0.40, 0.55), (0.60, 0.80)
    # latency of the causal pipeline, measured once on the noise-free signal
    fc = causal_pf_hilbert(y0)
    lags = np.arange(0, 0.25, 0.0005)
    lag = float(lags[np.argmin([rmse(t, fc, t, ftrue, (0.3, 0.85), L) for L in lags])])
    print(f"causal PF+Hilbert latency: {lag*1000:.1f} ms", flush=True)
    out = {'causal_latency_ms': lag*1000}
    for snr in [40, 30, 20, 15]:
        rng = np.random.default_rng(snr)
        n_emd = min(N_FAST, 30 if snr == 30 else 10)
        res = {}
        def add(k, a, b):
            res.setdefault(k, {'ramp': [], 'settled': []}); res[k]['ramp'].append(a); res[k]['settled'].append(b)
        for r in range(N_FAST):
            y = add_noise(y0, snr, rng)
            _, f = analytic_if(bandpass(y, FS, 40, 60), FS); add('PF+Hilbert', rmse(t, f, t, ftrue, RAMP), rmse(t, f, t, ftrue, SETT))
            f = causal_pf_hilbert(y); add('PF+Hilbert (causal)', rmse(t, f, t, ftrue, RAMP, lag), rmse(t, f, t, ftrue, SETT, lag))
            f = cwt_track(y, FS, 40, 60); add('CWT (L1)', rmse(t, f, t, ftrue, RAMP), rmse(t, f, t, ftrue, SETT))
            f, _ = sogi_fll(y, FS, 50.0); add('SOGI-FLL', rmse(t, f, t, ftrue, RAMP), rmse(t, f, t, ftrue, SETT))
            tc, f, _ = ipdft_track(y, FS, (40, 60), win=240, hop=8); add('IpDFT', rmse(tc, f, t, ftrue, RAMP), rmse(tc, f, t, ftrue, SETT))
            tc, f = esprit_track(y, FS, 50, 6, win=160, hop=16); add('ESPRIT', rmse(tc, f, t, ftrue, RAMP), rmse(tc, f, t, ftrue, SETT))
            tc, f, _ = stft_track(y, FS, (30, 70)); add('STFT', rmse(tc, f, t, ftrue, RAMP), rmse(tc, f, t, ftrue, SETT))
            u, c = vmd_modes(y, FS, 3); _, f = analytic_if(u[np.argmin(abs(c-50))], FS)
            add('VMD+Hilbert', rmse(t, f, t, ftrue, RAMP), rmse(t, f, t, ftrue, SETT))
            if r < n_emd:
                ce = CEEMDAN(trials=30, epsilon=0.05, parallel=False); ce.noise_seed(5000+r)
                imfs = ce.ceemdan(y, t); best, bd = None, 1e9
                for imf in imfs:
                    _, fi = analytic_if(imf, FS); md = np.median(fi[(t > .2) & (t < .8)])
                    if abs(md-50) < bd: bd, best = abs(md-50), fi
                add('Full HHT (CEEMDAN)', rmse(t, best, t, ftrue, RAMP), rmse(t, best, t, ftrue, SETT))
        out[snr] = {k: {w: summarize(v[w]) for w in v} for k, v in res.items()}
        print(snr, {k: f"{d['ramp']['med']:.3f}/{d['settled']['med']:.3f}" for k, d in out[snr].items()}, flush=True)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), 'res_mc2_rocof.json'), 'w'), indent=1)


if __name__ == '__main__':
    t0 = time.time(); run(); print(f"done {time.time()-t0:.0f}s")
