"""mc10_ceemdan100.py -- review report M3, Sec. 3.5: CEEMDAN-based methods with 100 realizations
(previously 30) in scenarios R (30 dB), G, D, U1 and U2. Fresh, independent noise realizations
from the same distributions; metrics computed exactly as in mc2-mc5."""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
import numpy as np
from mc_common import FS, A1, tvec, base, rocof_signal, growing_signal, transient_signal, add_noise, detect, logfit_rate, summarize
from methods.extra_estimators import bandstop, analytic_if
import mc4_transient as m4, mc5_unknown as m5
from PyEMD import CEEMDAN
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100; OUT = {}
def ce(y, t, s): c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(s); return c.ceemdan(y, t)
def save(): json.dump(OUT, open(os.path.join(os.path.dirname(__file__), 'res_mc10_ceemdan100.json'), 'w'), indent=1)

def R():
    t, y0, ft = rocof_signal(); rng = np.random.default_rng(1030); v = []
    rm = lambda f, w: float(np.sqrt(np.mean((f[(t >= w[0]) & (t <= w[1])]-ft[(t >= w[0]) & (t <= w[1])])**2)))
    for r in range(N):
        imfs = ce(add_noise(y0, 30, rng), t, 20000+r)
        best = min((analytic_if(i, FS)[1] for i in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50))
        v.append((rm(best, (.4, .55)), rm(best, (.6, .8))))
    OUT['R30'] = {'ramp': summarize([a for a, b in v]), 'settled': summarize([b for a, b in v])}; print('R30', OUT['R30'], flush=True)

def G():
    T0, T = 0.50, 1.05; t, y0, _ = growing_signal(T=T, t0=T0); rng = np.random.default_rng(1031); acc = {}
    for r in range(N):
        y = add_noise(y0, 30, rng)
        for k, pre in [('Full HHT (CEEMDAN)', False), ('FN-EMD', True)]:
            best, bd = None, 1e9
            for imf in ce(bandstop(y, FS, 40, 60) if pre else y, t, 21000+r):
                a, fi = analytic_if(imf, FS); md = np.median(fi[t > T0+0.2])
                if abs(md-110) < bd: bd, best = abs(md-110), a
            td = detect(t, best, (0.30, 0.48), (0.48, T-0.03)); d = acc.setdefault(k, {'det': [], 'fa': [], 'rate': []})
            d['fa'].append(td is not None and td < T0); d['det'].append(None if (td is None or td < T0) else td-T0)
            d['rate'].append(logfit_rate(t, best, (T0+0.05, T-0.08)))
    OUT['G'] = {k: dict(detect_prob=float(np.mean([x is not None for x in d['det']])), false_alarm=float(np.mean(d['fa'])),
                        delay_s=summarize(d['det']), growth_rate=summarize(d['rate'])) for k, d in acc.items()}
    print('G', OUT['G'], flush=True)

def D():
    t, y0, _ = transient_signal(t0=m4.T0); rng = np.random.default_rng(1032); acc = {}; late = t > m4.T0+0.15
    for r in range(N):
        y = add_noise(y0, 30, rng); imfs = ce(y, t, 22000+r); sc = []
        for imf in imfs:
            a, fi = analytic_if(imf, FS); e = (t >= m4.T0) & (t < m4.T0+0.06)
            sc.append(np.mean((fi[e] > 90) & (fi[e] < 150))*min(np.mean(a[(t >= m4.T0) & (t < m4.T0+0.05)])/(np.mean(a[late])+1e-9), 20))
        a, fi = analytic_if(imfs[int(np.argmax(sc))], FS)
        acc.setdefault('HHT, naive IMF rule', []).append(m4.est_env(t, a, fi)); acc.setdefault('EMD-guided LM', []).append(m4.emd_guided(t, y, imfs))
    OUT['D'] = {}
    for k, v in acc.items():
        f = np.array([a for a, b in v], float); tau = np.array([b for a, b in v], float); right = np.isfinite(f) & (abs(f-120) < 5)
        OUT['D'][k] = dict(right=float(right.mean()), f=summarize(f), tau_err=summarize(100*abs(tau-m4.TAU)/m4.TAU))
    print('D', OUT['D'], flush=True)

def U():
    t = tvec(0.5); m = (t > 0.05) & (t < 0.45); rng = np.random.default_rng(1033); rows = []
    for r in range(N):
        fu, au, ph = rng.uniform(70, 450), rng.uniform(0.10, 0.30)*A1, rng.uniform(-np.pi, np.pi)
        y = add_noise(base(t) + au*np.sin(2*np.pi*fu*t+ph), 30, rng); row = dict(rho=au*fu/(A1*50))
        for k, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
            imf = m5.pick_imf(ce(bandstop(y, FS, 40, 60) if pre else y, t, 23000+r), 60, 500, m)
            fe = np.nan if imf is None else float(np.median(analytic_if(imf, FS)[1][m])); row[k] = 100*abs(fe-fu)/fu
        rows.append(row)
    rho = np.array([x['rho'] for x in rows]); OUT['U1'] = {}
    for k in ['CEEMDAN', 'FN-EMD']:
        ok = np.array([np.isfinite(x[k]) and x[k] < 1 for x in rows])
        OUT['U1'][k] = dict(success=float(ok.mean()), rho_gt1=float(ok[rho > 1].mean()), rho_le1=float(ok[rho <= 1].mean()), n_rho_gt1=int((rho > 1).sum()))
    print('U1', OUT['U1'], flush=True)
    T = 0.6; t = tvec(T); k_ = 250/T; ftrue = 150 + k_*t; y0 = base(t) + 0.4*A1*np.sin(2*np.pi*(150*t + 0.5*k_*t**2))
    ev = (t >= 0.10) & (t <= 0.50); rng = np.random.default_rng(1034); acc = {}
    sm = lambda f: np.convolve(f, np.ones(20)/20, mode='same')
    for r in range(N):
        y = add_noise(y0, 30, rng)
        for k, pre in [('CEEMDAN', False), ('FN-EMD', True)]:
            imf = m5.pick_imf(ce(bandstop(y, FS, 40, 60) if pre else y, t, 24000+r), 60, 600, ev)
            acc.setdefault(k, []).append(np.nan if imf is None else float(np.sqrt(np.mean((sm(analytic_if(imf, FS)[1])[ev]-ftrue[ev])**2))))
    OUT['U2'] = {k: summarize(v) for k, v in acc.items()}; print('U2', OUT['U2'], flush=True)

if __name__ == '__main__':
    t0 = time.time()
    prev = json.load(open(os.path.join(os.path.dirname(__file__), 'res_mc10_ceemdan100.json'))) if os.path.exists(os.path.join(os.path.dirname(__file__), 'res_mc10_ceemdan100.json')) else {}
    OUT.update(prev)
    todo = sys.argv[2].split(',') if len(sys.argv) > 2 else ['G', 'R', 'D', 'U']
    for f in [{'G': G, 'R': R, 'D': D, 'U': U}[k] for k in todo]: f(); save()
    print(f"done {time.time()-t0:.0f}s")
