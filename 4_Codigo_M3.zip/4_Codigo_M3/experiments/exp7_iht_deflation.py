"""
exp7_iht_deflation.py
========================
IHT with iterative deflation (proposed): repeat the identify-and-
subtract step on the SAME target band, checking the band's residual
power after each subtraction, until it drops below 15% of its
pre-round value (or 4 rounds elapse) -- a more literal reading of
"Iterative" Hybrid Transform, meant to test whether repeated
subtraction closes the gap left by a single pass (exp6). It narrows
the gap (f1 extraction improves to ~1.8% residual power in one round)
but does NOT resolve f2 (still ~43% error after 2 rounds), because
each round re-runs the same signal-dependent sifting on a residual
that already carries the bias forward.

Run from the repository root:
    python3 experiments/exp7_iht_deflation.py
(Takes ~15-20s: multiple CEEMDAN rounds.)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from methods.ground_truth import CONFIGS, y_model, time_vector, FS
from methods.iht import iht_decompose_deflation


def run():
    t = time_vector()
    theta = CONFIGS['v1']
    y = y_model(theta, t)
    f_true = [theta[1], theta[4], theta[7]]
    ranges = [(35, 65), (max(60, f_true[1]*0.5), f_true[1]*1.5), (f_true[2]*0.7, f_true[2]*1.3)]

    results, final_res, diag = iht_decompose_deflation(
        t, y, FS, ranges, trials=60, epsilon=0.05, max_deflation_rounds=3)

    print("IHT with deflation on v1:\n")
    for i, (f_hat, imf) in enumerate(results):
        err = 100 * abs(f_hat - f_true[i]) / f_true[i]
        print(f"Tone {i+1}: true={f_true[i]:.3f}  IHT-deflation={f_hat:.3f}  error={err:.3f}%")
        for rlog in diag[i]:
            print(f"    round {rlog['round']}: f_hat={rlog['f_hat']:.2f}  "
                  f"power remaining in band={rlog['power_ratio_remaining']*100:.1f}%")
    return results, diag


if __name__ == '__main__':
    run()
