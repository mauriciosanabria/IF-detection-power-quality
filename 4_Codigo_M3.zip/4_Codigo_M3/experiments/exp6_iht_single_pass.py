"""
exp6_iht_single_pass.py
==========================
IHT (proposed): rather than a fixed external notch (FN-EMD), let
CEEMDAN identify the fundamental IMF from its OWN extracted frequency,
then subtract that exact waveform from the ORIGINAL signal. Fully
signal-adaptive, no external assumption about where the fundamental is.

Result: fails (45.5% error on v1's f2) because the identified IMF does
not capture 100% of the fundamental's energy (measured residual std
8.80 kV vs. 1.81 kV for a perfect subtraction) -- see the diagnostic
block at the end of this script, which reproduces that comparison.

Run from the repository root:
    python3 experiments/exp6_iht_single_pass.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np
from methods.ground_truth import CONFIGS, y_model, time_vector, FS
from methods.iht import iht_decompose
from scipy.signal import hilbert
from PyEMD import CEEMDAN


def run():
    t = time_vector()
    theta = CONFIGS['v1']
    y = y_model(theta, t)
    f_true = [theta[1], theta[4], theta[7]]

    ranges = [(35, 65), (max(60, f_true[1]*0.5), f_true[1]*1.5), (f_true[2]*0.7, f_true[2]*1.3)]

    results, final_residual = iht_decompose(t, y, FS, ranges, trials=100, epsilon=0.05)
    print("IHT on v1:\n")
    for i, (f_hat, imf) in enumerate(results):
        err = 100 * abs(f_hat - f_true[i]) / f_true[i]
        print(f"  Tone {i+1}: true={f_true[i]:.3f} Hz  IHT={f_hat:.3f} Hz  error={err:.3f}%")
    print(f"\n  Final residual std: {np.std(final_residual):.4f}")

    # Diagnostic: why it fails -- incomplete subtraction of the fundamental
    print("\n" + "="*60)
    print("DIAGNOSTIC: is the 'fundamental' IMF actually complete?")
    print("="*60)
    ceemdan = CEEMDAN(trials=100, epsilon=0.05, parallel=False)
    ceemdan.noise_seed(42)
    imfs = ceemdan.ceemdan(y, t)

    def medf(imf):
        a = hilbert(imf)
        ph = np.unwrap(np.angle(a))
        ifq = np.diff(ph) / (2*np.pi*(t[1]-t[0]))
        edge = int(0.05*len(t))
        v = ifq[edge:len(t)-1-edge]
        v = v[(v > 0) & (v < 2000)]
        return np.median(v) if len(v) else float('nan')

    freqs = [medf(imf) for imf in imfs]
    fund_idx = int(np.argmin([abs(f-50) for f in freqs]))
    print(f"Fundamental identified as IMF{fund_idx} at {freqs[fund_idx]:.3f} Hz")

    residual_after = y - imfs[fund_idx]
    a1, f1, p1 = theta[0], theta[1], theta[2]
    true_residual = y - a1*np.sin(2*np.pi*f1*t + p1)
    print(f"Residual std subtracting IDENTIFIED IMF: {np.std(residual_after):.4f}")
    print(f"Residual std subtracting TRUE f1 exactly:  {np.std(true_residual):.4f}")
    print(f"  (Ratio: {np.std(residual_after)/np.std(true_residual):.2f}x more energy left over)")


if __name__ == '__main__':
    run()
