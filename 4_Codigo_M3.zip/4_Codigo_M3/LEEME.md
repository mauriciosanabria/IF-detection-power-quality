# Código de M3

*Revisiting Instantaneous Frequency Detection in Power Quality: When Does Adaptive Decomposition Actually Help?*
(enviado a *Electric Power Systems Research*, Elsevier). Sanabria Villamizar, López García, Bueno López, López-Monsalvo y Beltran-Carbajal.

Aquí está todo el código con el que se generaron las tablas y figuras del manuscrito enviado a EPSR
(`manuscript_epsr.tex`, versión del 11-nov-2026), además de sus resultados y los dos registros medidos.
Corresponde a la versión v1.1.0 del repositorio.

## Instalación

Usa Python 3.12 y luego `pip install -r requirements.txt`. Las versiones de las bibliotecas son las exactas con las que se generaron los resultados: numpy 2.4.4,
scipy 1.17.1, matplotlib 3.10.8, EMD-signal 1.10.0, vmdpy 0.2 y PyWavelets 1.10.0. Con otras versiones pueden cambiar
algunas realizaciones que quedan justo en el umbral de éxito del 1 %.

Todos los scripts se ejecutan desde `experiments/journal/`. Las semillas son fijas, así que cada corrida da los mismos
resultados. Los resultados se guardan en esa misma carpeta (`res_*.json`, `*.jsonl`) y las figuras en `figures/`.
Antes de volver a correr un experimento, copia su resultado si quieres compararlo, porque se sobrescribe.

## Estructura

```
methods/                 estimadores y señales
  extra_estimators.py    IpDFT (ventana de Hann periódica), ESPRIT, SOGI-FLL, VMD, CWT, STFT, filtros, señal analítica
  extra2.py              Matrix Pencil, Prony, modelos de clase P y M (IEC/IEEE 60255-118-1), FSST
  hht_emd.py             EMD (biblioteca EMD-signal) y transformada de Hilbert
  fft_welch.py, iht.py   FFT secuencial e IHT
  ground_truth.py        configuraciones v1, v2 y v3 del escenario S
  ieee_style.py          estilo de las figuras
experiments/journal/     experimentos Monte Carlo (mc*.py), figuras (fig_*.py) y resultados
  mc_common.py           muestreo (4 kHz), señales de los escenarios, ruido, detección y estadísticas
  rlib.py                guardado por realización (corridas reanudables)
  realbg.py              fondo medido: lee los .mat, remuestrea a 4 kHz y quita la fundamental
experiments/exp6_iht_single_pass.py, exp7_iht_deflation.py   filas IHT de la Tabla 5
analisis_pendientes/     análisis de la revisión de nov-2026 (ver la tabla y la sección propia), con sus resultados;
                         localizan el resto del código con M3_CODE (por defecto, esta carpeta)
m1m2/raw_inputs.py       lector de los registros crudos (variable M1M2_DATA)
data/raw/                V_NoLISN_2V.mat y V_SiLISN_2V.mat: tensión del cargador, 1,25 MS/s
data/*.npy               exportaciones antiguas de las formas de onda (ya no se usan en el artículo)
figures/                 las 8 figuras tal como están en el manuscrito
extras/                  versión anterior de la figura D/U5, mc1_v3_60.py (rehizo la fila v3 a 60 dB de la Tabla 5) y
                         actualizar_U3_ipdft.py (ver la nota final)
```

## Qué script genera cada resultado

La numeración de tablas y figuras es la del manuscrito enviado a EPSR. Los scripts sin carpeta están en
`experiments/journal/`; `ap/` abrevia `analisis_pendientes/`. Los números con "S" son del suplementario.

| Manuscrito | Script(s) | Resultado |
|---|---|---|
| Fig. 1 (criterio de pendiente) | `fig_key_rho.py` | figures/key_slope_criterion.pdf |
| Tabla 3 (regímenes de cada escenario) | sin script: ρ_k calculado con la ec. (2) y la Tabla 2 | — |
| Tabla 4 y Tablas S5–S6 (escenario S, cota de Cramér–Rao) | `mc1_stationary.py 60 15` (o `mc1_parte.py N v1`, `v3`, `v2`); `mc8_new_methods.py 100` (Matrix Pencil, Prony); `ceemdan_tabla4.py` y `ceemdan_uno.py` (CEEMDAN y FN-EMD); `../exp6_iht_single_pass.py`, `../exp7_iht_deflation.py` (IHT); `mc12_crlb.py`, `analyze_round6.py` | res_mc1_stationary.json, res_mc8_new_methods.json, res_ceemdan_tabla4.json, crlb.jsonl, res_round6.json |
| Fig. 2 y Sec. 6.2 (barrido P) | `mc6_sweep.py` (todos los métodos menos CEEMDAN); `ap/p_ceemdan30.py` (CEEMDAN, 30 ensayos, 20 realizaciones por celda); `ap/fig_sweep_p30.py`; `ap/p_frontera_rf.py` (fronteras de Rilling y Flandrin) | res_mc6_sweep.json, ap/p_ceemdan30.json, ap/p_frontera_rf.json, ap/sweep_map.pdf |
| Tabla 5 y Tabla S8 (escenario G) | `mc3_growing.py 100`; CEEMDAN y FN-EMD: `mc10r_resumable.py`; FSST, Matrix Pencil y Prony: `mc8_new_methods.py` | res_mc3_growing.json, res_mc10_ceemdan100.json (G), res_mc8_new_methods.json (G) |
| Tabla 6, Tabla S9 y Fig. S4 (escenario D) | `mc4_transient.py 100`, `mc10r_resumable.py`, `mc8_new_methods.py`, `fig_scenarioD.py` | res_mc4_transient.json, D_ce_raw.jsonl, res_mc8_new_methods.json (D) |
| Sec. 6.4 y S7 (D: fase del transitorio y semilla de la EMD) | `ap/d_fases.py` (72 fases), `ap/d_fase_aleatoria.py` (fase sorteada), `ap/d_semilla_sin_emd.py` (el mismo ajuste sin EMD), `ap/s7.py` (análisis IMF por IMF) | ap/d_fases.json, ap/d_fase_aleatoria.json, ap/d_semilla_sin_emd.json, ap/s7.json |
| Tabla 7, Tablas S3 y S10, Fig. S5 (U1–U4) | `mc5_unknown.py 100`, `mc10r_resumable.py`, `mc9r_resumable.py`, `mc8_new_methods.py`, `fig_unknown_rho.py` | res_mc5_unknown.json, U1_ce_raw.jsonl, U2_ce_raw.jsonl, U3_raw.jsonl, U4_raw.jsonl, res_mc9_new_scenarios.json |
| Tabla 8, Fig. 3, Tablas S2, S3 y S7, Figs. S1–S3 (R y N) | `mc2_rocof.py 100`, `mc13_rocof_stats.py`, `mc10r_resumable.py`, `mc8_new_methods.py` (clases P y M, FSST), `mc17_ipdft_fix.py` (IpDFT, HT-IpDFT), `mc9_new_scenarios.py` (N), `fig_rocof_mc.py`, `fig_signal_model.py`, `fig_rocof_example.py`, `fig_scenarioU5.py` | res_mc2_rocof.json, rstats.jsonl, res_mc10_ceemdan100.json, res_mc8b_pmu_exact.json, res_mc17_ipdft_fix_raw.json, res_mc9_new_scenarios.json (clave U5) |
| Tabla 8 y Tabla S4 (fondo medido) | `REALBG_RAW=1 RLIB_SUFFIX=_raw python mc15_semisynthetic.py`, ídem `mc17_ipdft_fix.py`, `RLIB_SUFFIX=_raw python agg_semi.py` | semi_R_raw.jsonl, semi_G_raw.jsonl, real_f_raw.jsonl, res_semi_aggregate_raw.json |
| Sec. 7.3 y S4 (CEEMDAN con 200 y 500 ensayos, IMF recombinados) | `ap/ceemdan_ensayos.py` | ap/ceemdan_ensayos.json |
| Supl. S1 (red de 60 Hz) | `mc7_rocof60.py` | res_mc7_rocof60.json |
| Supl. S4 y Tabla S1 (sensibilidad) | `mc14_sensitivity.py` | sens.jsonl |
| Supl. S6 (verificación de la ec. (3)) | `ap/prop1_check.py` | ap/prop1_check.json |
| Supl. S8 (pruebas de cumplimiento PMU) | `mc11_pmu_compliance.py` | res_mc11_pmu_compliance.json |
| Supl. S15 (VMD en el escenario N) | `ap/vmd_n.py` | ap/vmd_n.json |
| Tabla S11 (costo de cómputo) | `timing.py` (los tiempos dependen de la máquina) | res_timing.json |
| Tabla 9 (guía por tarea) y Tabla S12 (comparación global) | sin script: resumen las tablas anteriores | — |

Las variables de entorno `REALBG_RAW=1` y `RLIB_SUFFIX=_raw` hacen que se use el registro crudo de 1,25 MS/s. Sin
ellas se usan las exportaciones `.npy` de una versión anterior. En Windows (PowerShell) se definen así:
`$env:REALBG_RAW="1"; $env:RLIB_SUFFIX="_raw"`.

## Corridas largas

Los métodos con CEEMDAN tardan de 2 a 5 s por descomposición, así que las corridas que los incluyen tardan de decenas de minutos a horas.
Algunos scripts guardan cada realización al terminarla y, si se interrumpen, retoman donde quedaron al volver a lanzarlos:
`mc10r_resumable.py`, `mc9r_resumable.py`, `mc1_parte.py`, `mc12`–`mc17`. Para empezar de cero, borra su `.jsonl`.
Para una prueba rápida, pasa un número pequeño de realizaciones (por ejemplo `python mc3_growing.py 5`).

## Trampas conocidas

- **IpDFT:** usa la ventana de Hann periódica (DFT-even), que es la que supone la fórmula de interpolación. Con la
  simétrica (`numpy.hanning`) la frecuencia se sesga en decenas de mHz y cambian las detecciones.
- **EMD:** usa la biblioteca EMD-signal. La implementación propia anterior generaba IMF espurias. Prueba rápida: una
  senoide pura debe dar una sola IMF.
- **`ModuleNotFoundError: methods`:** pasa si no ejecutas desde `experiments/journal/`.

## Nota sobre la verificación (11-nov-2026)

- **Figuras:** las 8 figuras se regeneraron con estos scripts. Coinciden en datos con las del manuscrito y solo
  difieren en detalles menores de estilo.
  - `fig_signal_model.py` es nuevo: el anterior dibujaba otra versión de la Fig. 1.
  - Las Figs. 6 y 7 salen de `fig_scenarioU5.py` y `fig_scenarioD.py`. El `fig_D_U5.py` anterior, que está en `extras/`, dibuja una versión vieja.
- **Resultados guardados que estaban desactualizados:** dos archivos se habían generado antes de la corrección de la ventana del IpDFT (3-oct-2026).
  - `res_mc3_growing.json`: la fila IpDFT de la Tabla 8 daba 100 % y 180 ms. Con el código actual da 98 % y 130 ms, que es lo que dice el artículo. Se volvió a correr `mc3_growing.py 100`.
  - `U3_raw.jsonl`: en la fila IpDFT de U3 cambiaban unas décimas de ms. Se recalculó solo esa fila con `extras/actualizar_U3_ipdft.py` y se volvió a agregar. Ahora da 0,75 falsos por registro, como la Tabla S3.
  - Los demás resultados se generaron después de esa corrección o no usan el IpDFT.
- **Lo que no se revisó:** no se volvieron a correr todas las tablas celda por celda, porque las corridas con CEEMDAN tardan horas.

## Análisis añadidos en la v1.1.0 (`analisis_pendientes/`)

Se escribieron en la revisión de noviembre de 2026. Se corren desde su propia carpeta y no sobrescriben ningún
resultado de `experiments/journal/`. `p_ceemdan30.py` y `ceemdan_ensayos.py` usan varios procesos y son reanudables.

| Script | Qué hace |
|---|---|
| `p_ceemdan30.py` | Barrido P con CEEMDAN de 30 ensayos sobre las mismas 20 realizaciones por celda que los demás métodos. Con `control` repite la corrida original (20 ensayos, 5 realizaciones) y debe reproducirla |
| `fig_sweep_p30.py` | Fig. 2 con el panel de CEEMDAN de la corrida anterior |
| `p_frontera_rf.py` | Compara la frontera de pendiente con la frontera refinada y el corte de Rilling y Flandrin (2008) |
| `d_fases.py` | Extremos de la señal de D para 72 fases iniciales del transitorio |
| `d_fase_aleatoria.py` | Escenario D con la fase del transitorio sorteada |
| `d_semilla_sin_emd.py` | El ajuste LM "guiado por EMD" con la semilla tomada del espectro, sin EMD |
| `ceemdan_ensayos.py` | CEEMDAN con 30, 200 y 500 ensayos, con un IMF y con la suma de los IMF de la banda, en S y R |
| `ceemdan_ensayos_piloto.py` | Piloto previo del anterior (5 realizaciones) |
| `prop1_check.py` | Conteo numérico de extremos frente a la ec. (3) |
| `s7.py`, `vmd_n.py` | Análisis de octubre: modos de v1 y D, y mecanismo de VMD en N |

## Resultados guardados que ya no son los del artículo

Se conservan por trazabilidad, pero el artículo usa otros:

- `res_mc6_sweep.json`, columna `CEEMDAN` (20 ensayos, 5 realizaciones por celda): la del artículo es
  `analisis_pendientes/p_ceemdan30.json` (30 ensayos, 20 realizaciones por celda).
- `res_mc9_new_scenarios.json`, clave `U5`, fila `IpDFT` (anterior a la ventana de Hann periódica): la del artículo
  está en `res_mc17_ipdft_fix_raw.json`.
- `res_mc8_new_methods.json`, clave `R`, fila `M-class` (anterior al modelo exacto de la norma): la del artículo
  está en `res_mc8b_pmu_exact.json`; volver a correr `mc8_new_methods.py` con el código actual la reproduce.
