import os
import sys; sys.path.insert(0, '../../methods'); sys.path.insert(0, '.'); sys.path.insert(0, '../..')
from ieee_style import plt
import numpy as np
from mc_common import FS, transient_signal, rocof_signal, add_noise
from methods.ground_truth import CONFIGS
from methods.extra_estimators import analytic_if, bandpass, vmd_modes
from methods.extra2 import matrix_pencil, pmu_frequency
import mc4_transient as m4
from PyEMD import CEEMDAN
# ---------------- Scenario D
t, y0, env = transient_signal(t0=m4.T0); y = add_noise(y0, 30, np.random.default_rng(2027)); T0 = m4.T0
c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(1); imfs = c.ceemdan(y, t); late = t > T0+0.15; sc = []
for imf in imfs:
    a, fi = analytic_if(imf, FS); e = (t >= T0) & (t < T0+0.06)
    sc.append(np.mean((fi[e] > 90) & (fi[e] < 150))*min(np.mean(a[(t >= T0) & (t < T0+0.05)])/(np.mean(a[late])+1e-9), 20))
a_n, f_n = analytic_if(imfs[int(np.argmax(sc))], FS); f_g, tau_g = m4.emd_guided(t, y, imfs)
seg = (t >= T0+0.002) & (t <= T0+0.10); fm, sm, am = matrix_pencil(y[seg], FS, 8); k = (fm > 90) & (fm < 150); i = np.argmin(abs(fm[k]-120))
f_mp, s_mp, A_mp = fm[k][i], sm[k][i], am[k][i]
print(f'D: naive IMF median f (onset+5..40 ms) = {np.median(f_n[(t > T0+.005) & (t < T0+.04)]):.1f} Hz; guided f={f_g:.2f}, tau={1000*tau_g:.1f} ms; MP f={f_mp:.2f}, tau={-1000/s_mp:.1f} ms')
w = (t >= T0-0.03) & (t <= T0+0.08); tm = 1000*t[w]
fig, ax = plt.subplots(3, 1, figsize=(3.6, 5.6), sharex=True)
ax[0].plot(tm, y[w], color='#000000', lw=0.6); ax[0].axvline(1000*T0, color='#888888', ls=':', lw=0.8); ax[0].set_ylabel('Voltage (kV)')
on = t[w] >= T0
ax[1].axhline(120, color='#000000', lw=1.4, label='True (120 Hz)'); ax[1].plot(tm, np.clip(f_n[w], 0, 200), color='#c0392b', lw=0.8, label='HHT, selected IMF')
ax[1].plot(tm[on], np.full(on.sum(), f_g), color='#2e7d32', ls='--', lw=1.3, label='EMD-guided LM'); ax[1].plot(tm[on], np.full(on.sum(), f_mp), color='#1a5fb4', ls=':', lw=1.5, label='Matrix Pencil')
ax[1].set_ylim(0, 200); ax[1].set_ylabel('Inst. frequency (Hz)'); ax[1].legend(fontsize=6, loc='lower right', ncol=2)
ax[2].plot(tm, env[w], color='#000000', lw=1.4, label=r'True, $\tau$ = 15 ms'); ax[2].plot(tm, a_n[w], color='#c0392b', lw=0.8, label='HHT, selected IMF')
ax[2].plot(tm[on], A_mp*np.exp(s_mp*(t[w][on]-T0-0.002)), color='#1a5fb4', ls=':', lw=1.5, label='Matrix Pencil')
ax[2].set_ylabel('Envelope (kV)'); ax[2].set_xlabel('Time (ms)'); ax[2].legend(fontsize=6, loc='upper right')
for a_, l in zip(ax, '(a)(b)(c)'.replace(')(', ') (').split()): a_.text(0.02, 0.9, l, transform=a_.transAxes, fontsize=8)
plt.tight_layout(); plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'scenarioD_frequency.pdf'))
# ---------------- Scenario U5
t, yR, ft = rocof_signal(); a1, _, p1 = CONFIGS['v1'][:3]
ph = np.mod(2*np.pi*np.cumsum(ft)/FS + p1, np.pi/3); h = (ph > 0.5) & (ph < 0.5 + 2*np.pi*50*0.0006); yN0 = yR*(1-0.3*h)
y = add_noise(yN0, 30, np.random.default_rng(2028))
tr = {'PF+Hilbert': (t, analytic_if(bandpass(y, FS, 40, 60), FS)[1]), 'M class': (t, pmu_frequency(y, FS, 50.0, 'M')[0])}
u, cc = vmd_modes(y, FS, 3); tr['VMD+Hilbert'] = (t, analytic_if(u[np.argmin(abs(cc-50))], FS)[1])
c = CEEMDAN(trials=30, epsilon=0.05, parallel=False); c.noise_seed(2); imfs = c.ceemdan(y, t)
tr['Full HHT (CEEMDAN)'] = (t, min((analytic_if(q, FS)[1] for q in imfs), key=lambda q: abs(np.median(q[(t > .2) & (t < .8)])-50)))
st = {'PF+Hilbert': ('#c0392b', '-', 1.1), 'M class': ('#1a5fb4', '--', 1.1), 'VMD+Hilbert': ('#e67e22', '-.', 0.8), 'Full HHT (CEEMDAN)': ('#777777', '-', 0.5)}
fig = plt.figure(figsize=(7.1, 5.2)); gs = fig.add_gridspec(2, 2, width_ratios=[1, 2.3], height_ratios=[1, 1], hspace=0.35, wspace=0.28)
a0 = fig.add_subplot(gs[:, 0]); c1 = (t >= 0.30) & (t < 0.32)
a0.plot(1000*(t[c1]-0.30), yR[c1], color='#999999', ls='--', lw=1.0, label='Undistorted'); a0.plot(1000*(t[c1]-0.30), yN0[c1], color='#000000', lw=1.0, label='Notched')
a0.set_xlabel('Time (ms)'); a0.set_ylabel('Voltage (kV)'); a0.legend(fontsize=6.5, loc='lower left'); a0.set_title('(a) One cycle', fontsize=8.5)
a1_ = fig.add_subplot(gs[0, 1]); a2_ = fig.add_subplot(gs[1, 1], sharex=a1_); m = (t >= 0.3) & (t <= 0.85)
a1_.plot(1000*t[m], ft[m], color='#000000', lw=1.6, label='True', zorder=6)
for k_, (tt, f) in tr.items():
    c_, ls, lw = st[k_]; mm = (tt >= 0.3) & (tt <= 0.85)
    a1_.plot(1000*tt[mm], f[mm], color=c_, ls=ls, lw=lw, label=k_); a2_.plot(1000*tt[mm], f[mm]-np.interp(tt[mm], t, ft), color=c_, ls=ls, lw=lw)
for a_ in (a1_, a2_): a_.axvspan(400, 550, color='#e8e8e8', zorder=0)
a1_.set_ylim(47, 52.5); a1_.set_ylabel('Frequency (Hz)'); a1_.legend(fontsize=6.3, loc='upper right', ncol=2); a1_.set_title('(b) Instantaneous frequency', fontsize=8.5)
a2_.set_ylim(-3, 3); a2_.axhline(0, color='k', lw=0.5); a2_.set_ylabel('Error (Hz)'); a2_.set_xlabel('Time (ms)'); a2_.set_title('(c) Frequency error', fontsize=8.5)
plt.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figures', 'scenarioU5_frequency.pdf'), bbox_inches='tight'); print('figs ok')
