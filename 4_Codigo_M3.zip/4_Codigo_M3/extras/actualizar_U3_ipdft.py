"""actualizar_U3_ipdft.py -- recomputes only the IpDFT entries of U3_raw.jsonl with the current ipdft_track (periodic
Hann window) and re-aggregates res_mc9_new_scenarios.json. The stored IpDFT entries had been computed before the window
correction of 3-oct-2026; the other methods of U3 do not use the IpDFT and are left unchanged. Run from
experiments/journal/:  python ../../extras/actualizar_U3_ipdft.py"""
import sys, os, json
J = os.getcwd(); sys.path.insert(0, J); sys.path.insert(0, os.path.join(J, '..', '..'))
import numpy as np
from mc_common import FS, A1, tvec, base, add_noise
from methods.extra_estimators import bandstop, ipdft_track
from mc9_new_scenarios import score_bursts
import mc9r_resumable as M
rows = [json.loads(l) for l in open('U3_raw.jsonl')]
for row in rows:
    r = row['r']; t = tvec(1.0); rng = np.random.default_rng(930000 + r)          # same signal as mc9r_resumable.U3
    fb, ab = rng.uniform(150, 450), rng.uniform(0.10, 0.30)*A1
    starts = [0.15 + rng.uniform(0, .05), 0.45 + rng.uniform(0, .05), 0.75 + rng.uniform(0, .05)]; y = base(t)
    for s in starts:
        e = np.clip((t - s)/0.005, 0, 1)*np.clip((s + 0.06 - t)/0.005, 0, 1); e = 0.5 - 0.5*np.cos(np.pi*e)
        y = y + ab*e*np.sin(2*np.pi*fb*t + rng.uniform(-np.pi, np.pi))
    y = add_noise(y, 30, rng); yn = bandstop(y, FS, 40, 60); tc, f, a = ipdft_track(yn, FS, (60, 500), win=120, hop=8)
    d, fa, on, fo = score_bursts(tc, a, f, starts, fb); row['IpDFT'] = [d, fa, [float(x) for x in on], fo]
with open('U3_raw.jsonl', 'w') as fh:
    for row in rows: fh.write(json.dumps(row) + '\n')
M.aggregate()
