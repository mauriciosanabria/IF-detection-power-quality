import sys; sys.argv = ['x', '60', '15']
import mc1_stationary as m
from methods.ground_truth import CONFIGS
orig = dict(CONFIGS)
for k in ['v1', 'v2']: CONFIGS.pop(k)
import numpy as np
src = open('mc1_stationary.py').read().replace("for SNR in [30, 60]:", "for SNR in [60]:").replace("res_mc1_stationary.json", "res_mc1_v3_60.json")
exec(compile(src, 'mc1_v3', 'exec'), {'__name__': '__main__', '__file__': 'mc1_stationary.py'})
